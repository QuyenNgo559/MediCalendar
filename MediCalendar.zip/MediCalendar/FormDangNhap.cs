﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediCalendar
{
    public partial class FormDangNhap : Form
    {
        public FormDangNhap()
        {
            InitializeComponent();
        }

        private void txtQuenMatKhau_Click(object sender, EventArgs e)
        {
            this.Close();
            QuenMatKhau quenMatKhau = new QuenMatKhau();
            quenMatKhau.ShowDialog();
            
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            TrangChuBacSi trangChuBacSi = new TrangChuBacSi();
            this.Hide();
            trangChuBacSi.ShowDialog();
            this.Close();
        }
    }
}

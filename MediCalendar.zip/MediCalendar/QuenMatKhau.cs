﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;

namespace MediCalendar
{
    public partial class QuenMatKhau : Form
    {
        private string authorizeCode;
        private DateTime codeGenerationTime;
        private int countdownSeconds = 60;
        public QuenMatKhau()
        {
            InitializeComponent();
        }

        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            // 1. Kiểm tra xem mã còn tồn tại không (chưa bị timer hủy)
            if (string.IsNullOrEmpty(authorizeCode))
            {
                MessageBox.Show("Mã xác thực đã hết hiệu lực hoặc không chính xác. Vui lòng yêu cầu mã mới.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Lấy mã người dùng nhập
            string userInputCode = txtMatKhauKhoiPhuc.Text.Trim();

            // 2. So sánh mã
            if (userInputCode == this.authorizeCode)
            {
                tmrCountdown.Stop(); // Dừng đếm ngược khi đã xác thực thành công
                MessageBox.Show("Xác thực thành công!", "Thành công");

                this.Close();
                DatLaiMatKhau datLaiMatKhau = new DatLaiMatKhau();
                datLaiMatKhau.ShowDialog();
            }
            else
            {
                MessageBox.Show("Mã xác nhận không chính xác. Vui lòng thử lại.", "Lỗi");
            }
        }

        private void btnGuiYeuCau_Click(object sender, EventArgs e)
        {
            try
            {
                // 1. Tạo mã ngẫu nhiên gồm 6 chữ số
                Random rand = new Random();
                authorizeCode = rand.Next(100000, 999999).ToString();
                codeGenerationTime = DateTime.Now;

                // 2. Cấu hình thông tin email
                string fromEmail = "tonydangtg63@gmail.com"; // Email của bạn
                string fromPassword = "ewqv yzzi huuc ptet"; // Dùng Mật khẩu ứng dụng của Gmail
                string toEmail = txtEmail.Text.Trim(); ; // Lấy email từ TextBox

                MailMessage message = new MailMessage();
                message.From = new MailAddress(fromEmail);
                message.To.Add(toEmail);
                message.Subject = "MediCalendar - Mã khôi phục mật khẩu";
                message.Body = $"<p>Mã xác thực để đặt lại mật khẩu của bạn là: <strong>{authorizeCode}</strong>. Vui lòng không chia sẻ cho bất kỳ ai khác.</p>";
                message.IsBodyHtml = true;

                // 3. Cấu hình máy chủ SMTP của Gmail
                SmtpClient smtp = new SmtpClient("smtp.gmail.com");
                smtp.EnableSsl = true;
                smtp.Port = 587;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.Credentials = new NetworkCredential(fromEmail, fromPassword);

                // 4. Gửi email
                smtp.Send(message);

                MessageBox.Show("Mã xác thực đã được gửi. Vui lòng kiểm tra email!", "Thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);

                countdownSeconds = 60; // Reset thời gian
                lblCountdown.Text = $"Mã hết hạn sau: {countdownSeconds} giây";
                tmrCountdown.Start(); // Bắt đầu timer
                btnGuiYeuCau.Enabled = false; // Vô hiệu hóa nút gửi lại
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi gửi email: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tmrCountdown_Tick(object sender, EventArgs e)
        {
            countdownSeconds--; // Giảm thời gian đi 1
            lblCountdown.Text = $"Mã hết hạn sau: {countdownSeconds} giây";

            if (countdownSeconds <= 0)
            {
                tmrCountdown.Stop(); // Dừng timer
                authorizeCode = null;   // Hủy mã xác thực
                btnGuiYeuCau.Enabled = true; // Cho phép gửi lại
                lblCountdown.Text = "Mã hết hạn!";
            }
        }
    }
}

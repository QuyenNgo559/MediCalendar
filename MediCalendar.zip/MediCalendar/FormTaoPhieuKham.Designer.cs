﻿namespace MediCalendar
{
    partial class FormTaoPhieuKham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges19 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges20 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            txtSDT = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            btnHuy = new Guna.UI2.WinForms.Guna2Button();
            btnTaoPhieu = new Guna.UI2.WinForms.Guna2Button();
            dtpNgayKham = new DateTimePicker();
            label1 = new Label();
            txtLyDoKham = new Guna.UI2.WinForms.Guna2TextBox();
            txtTrieuChung = new Guna.UI2.WinForms.Guna2TextBox();
            btnTaoDonThuoc = new Guna.UI2.WinForms.Guna2Button();
            txtChanDoan = new Guna.UI2.WinForms.Guna2TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            checkBox1 = new CheckBox();
            SuspendLayout();
            // 
            // txtSDT
            // 
            txtSDT.BorderRadius = 50;
            txtSDT.CustomizableEdges = customizableEdges15;
            txtSDT.DefaultText = "";
            txtSDT.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtSDT.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtSDT.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtSDT.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtSDT.FillColor = Color.WhiteSmoke;
            txtSDT.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSDT.Font = new Font("Segoe UI", 9F);
            txtSDT.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtSDT.Location = new Point(15, 98);
            txtSDT.Margin = new Padding(6, 6, 6, 6);
            txtSDT.Name = "txtSDT";
            txtSDT.PlaceholderText = "";
            txtSDT.SelectedText = "";
            txtSDT.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtSDT.Size = new Size(575, 80);
            txtSDT.TabIndex = 1;
            txtSDT.KeyPress += txtSDT_KeyPress;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Open Sans SemiBold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(44, 38);
            label2.Name = "label2";
            label2.Size = new Size(424, 43);
            label2.TabIndex = 3;
            label2.Text = "Số điện thoại người bệnh*";
            // 
            // btnHuy
            // 
            btnHuy.BorderRadius = 50;
            btnHuy.CustomizableEdges = customizableEdges17;
            btnHuy.DisabledState.BorderColor = Color.DarkGray;
            btnHuy.DisabledState.CustomBorderColor = Color.DarkGray;
            btnHuy.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnHuy.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnHuy.FillColor = Color.FromArgb(240, 18, 18);
            btnHuy.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHuy.ForeColor = Color.White;
            btnHuy.Location = new Point(286, 738);
            btnHuy.Name = "btnHuy";
            btnHuy.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnHuy.Size = new Size(237, 75);
            btnHuy.TabIndex = 8;
            btnHuy.Text = "Hủy";
            btnHuy.Click += btnHuy_Click;
            // 
            // btnTaoPhieu
            // 
            btnTaoPhieu.BorderRadius = 50;
            btnTaoPhieu.CustomizableEdges = customizableEdges19;
            btnTaoPhieu.DisabledState.BorderColor = Color.DarkGray;
            btnTaoPhieu.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTaoPhieu.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTaoPhieu.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTaoPhieu.FillColor = Color.FromArgb(4, 140, 212);
            btnTaoPhieu.Font = new Font("Segoe UI Semibold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTaoPhieu.ForeColor = Color.White;
            btnTaoPhieu.Location = new Point(557, 738);
            btnTaoPhieu.Name = "btnTaoPhieu";
            btnTaoPhieu.ShadowDecoration.CustomizableEdges = customizableEdges20;
            btnTaoPhieu.Size = new Size(326, 75);
            btnTaoPhieu.TabIndex = 9;
            btnTaoPhieu.Text = "Tạo phiếu";
            btnTaoPhieu.Click += btnTaoPhieu_Click;
            // 
            // dtpNgayKham
            // 
            dtpNgayKham.Location = new Point(744, 116);
            dtpNgayKham.Name = "dtpNgayKham";
            dtpNgayKham.Size = new Size(702, 39);
            dtpNgayKham.TabIndex = 10;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Open Sans SemiBold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(1252, 38);
            label1.Name = "label1";
            label1.Size = new Size(194, 43);
            label1.TabIndex = 11;
            label1.Text = "Ngày khám";
            // 
            // txtLyDoKham
            // 
            txtLyDoKham.CustomizableEdges = customizableEdges21;
            txtLyDoKham.DefaultText = "";
            txtLyDoKham.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtLyDoKham.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtLyDoKham.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtLyDoKham.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtLyDoKham.FillColor = Color.WhiteSmoke;
            txtLyDoKham.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtLyDoKham.Font = new Font("Segoe UI", 9F);
            txtLyDoKham.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtLyDoKham.Location = new Point(24, 220);
            txtLyDoKham.Margin = new Padding(6, 6, 6, 6);
            txtLyDoKham.Name = "txtLyDoKham";
            txtLyDoKham.PlaceholderText = "";
            txtLyDoKham.SelectedText = "";
            txtLyDoKham.ShadowDecoration.CustomizableEdges = customizableEdges22;
            txtLyDoKham.Size = new Size(1422, 68);
            txtLyDoKham.TabIndex = 12;
            // 
            // txtTrieuChung
            // 
            txtTrieuChung.CustomizableEdges = customizableEdges23;
            txtTrieuChung.DefaultText = "";
            txtTrieuChung.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtTrieuChung.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtTrieuChung.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtTrieuChung.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtTrieuChung.FillColor = Color.WhiteSmoke;
            txtTrieuChung.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtTrieuChung.Font = new Font("Segoe UI", 9F);
            txtTrieuChung.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtTrieuChung.Location = new Point(24, 337);
            txtTrieuChung.Margin = new Padding(6, 6, 6, 6);
            txtTrieuChung.Name = "txtTrieuChung";
            txtTrieuChung.PlaceholderText = "";
            txtTrieuChung.SelectedText = "";
            txtTrieuChung.ShadowDecoration.CustomizableEdges = customizableEdges24;
            txtTrieuChung.Size = new Size(1422, 130);
            txtTrieuChung.TabIndex = 13;
            // 
            // btnTaoDonThuoc
            // 
            btnTaoDonThuoc.BorderRadius = 50;
            btnTaoDonThuoc.CustomizableEdges = customizableEdges25;
            btnTaoDonThuoc.DisabledState.BorderColor = Color.DarkGray;
            btnTaoDonThuoc.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTaoDonThuoc.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTaoDonThuoc.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTaoDonThuoc.FillColor = Color.FromArgb(4, 140, 121);
            btnTaoDonThuoc.Font = new Font("Segoe UI Semibold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTaoDonThuoc.ForeColor = Color.White;
            btnTaoDonThuoc.Location = new Point(927, 738);
            btnTaoDonThuoc.Name = "btnTaoDonThuoc";
            btnTaoDonThuoc.ShadowDecoration.CustomizableEdges = customizableEdges26;
            btnTaoDonThuoc.Size = new Size(326, 75);
            btnTaoDonThuoc.TabIndex = 14;
            btnTaoDonThuoc.Text = "Tạo đơn thuốc";
            // 
            // txtChanDoan
            // 
            txtChanDoan.CustomizableEdges = customizableEdges27;
            txtChanDoan.DefaultText = "";
            txtChanDoan.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtChanDoan.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtChanDoan.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtChanDoan.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtChanDoan.FillColor = Color.WhiteSmoke;
            txtChanDoan.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtChanDoan.Font = new Font("Segoe UI", 9F);
            txtChanDoan.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtChanDoan.Location = new Point(24, 518);
            txtChanDoan.Margin = new Padding(6, 6, 6, 6);
            txtChanDoan.Name = "txtChanDoan";
            txtChanDoan.PlaceholderText = "";
            txtChanDoan.SelectedText = "";
            txtChanDoan.ShadowDecoration.CustomizableEdges = customizableEdges28;
            txtChanDoan.Size = new Size(1422, 208);
            txtChanDoan.TabIndex = 15;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(26, 182);
            label3.Name = "label3";
            label3.Size = new Size(167, 37);
            label3.TabIndex = 16;
            label3.Text = "Lý do khám";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(24, 473);
            label4.Name = "label4";
            label4.Size = new Size(157, 37);
            label4.TabIndex = 17;
            label4.Text = "Chẩn đoán";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(26, 294);
            label5.Name = "label5";
            label5.Size = new Size(173, 37);
            label5.TabIndex = 18;
            label5.Text = "Triệu chứng";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Font = new Font("Open Sans", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            checkBox1.Location = new Point(1048, 38);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(198, 47);
            checkBox1.TabIndex = 19;
            checkBox1.Text = "Tái khám";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // FormTaoPhieuKham
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1479, 840);
            Controls.Add(checkBox1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(txtChanDoan);
            Controls.Add(btnTaoDonThuoc);
            Controls.Add(txtTrieuChung);
            Controls.Add(txtLyDoKham);
            Controls.Add(label1);
            Controls.Add(dtpNgayKham);
            Controls.Add(btnTaoPhieu);
            Controls.Add(btnHuy);
            Controls.Add(label2);
            Controls.Add(txtSDT);
            Name = "FormTaoPhieuKham";
            Text = "Tạo phiếu khám";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Guna.UI2.WinForms.Guna2TextBox txtSDT;
        private Label label2;
        private Guna.UI2.WinForms.Guna2Button btnHuy;
        private Guna.UI2.WinForms.Guna2Button btnTaoPhieu;
        private DateTimePicker dtpNgayKham;
        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtLyDoKham;
        private Guna.UI2.WinForms.Guna2TextBox txtTrieuChung;
        private Guna.UI2.WinForms.Guna2Button btnTaoDonThuoc;
        private Guna.UI2.WinForms.Guna2TextBox txtChanDoan;
        private Label label3;
        private Label label4;
        private Label label5;
        private CheckBox checkBox1;
    }
}
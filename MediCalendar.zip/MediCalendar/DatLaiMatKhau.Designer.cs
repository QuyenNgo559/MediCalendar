﻿namespace MediCalendar
{
    partial class DatLaiMatKhau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label1 = new Label();
            txtMatKhauMoi = new Guna.UI2.WinForms.Guna2TextBox();
            txtXacNhanMatKhauMoi = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            label3 = new Label();
            btnHuy = new Guna.UI2.WinForms.Guna2Button();
            btnDoiMatKhau = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Open Sans", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(89, 33);
            label1.Name = "label1";
            label1.Size = new Size(384, 78);
            label1.TabIndex = 0;
            label1.Text = "Đặt lại mật khẩu";
            // 
            // txtMatKhauMoi
            // 
            txtMatKhauMoi.BorderRadius = 50;
            txtMatKhauMoi.CustomizableEdges = customizableEdges1;
            txtMatKhauMoi.DefaultText = "";
            txtMatKhauMoi.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMatKhauMoi.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMatKhauMoi.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMatKhauMoi.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMatKhauMoi.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMatKhauMoi.Font = new Font("Segoe UI", 9F);
            txtMatKhauMoi.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMatKhauMoi.Location = new Point(36, 203);
            txtMatKhauMoi.Margin = new Padding(6, 6, 6, 6);
            txtMatKhauMoi.Name = "txtMatKhauMoi";
            txtMatKhauMoi.PlaceholderText = "";
            txtMatKhauMoi.SelectedText = "";
            txtMatKhauMoi.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtMatKhauMoi.Size = new Size(508, 84);
            txtMatKhauMoi.TabIndex = 1;
            // 
            // txtXacNhanMatKhauMoi
            // 
            txtXacNhanMatKhauMoi.BorderRadius = 50;
            txtXacNhanMatKhauMoi.CustomizableEdges = customizableEdges3;
            txtXacNhanMatKhauMoi.DefaultText = "";
            txtXacNhanMatKhauMoi.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtXacNhanMatKhauMoi.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtXacNhanMatKhauMoi.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtXacNhanMatKhauMoi.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtXacNhanMatKhauMoi.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtXacNhanMatKhauMoi.Font = new Font("Segoe UI", 9F);
            txtXacNhanMatKhauMoi.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtXacNhanMatKhauMoi.Location = new Point(36, 360);
            txtXacNhanMatKhauMoi.Margin = new Padding(6, 6, 6, 6);
            txtXacNhanMatKhauMoi.Name = "txtXacNhanMatKhauMoi";
            txtXacNhanMatKhauMoi.PlaceholderText = "";
            txtXacNhanMatKhauMoi.SelectedText = "";
            txtXacNhanMatKhauMoi.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtXacNhanMatKhauMoi.Size = new Size(508, 84);
            txtXacNhanMatKhauMoi.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(55, 158);
            label2.Name = "label2";
            label2.Size = new Size(214, 37);
            label2.TabIndex = 3;
            label2.Text = "Mật khẩu mới*";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(55, 317);
            label3.Name = "label3";
            label3.Size = new Size(342, 37);
            label3.TabIndex = 4;
            label3.Text = "Xác nhận mật khẩu mới*";
            // 
            // btnHuy
            // 
            btnHuy.BorderRadius = 50;
            btnHuy.CustomizableEdges = customizableEdges5;
            btnHuy.DisabledState.BorderColor = Color.DarkGray;
            btnHuy.DisabledState.CustomBorderColor = Color.DarkGray;
            btnHuy.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnHuy.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnHuy.FillColor = Color.FromArgb(240, 18, 18);
            btnHuy.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHuy.ForeColor = Color.White;
            btnHuy.Location = new Point(36, 498);
            btnHuy.Name = "btnHuy";
            btnHuy.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnHuy.Size = new Size(178, 80);
            btnHuy.TabIndex = 5;
            btnHuy.Text = "Hủy";
            btnHuy.Click += btnHuy_Click;
            // 
            // btnDoiMatKhau
            // 
            btnDoiMatKhau.BorderRadius = 50;
            btnDoiMatKhau.CustomizableEdges = customizableEdges7;
            btnDoiMatKhau.DisabledState.BorderColor = Color.DarkGray;
            btnDoiMatKhau.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDoiMatKhau.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDoiMatKhau.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDoiMatKhau.FillColor = Color.FromArgb(4, 140, 212);
            btnDoiMatKhau.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDoiMatKhau.ForeColor = Color.White;
            btnDoiMatKhau.Location = new Point(220, 498);
            btnDoiMatKhau.Name = "btnDoiMatKhau";
            btnDoiMatKhau.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnDoiMatKhau.Size = new Size(324, 80);
            btnDoiMatKhau.TabIndex = 6;
            btnDoiMatKhau.Text = "Đổi mật khẩu";
            btnDoiMatKhau.Click += btnDoiMatKhau_Click;
            // 
            // DatLaiMatKhau
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(569, 628);
            Controls.Add(btnDoiMatKhau);
            Controls.Add(btnHuy);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtXacNhanMatKhauMoi);
            Controls.Add(txtMatKhauMoi);
            Controls.Add(label1);
            Name = "DatLaiMatKhau";
            Text = "Đặt lại mật khẩu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtMatKhauMoi;
        private Guna.UI2.WinForms.Guna2TextBox txtXacNhanMatKhauMoi;
        private Label label2;
        private Label label3;
        private Guna.UI2.WinForms.Guna2Button btnHuy;
        private Guna.UI2.WinForms.Guna2Button btnDoiMatKhau;
    }
}
﻿namespace MediCalendar
{
    partial class TrangChuBacSi
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrangChuBacSi));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            panel2 = new Panel();
            copyRight = new Label();
            btnDangXuat = new Guna.UI2.WinForms.Guna2Button();
            label2 = new Label();
            btnTaoLich = new Guna.UI2.WinForms.Guna2Button();
            btnLichSuHen = new Guna.UI2.WinForms.Guna2Button();
            panel3 = new Panel();
            label1 = new Label();
            btnHoSo = new Guna.UI2.WinForms.Guna2Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(pictureBox2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1673, 204);
            panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(1697, 216);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(4, 140, 212);
            panel2.Controls.Add(copyRight);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 1009);
            panel2.Name = "panel2";
            panel2.Size = new Size(1673, 83);
            panel2.TabIndex = 1;
            // 
            // copyRight
            // 
            copyRight.AutoSize = true;
            copyRight.Font = new Font("Open Sans", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            copyRight.ForeColor = Color.White;
            copyRight.Location = new Point(555, 25);
            copyRight.Name = "copyRight";
            copyRight.Size = new Size(493, 33);
            copyRight.TabIndex = 0;
            copyRight.Text = "Copyright © 2025 Vesta. All rights reserved.";
            copyRight.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnDangXuat
            // 
            btnDangXuat.BackColor = Color.Transparent;
            btnDangXuat.BorderRadius = 40;
            btnDangXuat.CustomizableEdges = customizableEdges1;
            btnDangXuat.DisabledState.BorderColor = Color.DarkGray;
            btnDangXuat.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDangXuat.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDangXuat.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDangXuat.FillColor = Color.FromArgb(240, 18, 18);
            btnDangXuat.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDangXuat.ForeColor = Color.White;
            btnDangXuat.HoverState.FillColor = Color.FromArgb(131, 5, 26);
            btnDangXuat.Location = new Point(1430, 4);
            btnDangXuat.Name = "btnDangXuat";
            btnDangXuat.PressedColor = Color.Transparent;
            btnDangXuat.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnDangXuat.Size = new Size(218, 90);
            btnDangXuat.TabIndex = 7;
            btnDangXuat.Text = "Đăng xuất";
            btnDangXuat.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SingleBitPerPixelGridFit;
            btnDangXuat.Click += btnDangXuat_Click_1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Open Sans", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(203, 384);
            label2.Name = "label2";
            label2.Size = new Size(1295, 73);
            label2.TabIndex = 3;
            label2.Text = "Vui lòng chọn dịch vụ để được phục vụ tốt nhất!";
            // 
            // btnTaoLich
            // 
            btnTaoLich.BackColor = Color.Transparent;
            btnTaoLich.BorderRadius = 34;
            btnTaoLich.CustomizableEdges = customizableEdges3;
            btnTaoLich.DisabledState.BorderColor = Color.DarkGray;
            btnTaoLich.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTaoLich.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTaoLich.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTaoLich.FillColor = Color.FromArgb(4, 140, 212);
            btnTaoLich.Font = new Font("Open Sans", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTaoLich.ForeColor = Color.White;
            btnTaoLich.Location = new Point(647, 580);
            btnTaoLich.Name = "btnTaoLich";
            btnTaoLich.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnTaoLich.Size = new Size(385, 212);
            btnTaoLich.TabIndex = 5;
            btnTaoLich.Text = "Tạo lịch";
            btnTaoLich.Click += btnTaoLich_Click;
            // 
            // btnLichSuHen
            // 
            btnLichSuHen.BackColor = Color.Transparent;
            btnLichSuHen.BorderRadius = 34;
            btnLichSuHen.CustomizableEdges = customizableEdges5;
            btnLichSuHen.DisabledState.BorderColor = Color.DarkGray;
            btnLichSuHen.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLichSuHen.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLichSuHen.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLichSuHen.FillColor = Color.FromArgb(4, 140, 212);
            btnLichSuHen.Font = new Font("Open Sans", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLichSuHen.ForeColor = Color.White;
            btnLichSuHen.Location = new Point(1113, 580);
            btnLichSuHen.Name = "btnLichSuHen";
            btnLichSuHen.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnLichSuHen.Size = new Size(385, 212);
            btnLichSuHen.TabIndex = 6;
            btnLichSuHen.Text = "Lịch sử hẹn";
            btnLichSuHen.Click += btnLichSuHen_Click;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(4, 140, 212);
            panel3.BorderStyle = BorderStyle.Fixed3D;
            panel3.Controls.Add(label1);
            panel3.Controls.Add(btnDangXuat);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 204);
            panel3.Name = "panel3";
            panel3.Size = new Size(1673, 101);
            panel3.TabIndex = 8;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Open Sans", 13.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.WhiteSmoke;
            label1.Location = new Point(44, 20);
            label1.Name = "label1";
            label1.Size = new Size(315, 51);
            label1.TabIndex = 8;
            label1.Text = "Xin chào, bác sĩ!";
            // 
            // btnHoSo
            // 
            btnHoSo.BackColor = Color.Transparent;
            btnHoSo.BorderRadius = 34;
            btnHoSo.CustomizableEdges = customizableEdges7;
            btnHoSo.DisabledState.BorderColor = Color.DarkGray;
            btnHoSo.DisabledState.CustomBorderColor = Color.DarkGray;
            btnHoSo.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnHoSo.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnHoSo.FillColor = Color.FromArgb(4, 140, 212);
            btnHoSo.Font = new Font("Open Sans", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHoSo.ForeColor = Color.White;
            btnHoSo.Location = new Point(179, 580);
            btnHoSo.Name = "btnHoSo";
            btnHoSo.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnHoSo.Size = new Size(385, 212);
            btnHoSo.TabIndex = 9;
            btnHoSo.Text = "Hồ sơ";
            btnHoSo.UseTransparentBackground = true;
            btnHoSo.Click += btnHoSo_Click;
            // 
            // TrangChuBacSi
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(240, 240, 240);
            ClientSize = new Size(1673, 1092);
            Controls.Add(btnHoSo);
            Controls.Add(panel3);
            Controls.Add(btnLichSuHen);
            Controls.Add(btnTaoLich);
            Controls.Add(label2);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "TrangChuBacSi";
            Text = "MediCalendar - Bác sĩ - Trang chủ";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel1;
        private Panel panel2;
        private Label copyRight;
        private Label label2;
        private Guna.UI2.WinForms.Guna2Button btnTaoLich;
        private Guna.UI2.WinForms.Guna2Button btnLichSuHen;
        private Guna.UI2.WinForms.Guna2Button btnDangXuat;
        private Panel panel3;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Button btnHoSo;
        private PictureBox pictureBox2;
    }
}

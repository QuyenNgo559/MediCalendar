﻿namespace MediCalendar
{
    partial class FormThongBao
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label1 = new Label();
            label2 = new Label();
            btnTrangChu = new Guna.UI2.WinForms.Guna2Button();
            btnDangNhap = new Guna.UI2.WinForms.Guna2Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Open Sans", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 22);
            label1.Name = "label1";
            label1.Size = new Size(647, 59);
            label1.TabIndex = 0;
            label1.Text = "Đặt lại mật khẩu thành công!";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(93, 109);
            label2.Name = "label2";
            label2.Size = new Size(454, 37);
            label2.TabIndex = 1;
            label2.Text = "Mật khẩu mới đã được thiết lập!";
            // 
            // btnTrangChu
            // 
            btnTrangChu.BorderRadius = 50;
            btnTrangChu.CustomizableEdges = customizableEdges1;
            btnTrangChu.DisabledState.BorderColor = Color.DarkGray;
            btnTrangChu.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTrangChu.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTrangChu.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTrangChu.FillColor = Color.FromArgb(240, 18, 18);
            btnTrangChu.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTrangChu.ForeColor = Color.White;
            btnTrangChu.Location = new Point(25, 180);
            btnTrangChu.Name = "btnTrangChu";
            btnTrangChu.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnTrangChu.Size = new Size(266, 73);
            btnTrangChu.TabIndex = 2;
            btnTrangChu.Text = "Trang chủ";
            btnTrangChu.Click += btnTrangChu_Click;
            // 
            // btnDangNhap
            // 
            btnDangNhap.BorderRadius = 50;
            btnDangNhap.CustomizableEdges = customizableEdges3;
            btnDangNhap.DisabledState.BorderColor = Color.DarkGray;
            btnDangNhap.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDangNhap.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDangNhap.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDangNhap.FillColor = Color.FromArgb(4, 140, 212);
            btnDangNhap.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDangNhap.ForeColor = Color.White;
            btnDangNhap.Location = new Point(297, 180);
            btnDangNhap.Name = "btnDangNhap";
            btnDangNhap.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnDangNhap.Size = new Size(324, 73);
            btnDangNhap.TabIndex = 3;
            btnDangNhap.Text = "Đăng nhập";
            btnDangNhap.Click += btnDangNhap_Click;
            // 
            // FormThongBao
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(658, 310);
            Controls.Add(btnDangNhap);
            Controls.Add(btnTrangChu);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "FormThongBao";
            Text = "Đặt lại mật khẩu thành công!";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Guna.UI2.WinForms.Guna2Button btnTrangChu;
        private Guna.UI2.WinForms.Guna2Button btnDangNhap;
    }
}
﻿namespace MediCalendar
{
    partial class TrangHoSo
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrangHoSo));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges17 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges18 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            panel2 = new Panel();
            copyRight = new Label();
            panel3 = new Panel();
            btnTaoPhieuKham = new Guna.UI2.WinForms.Guna2Button();
            btnLichSuKham = new Guna.UI2.WinForms.Guna2Button();
            btnTrangChu = new Guna.UI2.WinForms.Guna2Button();
            label1 = new Label();
            btnDangXuat = new Guna.UI2.WinForms.Guna2Button();
            guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            txtTenDangNhap = new Guna.UI2.WinForms.Guna2TextBox();
            txtChuyenKhoa = new Guna.UI2.WinForms.Guna2TextBox();
            txtHoVaTen = new Guna.UI2.WinForms.Guna2TextBox();
            guna2ShadowPanel2 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            txtGhiChu = new Guna.UI2.WinForms.Guna2TextBox();
            label5 = new Label();
            clickQuenMatKhau = new Label();
            btnTroLai = new Guna.UI2.WinForms.Guna2Button();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            guna2ShadowPanel1.SuspendLayout();
            guna2ShadowPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(pictureBox2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1667, 204);
            panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(-15, -6);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(1697, 216);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(4, 140, 212);
            panel2.Controls.Add(copyRight);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 979);
            panel2.Name = "panel2";
            panel2.Size = new Size(1667, 83);
            panel2.TabIndex = 1;
            // 
            // copyRight
            // 
            copyRight.AutoSize = true;
            copyRight.Font = new Font("Open Sans", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            copyRight.ForeColor = Color.White;
            copyRight.Location = new Point(552, 26);
            copyRight.Name = "copyRight";
            copyRight.Size = new Size(493, 33);
            copyRight.TabIndex = 0;
            copyRight.Text = "Copyright © 2025 Vesta. All rights reserved.";
            copyRight.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(4, 140, 212);
            panel3.Controls.Add(btnTaoPhieuKham);
            panel3.Controls.Add(btnLichSuKham);
            panel3.Controls.Add(btnTrangChu);
            panel3.Controls.Add(label1);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 204);
            panel3.Name = "panel3";
            panel3.Size = new Size(1667, 104);
            panel3.TabIndex = 7;
            // 
            // btnTaoPhieuKham
            // 
            btnTaoPhieuKham.BorderRadius = 11;
            btnTaoPhieuKham.CustomizableEdges = customizableEdges1;
            btnTaoPhieuKham.DisabledState.BorderColor = Color.DarkGray;
            btnTaoPhieuKham.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTaoPhieuKham.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTaoPhieuKham.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTaoPhieuKham.FillColor = Color.WhiteSmoke;
            btnTaoPhieuKham.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTaoPhieuKham.ForeColor = Color.FromArgb(35, 35, 35);
            btnTaoPhieuKham.Location = new Point(1397, 22);
            btnTaoPhieuKham.Name = "btnTaoPhieuKham";
            btnTaoPhieuKham.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnTaoPhieuKham.Size = new Size(249, 55);
            btnTaoPhieuKham.TabIndex = 12;
            btnTaoPhieuKham.Text = "Tạo phiếu khám";
            // 
            // btnLichSuKham
            // 
            btnLichSuKham.BorderRadius = 11;
            btnLichSuKham.CustomizableEdges = customizableEdges3;
            btnLichSuKham.DisabledState.BorderColor = Color.DarkGray;
            btnLichSuKham.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLichSuKham.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLichSuKham.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLichSuKham.FillColor = Color.WhiteSmoke;
            btnLichSuKham.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLichSuKham.ForeColor = Color.FromArgb(35, 35, 35);
            btnLichSuKham.Location = new Point(1109, 22);
            btnLichSuKham.Name = "btnLichSuKham";
            btnLichSuKham.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnLichSuKham.Size = new Size(239, 55);
            btnLichSuKham.TabIndex = 11;
            btnLichSuKham.Text = "Lịch sử khám";
            btnLichSuKham.Click += btnLichSuKham_Click;
            // 
            // btnTrangChu
            // 
            btnTrangChu.BorderRadius = 11;
            btnTrangChu.CustomizableEdges = customizableEdges5;
            btnTrangChu.DisabledState.BorderColor = Color.DarkGray;
            btnTrangChu.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTrangChu.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTrangChu.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTrangChu.FillColor = Color.WhiteSmoke;
            btnTrangChu.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTrangChu.ForeColor = Color.FromArgb(35, 35, 35);
            btnTrangChu.Location = new Point(825, 22);
            btnTrangChu.Name = "btnTrangChu";
            btnTrangChu.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnTrangChu.Size = new Size(239, 55);
            btnTrangChu.TabIndex = 10;
            btnTrangChu.Text = "Trang chủ";
            btnTrangChu.Click += btnTrangChu_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Open Sans", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(55, 22);
            label1.Name = "label1";
            label1.Size = new Size(408, 59);
            label1.TabIndex = 9;
            label1.Text = "Thông tin cá nhân";
            // 
            // btnDangXuat
            // 
            btnDangXuat.BackColor = Color.Transparent;
            btnDangXuat.BorderRadius = 50;
            btnDangXuat.CustomizableEdges = customizableEdges7;
            btnDangXuat.DisabledState.BorderColor = Color.DarkGray;
            btnDangXuat.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDangXuat.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDangXuat.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDangXuat.FillColor = Color.FromArgb(240, 18, 18);
            btnDangXuat.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDangXuat.ForeColor = Color.White;
            btnDangXuat.Location = new Point(1383, 860);
            btnDangXuat.Name = "btnDangXuat";
            btnDangXuat.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnDangXuat.Size = new Size(263, 95);
            btnDangXuat.TabIndex = 8;
            btnDangXuat.Text = "Đăng xuất";
            btnDangXuat.Click += btnDangXuat_Click;
            // 
            // guna2ShadowPanel1
            // 
            guna2ShadowPanel1.BackColor = Color.Transparent;
            guna2ShadowPanel1.Controls.Add(label4);
            guna2ShadowPanel1.Controls.Add(label3);
            guna2ShadowPanel1.Controls.Add(label2);
            guna2ShadowPanel1.Controls.Add(txtTenDangNhap);
            guna2ShadowPanel1.Controls.Add(txtChuyenKhoa);
            guna2ShadowPanel1.Controls.Add(txtHoVaTen);
            guna2ShadowPanel1.FillColor = Color.White;
            guna2ShadowPanel1.Location = new Point(25, 335);
            guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            guna2ShadowPanel1.Radius = 30;
            guna2ShadowPanel1.ShadowColor = Color.Black;
            guna2ShadowPanel1.Size = new Size(557, 620);
            guna2ShadowPanel1.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Open Sans", 13.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(61, 403);
            label4.Name = "label4";
            label4.Size = new Size(293, 51);
            label4.TabIndex = 5;
            label4.Text = "Tên đăng nhập";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Open Sans", 13.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(61, 227);
            label3.Name = "label3";
            label3.Size = new Size(263, 51);
            label3.TabIndex = 4;
            label3.Text = "Chuyên khoa";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Open Sans", 13.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(61, 34);
            label2.Name = "label2";
            label2.Size = new Size(198, 51);
            label2.TabIndex = 3;
            label2.Text = "Họ và tên";
            // 
            // txtTenDangNhap
            // 
            txtTenDangNhap.BorderRadius = 50;
            txtTenDangNhap.CustomizableEdges = customizableEdges9;
            txtTenDangNhap.DefaultText = "";
            txtTenDangNhap.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtTenDangNhap.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtTenDangNhap.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtTenDangNhap.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtTenDangNhap.FillColor = Color.WhiteSmoke;
            txtTenDangNhap.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtTenDangNhap.Font = new Font("Segoe UI", 9F);
            txtTenDangNhap.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtTenDangNhap.Location = new Point(25, 460);
            txtTenDangNhap.Margin = new Padding(6, 6, 6, 6);
            txtTenDangNhap.Name = "txtTenDangNhap";
            txtTenDangNhap.PlaceholderText = "";
            txtTenDangNhap.ReadOnly = true;
            txtTenDangNhap.SelectedText = "";
            txtTenDangNhap.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtTenDangNhap.Size = new Size(507, 103);
            txtTenDangNhap.TabIndex = 2;
            // 
            // txtChuyenKhoa
            // 
            txtChuyenKhoa.BorderRadius = 50;
            txtChuyenKhoa.CustomizableEdges = customizableEdges11;
            txtChuyenKhoa.DefaultText = "";
            txtChuyenKhoa.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtChuyenKhoa.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtChuyenKhoa.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtChuyenKhoa.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtChuyenKhoa.FillColor = Color.WhiteSmoke;
            txtChuyenKhoa.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtChuyenKhoa.Font = new Font("Segoe UI", 9F);
            txtChuyenKhoa.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtChuyenKhoa.Location = new Point(25, 284);
            txtChuyenKhoa.Margin = new Padding(6, 6, 6, 6);
            txtChuyenKhoa.Name = "txtChuyenKhoa";
            txtChuyenKhoa.PlaceholderText = "";
            txtChuyenKhoa.ReadOnly = true;
            txtChuyenKhoa.SelectedText = "";
            txtChuyenKhoa.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtChuyenKhoa.Size = new Size(507, 103);
            txtChuyenKhoa.TabIndex = 1;
            // 
            // txtHoVaTen
            // 
            txtHoVaTen.BorderRadius = 50;
            txtHoVaTen.CustomizableEdges = customizableEdges13;
            txtHoVaTen.DefaultText = "";
            txtHoVaTen.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtHoVaTen.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtHoVaTen.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtHoVaTen.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtHoVaTen.FillColor = Color.WhiteSmoke;
            txtHoVaTen.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtHoVaTen.Font = new Font("Segoe UI", 9F);
            txtHoVaTen.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtHoVaTen.Location = new Point(30, 98);
            txtHoVaTen.Margin = new Padding(6, 6, 6, 6);
            txtHoVaTen.Name = "txtHoVaTen";
            txtHoVaTen.PlaceholderText = "";
            txtHoVaTen.ReadOnly = true;
            txtHoVaTen.SelectedText = "";
            txtHoVaTen.ShadowDecoration.CustomizableEdges = customizableEdges14;
            txtHoVaTen.Size = new Size(507, 103);
            txtHoVaTen.TabIndex = 0;
            // 
            // guna2ShadowPanel2
            // 
            guna2ShadowPanel2.BackColor = Color.Transparent;
            guna2ShadowPanel2.Controls.Add(txtGhiChu);
            guna2ShadowPanel2.Controls.Add(label5);
            guna2ShadowPanel2.FillColor = Color.White;
            guna2ShadowPanel2.Location = new Point(613, 335);
            guna2ShadowPanel2.Name = "guna2ShadowPanel2";
            guna2ShadowPanel2.Radius = 30;
            guna2ShadowPanel2.ShadowColor = Color.Black;
            guna2ShadowPanel2.Size = new Size(1033, 517);
            guna2ShadowPanel2.TabIndex = 9;
            // 
            // txtGhiChu
            // 
            txtGhiChu.BorderRadius = 11;
            txtGhiChu.CustomizableEdges = customizableEdges15;
            txtGhiChu.DefaultText = "";
            txtGhiChu.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtGhiChu.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtGhiChu.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtGhiChu.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtGhiChu.FillColor = Color.WhiteSmoke;
            txtGhiChu.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtGhiChu.Font = new Font("Segoe UI", 9F);
            txtGhiChu.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtGhiChu.Location = new Point(53, 120);
            txtGhiChu.Margin = new Padding(6, 6, 6, 6);
            txtGhiChu.Name = "txtGhiChu";
            txtGhiChu.PlaceholderText = "";
            txtGhiChu.SelectedText = "";
            txtGhiChu.ShadowDecoration.CustomizableEdges = customizableEdges16;
            txtGhiChu.Size = new Size(932, 357);
            txtGhiChu.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Open Sans", 13.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(57, 34);
            label5.Name = "label5";
            label5.Size = new Size(161, 51);
            label5.TabIndex = 6;
            label5.Text = "Ghi chú";
            // 
            // clickQuenMatKhau
            // 
            clickQuenMatKhau.AutoSize = true;
            clickQuenMatKhau.Font = new Font("Open Sans", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            clickQuenMatKhau.Location = new Point(853, 901);
            clickQuenMatKhau.Name = "clickQuenMatKhau";
            clickQuenMatKhau.Size = new Size(250, 43);
            clickQuenMatKhau.TabIndex = 10;
            clickQuenMatKhau.Text = "Quên mật khẩu?";
            clickQuenMatKhau.Click += clickQuenMatKhau_Click;
            // 
            // btnTroLai
            // 
            btnTroLai.BackColor = Color.Transparent;
            btnTroLai.BorderRadius = 50;
            btnTroLai.CustomizableEdges = customizableEdges17;
            btnTroLai.DisabledState.BorderColor = Color.DarkGray;
            btnTroLai.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTroLai.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTroLai.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTroLai.FillColor = Color.FromArgb(4, 140, 212);
            btnTroLai.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTroLai.ForeColor = Color.White;
            btnTroLai.Location = new Point(1109, 860);
            btnTroLai.Name = "btnTroLai";
            btnTroLai.ShadowDecoration.CustomizableEdges = customizableEdges18;
            btnTroLai.Size = new Size(263, 95);
            btnTroLai.TabIndex = 11;
            btnTroLai.Text = "Trở lại";
            btnTroLai.Click += btnTroLai_Click;
            // 
            // TrangHoSo
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(240, 240, 240);
            ClientSize = new Size(1667, 1062);
            Controls.Add(btnTroLai);
            Controls.Add(clickQuenMatKhau);
            Controls.Add(guna2ShadowPanel2);
            Controls.Add(guna2ShadowPanel1);
            Controls.Add(panel3);
            Controls.Add(btnDangXuat);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "TrangHoSo";
            Text = "MediCalendar - Bác sĩ - Hồ sơ";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            guna2ShadowPanel1.ResumeLayout(false);
            guna2ShadowPanel1.PerformLayout();
            guna2ShadowPanel2.ResumeLayout(false);
            guna2ShadowPanel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel1;
        private Panel panel2;
        private Label copyRight;
        private Panel panel3;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Button btnDangXuat;
        private Guna.UI2.WinForms.Guna2Button btnTaoPhieuKham;
        private Guna.UI2.WinForms.Guna2Button btnLichSuKham;
        private Guna.UI2.WinForms.Guna2Button btnTrangChu;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Label label3;
        private Label label2;
        private Guna.UI2.WinForms.Guna2TextBox txtTenDangNhap;
        private Guna.UI2.WinForms.Guna2TextBox txtChuyenKhoa;
        private Guna.UI2.WinForms.Guna2TextBox txtHoVaTen;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel2;
        private Label label4;
        private Guna.UI2.WinForms.Guna2TextBox txtGhiChu;
        private Label label5;
        private Label clickQuenMatKhau;
        private Guna.UI2.WinForms.Guna2Button btnTroLai;
        private PictureBox pictureBox2;
    }
}

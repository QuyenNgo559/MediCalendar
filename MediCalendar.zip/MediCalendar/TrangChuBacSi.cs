﻿namespace MediCalendar
{
    public partial class TrangChuBacSi : Form
    {
        public TrangChuBacSi()
        {
            InitializeComponent();
        }

        private void btnDangXuat_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Bạn đã đăng xuất!", "Thông báo");
            this.Hide();
            TrangChu trangChu = new TrangChu();
            trangChu.ShowDialog();
            this.Close();
        }

        private void btnHoSo_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrangHoSo trangHoSo = new TrangHoSo();
            trangHoSo.ShowDialog();
            this.Show();
        }

        private void btnTaoLich_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTaoPhieuKham formTaoPhieuKham = new FormTaoPhieuKham();
            formTaoPhieuKham.ShowDialog();
            this.Show();
        }

        private void btnLichSuHen_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrangLichSuHen trangLichSuHen = new TrangLichSuHen();
            trangLichSuHen.ShowDialog();
            this.Show();
        }

        private void btnDangXuat_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            TrangChu trangChu = new TrangChu(); 
            trangChu.ShowDialog();
            this.Close();
        }
    }
}

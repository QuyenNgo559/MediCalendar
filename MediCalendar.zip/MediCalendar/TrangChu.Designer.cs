﻿namespace MediCalendar
{
    partial class TrangChu
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges13 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges14 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges15 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges16 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrangChu));
            panel1 = new Panel();
            panel2 = new Panel();
            copyRight = new Label();
            label1 = new Label();
            label2 = new Label();
            btnDangNhap = new Guna.UI2.WinForms.Guna2Button();
            btnDatLich = new Guna.UI2.WinForms.Guna2Button();
            btnLichSuHen = new Guna.UI2.WinForms.Guna2Button();
            btnDangXuat = new Guna.UI2.WinForms.Guna2Button();
            panel3 = new Panel();
            pictureBox2 = new PictureBox();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(pictureBox2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1673, 204);
            panel1.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(4, 140, 212);
            panel2.Controls.Add(copyRight);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 1009);
            panel2.Name = "panel2";
            panel2.Size = new Size(1673, 83);
            panel2.TabIndex = 1;
            // 
            // copyRight
            // 
            copyRight.AutoSize = true;
            copyRight.Font = new Font("Open Sans", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            copyRight.ForeColor = Color.White;
            copyRight.Location = new Point(585, 26);
            copyRight.Name = "copyRight";
            copyRight.RightToLeft = RightToLeft.Yes;
            copyRight.Size = new Size(493, 33);
            copyRight.TabIndex = 0;
            copyRight.Text = "Copyright © 2025 Vesta. All rights reserved.";
            copyRight.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.None;
            label1.Font = new Font("Open Sans ExtraBold", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(240, 240, 240);
            label1.Location = new Point(67, 3);
            label1.Name = "label1";
            label1.Size = new Size(1577, 103);
            label1.TabIndex = 3;
            label1.Text = "Chào mừng đến với hệ thống đặt lịch khám trực tuyến!";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Open Sans", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(203, 384);
            label2.Name = "label2";
            label2.Size = new Size(1295, 73);
            label2.TabIndex = 3;
            label2.Text = "Vui lòng chọn dịch vụ để được phục vụ tốt nhất!";
            // 
            // btnDangNhap
            // 
            btnDangNhap.BackColor = Color.Transparent;
            btnDangNhap.BorderRadius = 34;
            btnDangNhap.CustomizableEdges = customizableEdges9;
            btnDangNhap.DisabledState.BorderColor = Color.DarkGray;
            btnDangNhap.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDangNhap.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDangNhap.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDangNhap.FillColor = Color.FromArgb(4, 140, 212);
            btnDangNhap.Font = new Font("Open Sans", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDangNhap.ForeColor = Color.White;
            btnDangNhap.Location = new Point(184, 580);
            btnDangNhap.Name = "btnDangNhap";
            btnDangNhap.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnDangNhap.Size = new Size(385, 212);
            btnDangNhap.TabIndex = 4;
            btnDangNhap.Text = "Đăng nhập";
            btnDangNhap.Click += btnDangNhap_Click;
            // 
            // btnDatLich
            // 
            btnDatLich.BackColor = Color.Transparent;
            btnDatLich.BorderRadius = 34;
            btnDatLich.CustomizableEdges = customizableEdges11;
            btnDatLich.DisabledState.BorderColor = Color.DarkGray;
            btnDatLich.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDatLich.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDatLich.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDatLich.FillColor = Color.FromArgb(4, 140, 212);
            btnDatLich.Font = new Font("Open Sans", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDatLich.ForeColor = Color.White;
            btnDatLich.Location = new Point(647, 580);
            btnDatLich.Name = "btnDatLich";
            btnDatLich.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnDatLich.Size = new Size(385, 212);
            btnDatLich.TabIndex = 5;
            btnDatLich.Text = "Đặt lịch";
            btnDatLich.Click += btnDatLich_Click;
            // 
            // btnLichSuHen
            // 
            btnLichSuHen.BackColor = Color.Transparent;
            btnLichSuHen.BorderRadius = 34;
            btnLichSuHen.CustomizableEdges = customizableEdges13;
            btnLichSuHen.DisabledState.BorderColor = Color.DarkGray;
            btnLichSuHen.DisabledState.CustomBorderColor = Color.DarkGray;
            btnLichSuHen.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnLichSuHen.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnLichSuHen.FillColor = Color.FromArgb(4, 140, 212);
            btnLichSuHen.Font = new Font("Open Sans", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLichSuHen.ForeColor = Color.White;
            btnLichSuHen.Location = new Point(1113, 580);
            btnLichSuHen.Name = "btnLichSuHen";
            btnLichSuHen.ShadowDecoration.CustomizableEdges = customizableEdges14;
            btnLichSuHen.Size = new Size(385, 212);
            btnLichSuHen.TabIndex = 6;
            btnLichSuHen.Text = "Lịch sử hẹn";
            btnLichSuHen.Click += btnLichSuHen_Click_1;
            // 
            // btnDangXuat
            // 
            btnDangXuat.BackColor = Color.Transparent;
            btnDangXuat.BorderRadius = 40;
            btnDangXuat.CustomizableEdges = customizableEdges15;
            btnDangXuat.DisabledState.BorderColor = Color.DarkGray;
            btnDangXuat.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDangXuat.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDangXuat.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDangXuat.FillColor = Color.FromArgb(240, 18, 18);
            btnDangXuat.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDangXuat.ForeColor = Color.White;
            btnDangXuat.Location = new Point(1443, 18);
            btnDangXuat.Name = "btnDangXuat";
            btnDangXuat.PressedColor = Color.Transparent;
            btnDangXuat.ShadowDecoration.CustomizableEdges = customizableEdges16;
            btnDangXuat.Size = new Size(218, 68);
            btnDangXuat.TabIndex = 7;
            btnDangXuat.Text = "Đăng xuất";
            btnDangXuat.TextRenderingHint = System.Drawing.Text.TextRenderingHint.SingleBitPerPixelGridFit;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(4, 140, 212);
            panel3.Controls.Add(label1);
            panel3.Controls.Add(btnDangXuat);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 204);
            panel3.Name = "panel3";
            panel3.Size = new Size(1673, 111);
            panel3.TabIndex = 8;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(1697, 216);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // TrangChu
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(240, 240, 240);
            ClientSize = new Size(1673, 1092);
            Controls.Add(panel3);
            Controls.Add(btnLichSuHen);
            Controls.Add(btnDatLich);
            Controls.Add(btnDangNhap);
            Controls.Add(label2);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "TrangChu";
            Text = "Trang chủ - MediCalendar";
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel1;
        private Panel panel2;
        private Label copyRight;
        private Label label1;
        private Label label2;
        private Guna.UI2.WinForms.Guna2Button btnDangNhap;
        private Guna.UI2.WinForms.Guna2Button btnDatLich;
        private Guna.UI2.WinForms.Guna2Button btnLichSuHen;
        private Guna.UI2.WinForms.Guna2Button btnDangXuat;
        private Panel panel3;
        private PictureBox pictureBox2;
    }
}

﻿namespace MediCalendar
{
    public partial class TrangChu : Form
    {
        public TrangChu()
        {
            InitializeComponent();
            btnDangXuat.Visible = false;
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormDangNhap f = new FormDangNhap();
            f.ShowDialog();
            this.Close();
        }

        private void btnDatLich_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Vui lòng đăng nhập để sử dụng tính năng này!", "Thông báo");
        }

        private void btnLichSuHen_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Vui lòng đăng nhập để sử dụng tính năng này!", "Thông báo");

        }
    }
}

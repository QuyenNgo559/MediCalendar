﻿namespace MediCalendar
{
    partial class KetQuaKham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges27 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges28 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges21 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges22 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges23 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges24 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges25 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges26 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges39 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges40 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges29 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges30 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges31 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges32 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges33 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges34 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges35 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges36 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges37 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges38 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            label1 = new Label();
            panel2 = new Panel();
            guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            txtNguoiBenh = new Guna.UI2.WinForms.Guna2TextBox();
            txtGioKham = new Guna.UI2.WinForms.Guna2TextBox();
            txtNgayKham = new Guna.UI2.WinForms.Guna2TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            guna2CustomGradientPanel2 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            cbNgoaiTru = new CheckBox();
            cbNoiTru = new CheckBox();
            btnChinhSua = new Guna.UI2.WinForms.Guna2Button();
            btnTroLai = new Guna.UI2.WinForms.Guna2Button();
            txtDonThuoc = new Guna.UI2.WinForms.Guna2TextBox();
            label8 = new Label();
            label7 = new Label();
            txtChanDoan = new Guna.UI2.WinForms.Guna2TextBox();
            label6 = new Label();
            label5 = new Label();
            txtKhoa = new Guna.UI2.WinForms.Guna2TextBox();
            copyRight = new Label();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            guna2CustomGradientPanel1.SuspendLayout();
            guna2CustomGradientPanel2.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(4, 140, 212);
            panel1.Controls.Add(label1);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1476, 109);
            panel1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Open Sans", 19.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.White;
            label1.Location = new Point(510, 19);
            label1.Name = "label1";
            label1.Size = new Size(402, 73);
            label1.TabIndex = 0;
            label1.Text = "Kết quả khám";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(4, 140, 212);
            panel2.Controls.Add(copyRight);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 830);
            panel2.Name = "panel2";
            panel2.Size = new Size(1476, 70);
            panel2.TabIndex = 1;
            // 
            // guna2CustomGradientPanel1
            // 
            guna2CustomGradientPanel1.BorderRadius = 30;
            guna2CustomGradientPanel1.Controls.Add(txtNguoiBenh);
            guna2CustomGradientPanel1.Controls.Add(txtGioKham);
            guna2CustomGradientPanel1.Controls.Add(txtNgayKham);
            guna2CustomGradientPanel1.Controls.Add(label4);
            guna2CustomGradientPanel1.Controls.Add(label3);
            guna2CustomGradientPanel1.Controls.Add(label2);
            guna2CustomGradientPanel1.CustomizableEdges = customizableEdges27;
            guna2CustomGradientPanel1.Location = new Point(35, 151);
            guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            guna2CustomGradientPanel1.ShadowDecoration.CustomizableEdges = customizableEdges28;
            guna2CustomGradientPanel1.Size = new Size(417, 661);
            guna2CustomGradientPanel1.TabIndex = 2;
            // 
            // txtNguoiBenh
            // 
            txtNguoiBenh.BorderRadius = 11;
            txtNguoiBenh.CustomizableEdges = customizableEdges21;
            txtNguoiBenh.DefaultText = "";
            txtNguoiBenh.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtNguoiBenh.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtNguoiBenh.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtNguoiBenh.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtNguoiBenh.FillColor = Color.WhiteSmoke;
            txtNguoiBenh.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNguoiBenh.Font = new Font("Segoe UI", 9F);
            txtNguoiBenh.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNguoiBenh.Location = new Point(30, 461);
            txtNguoiBenh.Margin = new Padding(6, 6, 6, 6);
            txtNguoiBenh.Name = "txtNguoiBenh";
            txtNguoiBenh.PlaceholderText = "";
            txtNguoiBenh.SelectedText = "";
            txtNguoiBenh.ShadowDecoration.CustomizableEdges = customizableEdges22;
            txtNguoiBenh.Size = new Size(353, 80);
            txtNguoiBenh.TabIndex = 5;
            // 
            // txtGioKham
            // 
            txtGioKham.BorderRadius = 11;
            txtGioKham.CustomizableEdges = customizableEdges23;
            txtGioKham.DefaultText = "";
            txtGioKham.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtGioKham.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtGioKham.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtGioKham.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtGioKham.FillColor = Color.WhiteSmoke;
            txtGioKham.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtGioKham.Font = new Font("Segoe UI", 9F);
            txtGioKham.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtGioKham.Location = new Point(30, 259);
            txtGioKham.Margin = new Padding(6, 6, 6, 6);
            txtGioKham.Name = "txtGioKham";
            txtGioKham.PlaceholderText = "";
            txtGioKham.SelectedText = "";
            txtGioKham.ShadowDecoration.CustomizableEdges = customizableEdges24;
            txtGioKham.Size = new Size(353, 80);
            txtGioKham.TabIndex = 4;
            // 
            // txtNgayKham
            // 
            txtNgayKham.BorderRadius = 11;
            txtNgayKham.CustomizableEdges = customizableEdges25;
            txtNgayKham.DefaultText = "";
            txtNgayKham.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtNgayKham.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtNgayKham.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtNgayKham.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtNgayKham.FillColor = Color.WhiteSmoke;
            txtNgayKham.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNgayKham.Font = new Font("Segoe UI", 9F);
            txtNgayKham.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNgayKham.Location = new Point(30, 88);
            txtNgayKham.Margin = new Padding(6, 6, 6, 6);
            txtNgayKham.Name = "txtNgayKham";
            txtNgayKham.PlaceholderText = "";
            txtNgayKham.SelectedText = "";
            txtNgayKham.ShadowDecoration.CustomizableEdges = customizableEdges26;
            txtNgayKham.Size = new Size(353, 80);
            txtNgayKham.TabIndex = 3;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Open Sans", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(42, 380);
            label4.Name = "label4";
            label4.Size = new Size(208, 43);
            label4.TabIndex = 2;
            label4.Text = "Người bệnh";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Open Sans", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(42, 189);
            label3.Name = "label3";
            label3.Size = new Size(173, 43);
            label3.TabIndex = 1;
            label3.Text = "Giờ khám";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Open Sans", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(42, 27);
            label2.Name = "label2";
            label2.Size = new Size(199, 43);
            label2.TabIndex = 0;
            label2.Text = "Ngày khám";
            // 
            // guna2CustomGradientPanel2
            // 
            guna2CustomGradientPanel2.BorderRadius = 30;
            guna2CustomGradientPanel2.Controls.Add(cbNgoaiTru);
            guna2CustomGradientPanel2.Controls.Add(cbNoiTru);
            guna2CustomGradientPanel2.Controls.Add(btnChinhSua);
            guna2CustomGradientPanel2.Controls.Add(btnTroLai);
            guna2CustomGradientPanel2.Controls.Add(txtDonThuoc);
            guna2CustomGradientPanel2.Controls.Add(label8);
            guna2CustomGradientPanel2.Controls.Add(label7);
            guna2CustomGradientPanel2.Controls.Add(txtChanDoan);
            guna2CustomGradientPanel2.Controls.Add(label6);
            guna2CustomGradientPanel2.Controls.Add(label5);
            guna2CustomGradientPanel2.Controls.Add(txtKhoa);
            guna2CustomGradientPanel2.CustomizableEdges = customizableEdges39;
            guna2CustomGradientPanel2.Location = new Point(479, 151);
            guna2CustomGradientPanel2.Name = "guna2CustomGradientPanel2";
            guna2CustomGradientPanel2.ShadowDecoration.CustomizableEdges = customizableEdges40;
            guna2CustomGradientPanel2.Size = new Size(960, 661);
            guna2CustomGradientPanel2.TabIndex = 3;
            // 
            // cbNgoaiTru
            // 
            cbNgoaiTru.AutoSize = true;
            cbNgoaiTru.BackColor = Color.Transparent;
            cbNgoaiTru.Location = new Point(744, 93);
            cbNgoaiTru.Name = "cbNgoaiTru";
            cbNgoaiTru.Size = new Size(147, 36);
            cbNgoaiTru.TabIndex = 16;
            cbNgoaiTru.Text = "Ngoại trú";
            cbNgoaiTru.UseVisualStyleBackColor = false;
            // 
            // cbNoiTru
            // 
            cbNoiTru.AutoSize = true;
            cbNoiTru.BackColor = Color.Transparent;
            cbNoiTru.Location = new Point(601, 93);
            cbNoiTru.Name = "cbNoiTru";
            cbNoiTru.Size = new Size(121, 36);
            cbNoiTru.TabIndex = 15;
            cbNoiTru.Text = "Nội trú";
            cbNoiTru.UseVisualStyleBackColor = false;
            // 
            // btnChinhSua
            // 
            btnChinhSua.BackColor = Color.Transparent;
            btnChinhSua.BorderRadius = 50;
            btnChinhSua.CustomizableEdges = customizableEdges29;
            btnChinhSua.DisabledState.BorderColor = Color.DarkGray;
            btnChinhSua.DisabledState.CustomBorderColor = Color.DarkGray;
            btnChinhSua.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnChinhSua.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnChinhSua.FillColor = Color.FromArgb(4, 140, 121);
            btnChinhSua.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnChinhSua.ForeColor = Color.White;
            btnChinhSua.Location = new Point(372, 550);
            btnChinhSua.Name = "btnChinhSua";
            btnChinhSua.ShadowDecoration.CustomizableEdges = customizableEdges30;
            btnChinhSua.Size = new Size(260, 93);
            btnChinhSua.TabIndex = 14;
            btnChinhSua.Text = "Chỉnh sửa";
            // 
            // btnTroLai
            // 
            btnTroLai.BackColor = Color.Transparent;
            btnTroLai.BorderRadius = 50;
            btnTroLai.CustomizableEdges = customizableEdges31;
            btnTroLai.DisabledState.BorderColor = Color.DarkGray;
            btnTroLai.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTroLai.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTroLai.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTroLai.FillColor = Color.FromArgb(4, 140, 212);
            btnTroLai.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTroLai.ForeColor = Color.White;
            btnTroLai.Location = new Point(667, 550);
            btnTroLai.Name = "btnTroLai";
            btnTroLai.ShadowDecoration.CustomizableEdges = customizableEdges32;
            btnTroLai.Size = new Size(260, 93);
            btnTroLai.TabIndex = 13;
            btnTroLai.Text = "Trở lại ";
            // 
            // txtDonThuoc
            // 
            txtDonThuoc.BorderRadius = 11;
            txtDonThuoc.CustomizableEdges = customizableEdges33;
            txtDonThuoc.DefaultText = "";
            txtDonThuoc.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtDonThuoc.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtDonThuoc.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtDonThuoc.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtDonThuoc.FillColor = Color.WhiteSmoke;
            txtDonThuoc.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDonThuoc.Font = new Font("Segoe UI", 9F);
            txtDonThuoc.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtDonThuoc.Location = new Point(700, 259);
            txtDonThuoc.Margin = new Padding(6, 6, 6, 6);
            txtDonThuoc.Name = "txtDonThuoc";
            txtDonThuoc.PlaceholderText = "";
            txtDonThuoc.SelectedText = "";
            txtDonThuoc.ShadowDecoration.CustomizableEdges = customizableEdges34;
            txtDonThuoc.Size = new Size(211, 282);
            txtDonThuoc.TabIndex = 12;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Open Sans", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(715, 189);
            label8.Name = "label8";
            label8.Size = new Size(186, 43);
            label8.TabIndex = 11;
            label8.Text = "Đơn thuốc";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Open Sans", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(53, 189);
            label7.Name = "label7";
            label7.Size = new Size(189, 43);
            label7.TabIndex = 10;
            label7.Text = "Chẩn đoán";
            // 
            // txtChanDoan
            // 
            txtChanDoan.BorderRadius = 11;
            txtChanDoan.CustomizableEdges = customizableEdges35;
            txtChanDoan.DefaultText = "";
            txtChanDoan.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtChanDoan.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtChanDoan.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtChanDoan.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtChanDoan.FillColor = Color.WhiteSmoke;
            txtChanDoan.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtChanDoan.Font = new Font("Segoe UI", 9F);
            txtChanDoan.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtChanDoan.Location = new Point(31, 259);
            txtChanDoan.Margin = new Padding(6, 6, 6, 6);
            txtChanDoan.Name = "txtChanDoan";
            txtChanDoan.PlaceholderText = "";
            txtChanDoan.SelectedText = "";
            txtChanDoan.ShadowDecoration.CustomizableEdges = customizableEdges36;
            txtChanDoan.Size = new Size(624, 282);
            txtChanDoan.TabIndex = 9;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Open Sans", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(591, 36);
            label6.Name = "label6";
            label6.Size = new Size(224, 43);
            label6.TabIndex = 6;
            label6.Text = "Kiểu điều trị ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Open Sans", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(53, 27);
            label5.Name = "label5";
            label5.Size = new Size(100, 43);
            label5.TabIndex = 5;
            label5.Text = "Khoa";
            // 
            // txtKhoa
            // 
            txtKhoa.BorderRadius = 11;
            txtKhoa.CustomizableEdges = customizableEdges37;
            txtKhoa.DefaultText = "";
            txtKhoa.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtKhoa.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtKhoa.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtKhoa.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtKhoa.FillColor = Color.WhiteSmoke;
            txtKhoa.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtKhoa.Font = new Font("Segoe UI", 9F);
            txtKhoa.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtKhoa.Location = new Point(31, 88);
            txtKhoa.Margin = new Padding(6, 6, 6, 6);
            txtKhoa.Name = "txtKhoa";
            txtKhoa.PlaceholderText = "";
            txtKhoa.SelectedText = "";
            txtKhoa.ShadowDecoration.CustomizableEdges = customizableEdges38;
            txtKhoa.Size = new Size(519, 80);
            txtKhoa.TabIndex = 4;
            // 
            // copyRight
            // 
            copyRight.AutoSize = true;
            copyRight.Font = new Font("Open Sans", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            copyRight.ForeColor = Color.White;
            copyRight.Location = new Point(492, 19);
            copyRight.Name = "copyRight";
            copyRight.RightToLeft = RightToLeft.Yes;
            copyRight.Size = new Size(493, 33);
            copyRight.TabIndex = 1;
            copyRight.Text = "Copyright © 2025 Vesta. All rights reserved.";
            copyRight.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // KetQuaKham
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonFace;
            ClientSize = new Size(1476, 900);
            Controls.Add(guna2CustomGradientPanel2);
            Controls.Add(guna2CustomGradientPanel1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "KetQuaKham";
            Text = "MediCalendar - KetQuaKham";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            guna2CustomGradientPanel1.ResumeLayout(false);
            guna2CustomGradientPanel1.PerformLayout();
            guna2CustomGradientPanel2.ResumeLayout(false);
            guna2CustomGradientPanel2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Panel panel2;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel2;
        private Guna.UI2.WinForms.Guna2TextBox txtNgayKham;
        private Label label4;
        private Label label3;
        private Label label2;
        private Guna.UI2.WinForms.Guna2TextBox txtNguoiBenh;
        private Guna.UI2.WinForms.Guna2TextBox txtGioKham;
        private Guna.UI2.WinForms.Guna2Button btnTroLai;
        private Guna.UI2.WinForms.Guna2TextBox txtDonThuoc;
        private Label label8;
        private Label label7;
        private Guna.UI2.WinForms.Guna2TextBox txtChanDoan;
        private Label label6;
        private Label label5;
        private Guna.UI2.WinForms.Guna2TextBox txtKhoa;
        private Guna.UI2.WinForms.Guna2Button btnChinhSua;
        private CheckBox cbNgoaiTru;
        private CheckBox cbNoiTru;
        private Label copyRight;
    }
}
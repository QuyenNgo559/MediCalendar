﻿namespace MediCalendar
{
    partial class QuenMatKhau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            label1 = new Label();
            txtEmail = new Guna.UI2.WinForms.Guna2TextBox();
            txtMatKhauKhoiPhuc = new Guna.UI2.WinForms.Guna2TextBox();
            label2 = new Label();
            label3 = new Label();
            btnGuiYeuCau = new Guna.UI2.WinForms.Guna2Button();
            btnXacNhan = new Guna.UI2.WinForms.Guna2Button();
            label4 = new Label();
            tmrCountdown = new System.Windows.Forms.Timer(components);
            lblCountdown = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Font = new Font("Open Sans", 10.125F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(36, 96);
            label1.Name = "label1";
            label1.Size = new Size(471, 45);
            label1.TabIndex = 0;
            label1.Text = "Nhập email để nhận mã xác thực!";
            // 
            // txtEmail
            // 
            txtEmail.BorderRadius = 50;
            txtEmail.CustomizableEdges = customizableEdges1;
            txtEmail.DefaultText = "";
            txtEmail.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtEmail.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtEmail.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtEmail.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Font = new Font("Segoe UI", 9F);
            txtEmail.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtEmail.Location = new Point(36, 220);
            txtEmail.Margin = new Padding(6, 6, 6, 6);
            txtEmail.Name = "txtEmail";
            txtEmail.PlaceholderText = "";
            txtEmail.SelectedText = "";
            txtEmail.ShadowDecoration.CustomizableEdges = customizableEdges2;
            txtEmail.Size = new Size(508, 84);
            txtEmail.TabIndex = 1;
            // 
            // txtMatKhauKhoiPhuc
            // 
            txtMatKhauKhoiPhuc.BorderRadius = 50;
            txtMatKhauKhoiPhuc.CustomizableEdges = customizableEdges3;
            txtMatKhauKhoiPhuc.DefaultText = "";
            txtMatKhauKhoiPhuc.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMatKhauKhoiPhuc.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMatKhauKhoiPhuc.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMatKhauKhoiPhuc.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMatKhauKhoiPhuc.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMatKhauKhoiPhuc.Font = new Font("Segoe UI", 9F);
            txtMatKhauKhoiPhuc.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMatKhauKhoiPhuc.Location = new Point(36, 353);
            txtMatKhauKhoiPhuc.Margin = new Padding(6, 6, 6, 6);
            txtMatKhauKhoiPhuc.Name = "txtMatKhauKhoiPhuc";
            txtMatKhauKhoiPhuc.PlaceholderText = "";
            txtMatKhauKhoiPhuc.SelectedText = "";
            txtMatKhauKhoiPhuc.ShadowDecoration.CustomizableEdges = customizableEdges4;
            txtMatKhauKhoiPhuc.Size = new Size(508, 84);
            txtMatKhauKhoiPhuc.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(55, 175);
            label2.Name = "label2";
            label2.Size = new Size(105, 37);
            label2.TabIndex = 3;
            label2.Text = "Email*";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(55, 310);
            label3.Name = "label3";
            label3.Size = new Size(290, 37);
            label3.TabIndex = 4;
            label3.Text = "Mật khẩu khôi phục*";
            // 
            // btnGuiYeuCau
            // 
            btnGuiYeuCau.BorderRadius = 50;
            btnGuiYeuCau.CustomizableEdges = customizableEdges5;
            btnGuiYeuCau.DisabledState.BorderColor = Color.DarkGray;
            btnGuiYeuCau.DisabledState.CustomBorderColor = Color.DarkGray;
            btnGuiYeuCau.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnGuiYeuCau.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnGuiYeuCau.FillColor = Color.FromArgb(240, 18, 18);
            btnGuiYeuCau.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnGuiYeuCau.ForeColor = Color.White;
            btnGuiYeuCau.Location = new Point(36, 498);
            btnGuiYeuCau.Name = "btnGuiYeuCau";
            btnGuiYeuCau.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnGuiYeuCau.Size = new Size(245, 80);
            btnGuiYeuCau.TabIndex = 5;
            btnGuiYeuCau.Text = "Gửi yêu cầu";
            btnGuiYeuCau.Click += btnGuiYeuCau_Click;
            // 
            // btnXacNhan
            // 
            btnXacNhan.BorderRadius = 50;
            btnXacNhan.CustomizableEdges = customizableEdges7;
            btnXacNhan.DisabledState.BorderColor = Color.DarkGray;
            btnXacNhan.DisabledState.CustomBorderColor = Color.DarkGray;
            btnXacNhan.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnXacNhan.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnXacNhan.FillColor = Color.FromArgb(4, 140, 212);
            btnXacNhan.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXacNhan.ForeColor = Color.White;
            btnXacNhan.Location = new Point(287, 498);
            btnXacNhan.Name = "btnXacNhan";
            btnXacNhan.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnXacNhan.Size = new Size(257, 80);
            btnXacNhan.TabIndex = 6;
            btnXacNhan.Text = "Xác nhận";
            btnXacNhan.Click += btnXacNhan_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Open Sans", 13.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(125, 22);
            label4.Name = "label4";
            label4.Size = new Size(328, 51);
            label4.TabIndex = 7;
            label4.Text = "Đặt lại mật khẩu";
            // 
            // tmrCountdown
            // 
            tmrCountdown.Interval = 1000;
            tmrCountdown.Tick += tmrCountdown_Tick;
            // 
            // lblCountdown
            // 
            lblCountdown.AutoSize = true;
            lblCountdown.Location = new Point(300, 168);
            lblCountdown.Name = "lblCountdown";
            lblCountdown.Size = new Size(0, 32);
            lblCountdown.TabIndex = 8;
            // 
            // QuenMatKhau
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(569, 628);
            Controls.Add(lblCountdown);
            Controls.Add(label4);
            Controls.Add(btnXacNhan);
            Controls.Add(btnGuiYeuCau);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtMatKhauKhoiPhuc);
            Controls.Add(txtEmail);
            Controls.Add(label1);
            Name = "QuenMatKhau";
            Text = "Quên mật khẩu?";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Guna.UI2.WinForms.Guna2TextBox txtEmail;
        private Guna.UI2.WinForms.Guna2TextBox txtMatKhauKhoiPhuc;
        private Label label2;
        private Label label3;
        private Guna.UI2.WinForms.Guna2Button btnGuiYeuCau;
        private Guna.UI2.WinForms.Guna2Button btnXacNhan;
        private Label label4;
        private System.Windows.Forms.Timer tmrCountdown;
        private Label lblCountdown;
    }
}
﻿namespace MediCalendar
{
    public partial class TrangHoSo : Form
    {
        public TrangHoSo()
        {
            InitializeComponent();
        }


        private void btnDangXuat_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrangChu trangChu = new TrangChu();
            trangChu.ShowDialog();
            this.Close();
        }

        private void btnTroLai_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnTrangChu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLichSuKham_Click(object sender, EventArgs e)
        {
            this.Close();
            TrangLichSuHen trangLichSuHen = new TrangLichSuHen();
            trangLichSuHen.ShowDialog();

        }

        private void clickQuenMatKhau_Click(object sender, EventArgs e)
        {
            QuenMatKhau quenMatKhau = new QuenMatKhau();
            quenMatKhau.ShowDialog();
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediCalendar
{
    public partial class DatLaiMatKhau : Form
    {
        public DatLaiMatKhau()
        {
            InitializeComponent();
        }

        private void btnDoiMatKhau_Click(object sender, EventArgs e)
        {
            // Lấy giá trị từ hai TextBox
            string matKhauMoi = txtMatKhauMoi.Text;
            string xacNhanMatKhau = txtXacNhanMatKhauMoi.Text;

            // Kiểm tra xem người dùng đã nhập mật khẩu chưa
            if (string.IsNullOrWhiteSpace(matKhauMoi))
            {
                MessageBox.Show("Vui lòng nhập mật khẩu mới.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtMatKhauMoi.Focus(); // Di chuyển con trỏ tới ô mật khẩu mới
                return;
            }

            // So sánh hai mật khẩu
            if (matKhauMoi == xacNhanMatKhau)
            {
                // NẾU KHỚP: Đóng form hiện tại và mở form thông báo
                this.Close();
                FormThongBao formThongBao = new FormThongBao();
                formThongBao.ShowDialog();
            }
            else
            {
                // NẾU KHÔNG KHỚP: Hiển thị thông báo lỗi
                MessageBox.Show("Mật khẩu xác nhận không khớp. Vui lòng nhập lại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtXacNhanMatKhauMoi.Clear(); // Xóa ô xác nhận để người dùng nhập lại
                txtXacNhanMatKhauMoi.Focus(); // Di chuyển con trỏ tới ô xác nhận
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

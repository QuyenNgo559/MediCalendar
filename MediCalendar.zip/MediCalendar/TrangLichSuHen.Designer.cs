﻿namespace MediCalendar
{
    partial class TrangLichSuHen
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CheckedListBox clbTrangThaiKham;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrangLichSuHen));
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            panel1 = new Panel();
            pictureBox2 = new PictureBox();
            panel2 = new Panel();
            copyRight = new Label();
            panel3 = new Panel();
            btnDangXuat = new Guna.UI2.WinForms.Guna2Button();
            btnTaoPhieuKham = new Guna.UI2.WinForms.Guna2Button();
            btnHoSo = new Guna.UI2.WinForms.Guna2Button();
            btnTrangChu = new Guna.UI2.WinForms.Guna2Button();
            label1 = new Label();
            guna2ShadowPanel1 = new Guna.UI2.WinForms.Guna2ShadowPanel();
            label6 = new Label();
            label4 = new Label();
            label3 = new Label();
            cboLocTheoNguoi = new ComboBox();
            dtpLocTheoNgay = new DateTimePicker();
            label2 = new Label();
            label5 = new Label();
            dgvKetQuaTimKiem = new DataGridView();
            btnTimKiem = new Guna.UI2.WinForms.Guna2Button();
            btnXoaBoLoc = new Guna.UI2.WinForms.Guna2Button();
            clbTrangThaiKham = new CheckedListBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel2.SuspendLayout();
            panel3.SuspendLayout();
            guna2ShadowPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvKetQuaTimKiem).BeginInit();
            SuspendLayout();
            // 
            // clbTrangThaiKham
            // 
            clbTrangThaiKham.FormattingEnabled = true;
            clbTrangThaiKham.Items.AddRange(new object[] { "Đã khám", "Chưa khám" });
            clbTrangThaiKham.Location = new Point(29, 352);
            clbTrangThaiKham.Name = "clbTrangThaiKham";
            clbTrangThaiKham.Size = new Size(197, 76);
            clbTrangThaiKham.TabIndex = 10;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(pictureBox2);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1667, 204);
            panel1.TabIndex = 0;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(-15, -6);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(1697, 216);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(4, 140, 212);
            panel2.Controls.Add(copyRight);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 979);
            panel2.Name = "panel2";
            panel2.Size = new Size(1667, 83);
            panel2.TabIndex = 1;
            // 
            // copyRight
            // 
            copyRight.AutoSize = true;
            copyRight.Font = new Font("Open Sans", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            copyRight.ForeColor = Color.White;
            copyRight.Location = new Point(587, 25);
            copyRight.Name = "copyRight";
            copyRight.RightToLeft = RightToLeft.Yes;
            copyRight.Size = new Size(493, 33);
            copyRight.TabIndex = 1;
            copyRight.Text = "Copyright © 2025 Vesta. All rights reserved.";
            copyRight.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            panel3.BackColor = Color.FromArgb(4, 140, 212);
            panel3.Controls.Add(btnDangXuat);
            panel3.Controls.Add(btnTaoPhieuKham);
            panel3.Controls.Add(btnHoSo);
            panel3.Controls.Add(btnTrangChu);
            panel3.Controls.Add(label1);
            panel3.Dock = DockStyle.Top;
            panel3.Location = new Point(0, 204);
            panel3.Name = "panel3";
            panel3.Size = new Size(1667, 104);
            panel3.TabIndex = 7;
            // 
            // btnDangXuat
            // 
            btnDangXuat.BorderRadius = 11;
            btnDangXuat.CustomizableEdges = customizableEdges1;
            btnDangXuat.DisabledState.BorderColor = Color.DarkGray;
            btnDangXuat.DisabledState.CustomBorderColor = Color.DarkGray;
            btnDangXuat.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnDangXuat.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnDangXuat.FillColor = Color.FromArgb(240, 18, 18);
            btnDangXuat.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDangXuat.ForeColor = SystemColors.ButtonFace;
            btnDangXuat.Location = new Point(1376, 22);
            btnDangXuat.Name = "btnDangXuat";
            btnDangXuat.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnDangXuat.Size = new Size(249, 55);
            btnDangXuat.TabIndex = 13;
            btnDangXuat.Text = "Đăng xuất";
            // 
            // btnTaoPhieuKham
            // 
            btnTaoPhieuKham.BorderRadius = 11;
            btnTaoPhieuKham.CustomizableEdges = customizableEdges3;
            btnTaoPhieuKham.DisabledState.BorderColor = Color.DarkGray;
            btnTaoPhieuKham.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTaoPhieuKham.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTaoPhieuKham.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTaoPhieuKham.FillColor = Color.WhiteSmoke;
            btnTaoPhieuKham.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTaoPhieuKham.ForeColor = Color.FromArgb(35, 35, 35);
            btnTaoPhieuKham.Location = new Point(1082, 26);
            btnTaoPhieuKham.Name = "btnTaoPhieuKham";
            btnTaoPhieuKham.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnTaoPhieuKham.Size = new Size(249, 55);
            btnTaoPhieuKham.TabIndex = 12;
            btnTaoPhieuKham.Text = "Tạo phiếu khám";
            btnTaoPhieuKham.Click += btnTaoPhieuKham_Click;
            // 
            // btnHoSo
            // 
            btnHoSo.BorderRadius = 11;
            btnHoSo.CustomizableEdges = customizableEdges5;
            btnHoSo.DisabledState.BorderColor = Color.DarkGray;
            btnHoSo.DisabledState.CustomBorderColor = Color.DarkGray;
            btnHoSo.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnHoSo.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnHoSo.FillColor = Color.WhiteSmoke;
            btnHoSo.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnHoSo.ForeColor = Color.FromArgb(35, 35, 35);
            btnHoSo.Location = new Point(794, 26);
            btnHoSo.Name = "btnHoSo";
            btnHoSo.ShadowDecoration.CustomizableEdges = customizableEdges6;
            btnHoSo.Size = new Size(239, 55);
            btnHoSo.TabIndex = 11;
            btnHoSo.Text = "Hồ sơ";
            btnHoSo.Click += btnHoSo_Click;
            // 
            // btnTrangChu
            // 
            btnTrangChu.BorderRadius = 11;
            btnTrangChu.CustomizableEdges = customizableEdges7;
            btnTrangChu.DisabledState.BorderColor = Color.DarkGray;
            btnTrangChu.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTrangChu.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTrangChu.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTrangChu.FillColor = Color.WhiteSmoke;
            btnTrangChu.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTrangChu.ForeColor = Color.FromArgb(35, 35, 35);
            btnTrangChu.Location = new Point(510, 26);
            btnTrangChu.Name = "btnTrangChu";
            btnTrangChu.ShadowDecoration.CustomizableEdges = customizableEdges8;
            btnTrangChu.Size = new Size(239, 55);
            btnTrangChu.TabIndex = 10;
            btnTrangChu.Text = "Trang chủ";
            btnTrangChu.Click += btnTrangChu_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Open Sans", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(55, 22);
            label1.Name = "label1";
            label1.Size = new Size(403, 59);
            label1.TabIndex = 9;
            label1.Text = "Lịch sử hẹn khám";
            // 
            // guna2ShadowPanel1
            // 
            guna2ShadowPanel1.BackColor = Color.Transparent;
            guna2ShadowPanel1.Controls.Add(clbTrangThaiKham);
            guna2ShadowPanel1.Controls.Add(label6);
            guna2ShadowPanel1.Controls.Add(label4);
            guna2ShadowPanel1.Controls.Add(label3);
            guna2ShadowPanel1.Controls.Add(cboLocTheoNguoi);
            guna2ShadowPanel1.Controls.Add(dtpLocTheoNgay);
            guna2ShadowPanel1.Controls.Add(label2);
            guna2ShadowPanel1.FillColor = Color.White;
            guna2ShadowPanel1.Location = new Point(24, 327);
            guna2ShadowPanel1.Name = "guna2ShadowPanel1";
            guna2ShadowPanel1.Radius = 11;
            guna2ShadowPanel1.ShadowColor = Color.Black;
            guna2ShadowPanel1.Size = new Size(276, 458);
            guna2ShadowPanel1.TabIndex = 8;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(20, 312);
            label6.Name = "label6";
            label6.Size = new Size(155, 37);
            label6.TabIndex = 9;
            label6.Text = "Trạng thái";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(11, 209);
            label4.Name = "label4";
            label4.Size = new Size(247, 37);
            label4.TabIndex = 8;
            label4.Text = "Theo người bệnh";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(11, 110);
            label3.Name = "label3";
            label3.Size = new Size(155, 37);
            label3.TabIndex = 7;
            label3.Text = "Theo ngày";
            // 
            // cboLocTheoNguoi
            // 
            cboLocTheoNguoi.FormattingEnabled = true;
            cboLocTheoNguoi.Location = new Point(11, 258);
            cboLocTheoNguoi.Name = "cboLocTheoNguoi";
            cboLocTheoNguoi.Size = new Size(247, 40);
            cboLocTheoNguoi.TabIndex = 6;
            // 
            // dtpLocTheoNgay
            // 
            dtpLocTheoNgay.CalendarFont = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dtpLocTheoNgay.Location = new Point(11, 150);
            dtpLocTheoNgay.Name = "dtpLocTheoNgay";
            dtpLocTheoNgay.Size = new Size(247, 39);
            dtpLocTheoNgay.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Open Sans", 13.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(71, 35);
            label2.Name = "label2";
            label2.Size = new Size(133, 51);
            label2.TabIndex = 3;
            label2.Text = "Bộ lọc";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Open Sans", 13.875F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(341, 311);
            label5.Name = "label5";
            label5.Size = new Size(339, 51);
            label5.TabIndex = 6;
            label5.Text = "Kết quả tìm kiếm";
            // 
            // dgvKetQuaTimKiem
            // 
            dgvKetQuaTimKiem.BackgroundColor = Color.White;
            dgvKetQuaTimKiem.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvKetQuaTimKiem.Location = new Point(326, 369);
            dgvKetQuaTimKiem.Name = "dgvKetQuaTimKiem";
            dgvKetQuaTimKiem.RowHeadersWidth = 82;
            dgvKetQuaTimKiem.Size = new Size(1320, 586);
            dgvKetQuaTimKiem.TabIndex = 9;
            // 
            // btnTimKiem
            // 
            btnTimKiem.BorderRadius = 30;
            btnTimKiem.CustomizableEdges = customizableEdges9;
            btnTimKiem.DisabledState.BorderColor = Color.DarkGray;
            btnTimKiem.DisabledState.CustomBorderColor = Color.DarkGray;
            btnTimKiem.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnTimKiem.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnTimKiem.FillColor = Color.FromArgb(4, 140, 212);
            btnTimKiem.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTimKiem.ForeColor = Color.White;
            btnTimKiem.Location = new Point(71, 791);
            btnTimKiem.Name = "btnTimKiem";
            btnTimKiem.ShadowDecoration.CustomizableEdges = customizableEdges10;
            btnTimKiem.Size = new Size(197, 63);
            btnTimKiem.TabIndex = 4;
            btnTimKiem.Text = "Tìm kiếm";
            // 
            // btnXoaBoLoc
            // 
            btnXoaBoLoc.BorderRadius = 30;
            btnXoaBoLoc.CustomizableEdges = customizableEdges11;
            btnXoaBoLoc.DisabledState.BorderColor = Color.DarkGray;
            btnXoaBoLoc.DisabledState.CustomBorderColor = Color.DarkGray;
            btnXoaBoLoc.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnXoaBoLoc.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnXoaBoLoc.FillColor = Color.FromArgb(240, 18, 18);
            btnXoaBoLoc.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXoaBoLoc.ForeColor = Color.White;
            btnXoaBoLoc.Location = new Point(71, 877);
            btnXoaBoLoc.Name = "btnXoaBoLoc";
            btnXoaBoLoc.ShadowDecoration.CustomizableEdges = customizableEdges12;
            btnXoaBoLoc.Size = new Size(197, 63);
            btnXoaBoLoc.TabIndex = 10;
            btnXoaBoLoc.Text = "Xóa bộ lọc";
            // 
            // TrangLichSuHen
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1667, 1062);
            Controls.Add(btnXoaBoLoc);
            Controls.Add(dgvKetQuaTimKiem);
            Controls.Add(label5);
            Controls.Add(btnTimKiem);
            Controls.Add(guna2ShadowPanel1);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "TrangLichSuHen";
            Text = "MediCalendar - Bác sĩ - Lịch sử khám";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            guna2ShadowPanel1.ResumeLayout(false);
            guna2ShadowPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvKetQuaTimKiem).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Label label1;
        private Guna.UI2.WinForms.Guna2Button btnTaoPhieuKham;
        private Guna.UI2.WinForms.Guna2Button btnHoSo;
        private Guna.UI2.WinForms.Guna2Button btnTrangChu;
        private Guna.UI2.WinForms.Guna2ShadowPanel guna2ShadowPanel1;
        private Label label2;
        private Label label5;
        private DataGridView dgvKetQuaTimKiem;
        private Label label4;
        private Label label3;
        private ComboBox cboLocTheoNguoi;
        private DateTimePicker dtpLocTheoNgay;
        private Guna.UI2.WinForms.Guna2Button btnTimKiem;
        private Guna.UI2.WinForms.Guna2Button btnDangXuat;
        private Label label6;
        private Guna.UI2.WinForms.Guna2Button btnXoaBoLoc;
        private PictureBox pictureBox2;
        private Label copyRight;
    }
}

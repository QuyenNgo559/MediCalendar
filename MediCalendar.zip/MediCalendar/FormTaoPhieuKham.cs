﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediCalendar
{
    public partial class FormTaoPhieuKham : Form
    {
        public FormTaoPhieuKham()
        {
            InitializeComponent();
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtSDT_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void btnTaoPhieu_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLyDoKham.Text))
            {
                MessageBox.Show("Vui lòng nhập lý do khám.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtLyDoKham.Focus(); // Di chuyển con trỏ tới ô cần nhập
                return; // Dừng thực thi
            }

            if (string.IsNullOrWhiteSpace(txtTrieuChung.Text))
            {
                MessageBox.Show("Vui lòng nhập triệu chứng.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTrieuChung.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtChanDoan.Text))
            {
                MessageBox.Show("Vui lòng nhập chẩn đoán.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtChanDoan.Focus();
                return;
            }

            if (dtpNgayKham.Value > DateTime.Now)
            {
                MessageBox.Show("Ngày khám không được là một ngày trong tương lai.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Nếu tất cả dữ liệu đều hợp lệ
            // --> Thêm code để lưu thông tin phiếu khám vào cơ sở dữ liệu ở đây

            MessageBox.Show("Tạo phiếu khám thành công!", "Thành công");
            this.Close(); // Đóng form sau khi lưu thành công
        }
    }
}

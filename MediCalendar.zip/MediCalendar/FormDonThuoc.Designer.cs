﻿namespace MediCalendar
{
    partial class FormDonThuoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges1 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges2 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges3 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges4 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges5 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges6 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges7 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges8 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges9 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges10 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges11 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            Guna.UI2.WinForms.Suite.CustomizableEdges customizableEdges12 = new Guna.UI2.WinForms.Suite.CustomizableEdges();
            lblDonThuoc = new Label();
            btnChinhSua = new Guna.UI2.WinForms.Guna2Button();
            btnXong = new Guna.UI2.WinForms.Guna2Button();
            dgvChiTietDonThuoc = new DataGridView();
            txtMaDon = new Guna.UI2.WinForms.Guna2TextBox();
            txtNgay = new Guna.UI2.WinForms.Guna2TextBox();
            lblMaDon = new Label();
            lblNgay = new Label();
            lblNguoiBenh = new Label();
            lblTongThanhToan = new Label();
            txtNguoiBenh = new Guna.UI2.WinForms.Guna2TextBox();
            txtGhiChu = new Guna.UI2.WinForms.Guna2TextBox();
            panel1 = new Panel();
            panel2 = new Panel();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvChiTietDonThuoc).BeginInit();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // lblDonThuoc
            // 
            lblDonThuoc.AutoSize = true;
            lblDonThuoc.Font = new Font("Open Sans", 16.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDonThuoc.ForeColor = Color.WhiteSmoke;
            lblDonThuoc.Location = new Point(609, 27);
            lblDonThuoc.Name = "lblDonThuoc";
            lblDonThuoc.Size = new Size(249, 59);
            lblDonThuoc.TabIndex = 7;
            lblDonThuoc.Text = "Đơn thuốc";
            // 
            // btnChinhSua
            // 
            btnChinhSua.BorderRadius = 50;
            btnChinhSua.CustomizableEdges = customizableEdges1;
            btnChinhSua.DisabledState.BorderColor = Color.DarkGray;
            btnChinhSua.DisabledState.CustomBorderColor = Color.DarkGray;
            btnChinhSua.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnChinhSua.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnChinhSua.FillColor = Color.FromArgb(240, 18, 18);
            btnChinhSua.Font = new Font("Open Sans SemiBold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnChinhSua.ForeColor = Color.White;
            btnChinhSua.Location = new Point(485, 720);
            btnChinhSua.Name = "btnChinhSua";
            btnChinhSua.ShadowDecoration.CustomizableEdges = customizableEdges2;
            btnChinhSua.Size = new Size(237, 91);
            btnChinhSua.TabIndex = 8;
            btnChinhSua.Text = "Chỉnh sửa";
            // 
            // btnXong
            // 
            btnXong.BorderRadius = 50;
            btnXong.CustomizableEdges = customizableEdges3;
            btnXong.DisabledState.BorderColor = Color.DarkGray;
            btnXong.DisabledState.CustomBorderColor = Color.DarkGray;
            btnXong.DisabledState.FillColor = Color.FromArgb(169, 169, 169);
            btnXong.DisabledState.ForeColor = Color.FromArgb(141, 141, 141);
            btnXong.FillColor = Color.FromArgb(4, 140, 212);
            btnXong.Font = new Font("Segoe UI Semibold", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnXong.ForeColor = Color.White;
            btnXong.Location = new Point(737, 720);
            btnXong.Name = "btnXong";
            btnXong.ShadowDecoration.CustomizableEdges = customizableEdges4;
            btnXong.Size = new Size(326, 91);
            btnXong.TabIndex = 9;
            btnXong.Text = "Xong";
            // 
            // dgvChiTietDonThuoc
            // 
            dgvChiTietDonThuoc.BackgroundColor = Color.WhiteSmoke;
            dgvChiTietDonThuoc.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvChiTietDonThuoc.Location = new Point(53, 289);
            dgvChiTietDonThuoc.Name = "dgvChiTietDonThuoc";
            dgvChiTietDonThuoc.RowHeadersWidth = 82;
            dgvChiTietDonThuoc.Size = new Size(1386, 402);
            dgvChiTietDonThuoc.TabIndex = 11;
            // 
            // txtMaDon
            // 
            txtMaDon.CustomizableEdges = customizableEdges5;
            txtMaDon.DefaultText = "";
            txtMaDon.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtMaDon.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtMaDon.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtMaDon.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtMaDon.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMaDon.Font = new Font("Segoe UI", 9F);
            txtMaDon.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtMaDon.Location = new Point(182, 153);
            txtMaDon.Margin = new Padding(6, 6, 6, 6);
            txtMaDon.Name = "txtMaDon";
            txtMaDon.PlaceholderText = "";
            txtMaDon.SelectedText = "";
            txtMaDon.ShadowDecoration.CustomizableEdges = customizableEdges6;
            txtMaDon.Size = new Size(388, 51);
            txtMaDon.TabIndex = 12;
            // 
            // txtNgay
            // 
            txtNgay.CustomizableEdges = customizableEdges7;
            txtNgay.DefaultText = "";
            txtNgay.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtNgay.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtNgay.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtNgay.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtNgay.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNgay.Font = new Font("Segoe UI", 9F);
            txtNgay.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNgay.Location = new Point(182, 216);
            txtNgay.Margin = new Padding(6, 6, 6, 6);
            txtNgay.Name = "txtNgay";
            txtNgay.PlaceholderText = "";
            txtNgay.SelectedText = "";
            txtNgay.ShadowDecoration.CustomizableEdges = customizableEdges8;
            txtNgay.Size = new Size(388, 51);
            txtNgay.TabIndex = 13;
            // 
            // lblMaDon
            // 
            lblMaDon.AutoSize = true;
            lblMaDon.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMaDon.Location = new Point(54, 167);
            lblMaDon.Name = "lblMaDon";
            lblMaDon.Size = new Size(119, 37);
            lblMaDon.TabIndex = 14;
            lblMaDon.Text = "Mã đơn";
            // 
            // lblNgay
            // 
            lblNgay.AutoSize = true;
            lblNgay.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNgay.Location = new Point(54, 230);
            lblNgay.Name = "lblNgay";
            lblNgay.Size = new Size(85, 37);
            lblNgay.TabIndex = 15;
            lblNgay.Text = "Ngày";
            // 
            // lblNguoiBenh
            // 
            lblNguoiBenh.AutoSize = true;
            lblNguoiBenh.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNguoiBenh.Location = new Point(651, 167);
            lblNguoiBenh.Name = "lblNguoiBenh";
            lblNguoiBenh.Size = new Size(177, 37);
            lblNguoiBenh.TabIndex = 16;
            lblNguoiBenh.Text = "Người bệnh";
            // 
            // lblTongThanhToan
            // 
            lblTongThanhToan.AutoSize = true;
            lblTongThanhToan.Font = new Font("Open Sans", 10.125F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTongThanhToan.Location = new Point(651, 230);
            lblTongThanhToan.Name = "lblTongThanhToan";
            lblTongThanhToan.Size = new Size(120, 37);
            lblTongThanhToan.TabIndex = 17;
            lblTongThanhToan.Text = "Ghi chú";
            // 
            // txtNguoiBenh
            // 
            txtNguoiBenh.CustomizableEdges = customizableEdges9;
            txtNguoiBenh.DefaultText = "";
            txtNguoiBenh.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtNguoiBenh.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtNguoiBenh.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtNguoiBenh.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtNguoiBenh.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNguoiBenh.Font = new Font("Segoe UI", 9F);
            txtNguoiBenh.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtNguoiBenh.Location = new Point(836, 153);
            txtNguoiBenh.Margin = new Padding(6, 6, 6, 6);
            txtNguoiBenh.Name = "txtNguoiBenh";
            txtNguoiBenh.PlaceholderText = "";
            txtNguoiBenh.SelectedText = "";
            txtNguoiBenh.ShadowDecoration.CustomizableEdges = customizableEdges10;
            txtNguoiBenh.Size = new Size(603, 51);
            txtNguoiBenh.TabIndex = 18;
            // 
            // txtGhiChu
            // 
            txtGhiChu.CustomizableEdges = customizableEdges11;
            txtGhiChu.DefaultText = "";
            txtGhiChu.DisabledState.BorderColor = Color.FromArgb(208, 208, 208);
            txtGhiChu.DisabledState.FillColor = Color.FromArgb(226, 226, 226);
            txtGhiChu.DisabledState.ForeColor = Color.FromArgb(138, 138, 138);
            txtGhiChu.DisabledState.PlaceholderForeColor = Color.FromArgb(138, 138, 138);
            txtGhiChu.FocusedState.BorderColor = Color.FromArgb(94, 148, 255);
            txtGhiChu.Font = new Font("Segoe UI", 9F);
            txtGhiChu.HoverState.BorderColor = Color.FromArgb(94, 148, 255);
            txtGhiChu.Location = new Point(836, 229);
            txtGhiChu.Margin = new Padding(6, 6, 6, 6);
            txtGhiChu.Name = "txtGhiChu";
            txtGhiChu.PlaceholderText = "";
            txtGhiChu.SelectedText = "";
            txtGhiChu.ShadowDecoration.CustomizableEdges = customizableEdges12;
            txtGhiChu.Size = new Size(603, 51);
            txtGhiChu.TabIndex = 19;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(4, 140, 212);
            panel1.Controls.Add(lblDonThuoc);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1494, 109);
            panel1.TabIndex = 20;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(4, 140, 212);
            panel2.Controls.Add(label1);
            panel2.Dock = DockStyle.Bottom;
            panel2.Location = new Point(0, 833);
            panel2.Name = "panel2";
            panel2.Size = new Size(1494, 84);
            panel2.TabIndex = 21;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.WhiteSmoke;
            label1.Location = new Point(487, 28);
            label1.Name = "label1";
            label1.Size = new Size(478, 32);
            label1.TabIndex = 0;
            label1.Text = "Copyright © 2025 Vesta. All rights reserved.";
            // 
            // FormDonThuoc
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1494, 917);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(txtGhiChu);
            Controls.Add(txtNguoiBenh);
            Controls.Add(lblTongThanhToan);
            Controls.Add(lblNguoiBenh);
            Controls.Add(lblNgay);
            Controls.Add(lblMaDon);
            Controls.Add(txtNgay);
            Controls.Add(txtMaDon);
            Controls.Add(dgvChiTietDonThuoc);
            Controls.Add(btnXong);
            Controls.Add(btnChinhSua);
            Name = "FormDonThuoc";
            Text = "MediCalendar - Đơn thuốc";
            ((System.ComponentModel.ISupportInitialize)dgvChiTietDonThuoc).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblDonThuoc;
        private Guna.UI2.WinForms.Guna2Button btnChinhSua;
        private Guna.UI2.WinForms.Guna2Button btnXong;
        private DataGridView dgvChiTietDonThuoc;
        private Guna.UI2.WinForms.Guna2TextBox txtMaDon;
        private Guna.UI2.WinForms.Guna2TextBox txtNgay;
        private Label lblMaDon;
        private Label lblNgay;
        private Label lblNguoiBenh;
        private Label lblTongThanhToan;
        private Guna.UI2.WinForms.Guna2TextBox txtNguoiBenh;
        private Guna.UI2.WinForms.Guna2TextBox txtGhiChu;
        private Panel panel1;
        private Panel panel2;
        private Label label1;
    }
}
﻿namespace MediCalendar
{
    public partial class TrangLichSuHen : Form
    {
        public TrangLichSuHen()
        {
            InitializeComponent();

        }


        //private void btnDangXuat_Click_1(object sender, EventArgs e)
        //{
        //    MessageBox.Show("Đăng xuất thành công!");
        //}

        private void btnTrangChu_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnHoSo_Click(object sender, EventArgs e)
        {
            this.Hide();
            TrangHoSo trangHoSo = new TrangHoSo();
            trangHoSo.ShowDialog();
            this.Close();
        }

        private void btnTaoPhieuKham_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormTaoPhieuKham formTaoPhieuKham = new FormTaoPhieuKham();
            formTaoPhieuKham.ShowDialog();
            this.Close();
        }
    }
}

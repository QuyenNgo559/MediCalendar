﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MyHospitalApp
{
    public class datlich : Form
    {
        // Controls
        private Panel pnlHeader, pnlMenu, pnlMain, pnlDoctors;
        private PictureBox pbLogo, pbBannerImage, pbCalendarIcon;
        private Label lblHeaderTitle, lblFindDoctor, lblCurrentNumber;
        private Button btnLogout;
        private ComboBox cbSpecialty, cbExaminationTime;
        private TextBox txtFindDoctor;
        private DateTimePicker dtpDate;
        private Button btnSetAppointment;
        private Label lblCopyright;
        private FlowLayoutPanel flpDoctors;
        private Button btnLeftArrow, btnRightArrow;

        // Thêm biến để lưu thông tin bác sĩ và panel đã chọn
        private string selectedDoctorName = "";
        private Panel selectedDoctorPanel = null;

        public datlich()
        {
            this.Text = "Đặt lịch - Bệnh viện Hùng Vương";
            this.Size = new Size(1300, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Resize += new EventHandler(datlich_Resize);

            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Header Panel
            pnlHeader = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(this.Width, 120),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlHeader);

            // Logo Bệnh viện Hùng Vương
            pbLogo = new PictureBox()
            {
                // Thay đổi đường dẫn đến logo của bạn
                Image = Image.FromFile(@"D:\Dow\logo.png"),
                SizeMode = PictureBoxSizeMode.Zoom,
                Location = new Point(20, 10),
                Size = new Size(200, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbLogo);

            // Banner image
            pbBannerImage = new PictureBox()
            {
                // Thay đổi đường dẫn đến banner của bạn
                Image = Image.FromFile(@"D:\Dow\banner.png"),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Location = new Point(240, 10),
                Size = new Size(this.Width - 260, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbBannerImage);

            // Menu Panel
            pnlMenu = new Panel()
            {
                Location = new Point(0, 120),
                Size = new Size(this.Width, 60),
                BackColor = Color.FromArgb(0, 122, 204),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlMenu);

            // "Đặt lịch" Label
            lblHeaderTitle = new Label()
            {
                Text = "Đặt lịch",
                Location = new Point(20, 15),
                AutoSize = true,
                Font = new Font("Arial", 16, FontStyle.Bold),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlMenu.Controls.Add(lblHeaderTitle);

            // Menu Buttons
            Button btnHistory = CreateMenuButton("Lịch sử hẹn", new Point(pnlMenu.Width - 580, 15));
            Button btnHome = CreateMenuButton("Trang chủ", new Point(pnlMenu.Width - 430, 15));
            Button btnProfile = CreateMenuButton("Hồ sơ", new Point(pnlMenu.Width - 280, 15));
            pnlMenu.Controls.Add(btnHistory);
            pnlMenu.Controls.Add(btnHome);
            pnlMenu.Controls.Add(btnProfile);

            // Logout Button
            btnLogout = new Button()
            {
                Text = "Đăng xuất",
                Location = new Point(pnlMenu.Width - 130, 15),
                Size = new Size(120, 30),
                BackColor = Color.Red,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 10, FontStyle.Bold),
                Anchor = AnchorStyles.Right | AnchorStyles.Top
            };
            pnlMenu.Controls.Add(btnLogout);

            // Main Panel
            pnlMain = new Panel()
            {
                Location = new Point(50, 200),
                Size = new Size(this.Width - 100, this.Height - 300),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom
            };
            this.Controls.Add(pnlMain);

            // Find Doctor Section
            lblFindDoctor = CreateLabel("Tìm bác sĩ", new Point(20, 20), pnlMain);
            lblFindDoctor.Font = new Font("Arial", 14, FontStyle.Bold);

            txtFindDoctor = CreateTextBox(new Point(20, 50), pnlMain, 200);

            cbSpecialty = CreateComboBox(new Point(230, 50), pnlMain, 180);
            cbSpecialty.Items.AddRange(new string[] { "Chuyên khoa", "Tim mạch", "Nội tiết", "Da liễu" });
            cbSpecialty.SelectedIndex = 0;

            cbExaminationTime = CreateComboBox(new Point(420, 50), pnlMain, 120);
            cbExaminationTime.Items.AddRange(new string[] { "Giờ khám", "Sáng", "Chiều", "Tối" });
            cbExaminationTime.SelectedIndex = 0;

            dtpDate = new DateTimePicker()
            {
                Location = new Point(550, 50),
                Size = new Size(180, 30),
                Font = new Font("Arial", 10),
                Format = DateTimePickerFormat.Short
            };
            pnlMain.Controls.Add(dtpDate);

            btnSetAppointment = new Button()
            {
                Text = "Đặt lịch",
                Location = new Point(740, 50),
                Size = new Size(100, 30),
                BackColor = Color.Red,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 10, FontStyle.Bold)
            };
            // Thêm sự kiện click cho nút Đặt lịch
            btnSetAppointment.Click += btnSetAppointment_Click;
            pnlMain.Controls.Add(btnSetAppointment);

            // Current Number Label
            lblCurrentNumber = CreateLabel("Số hiện tại: 72", new Point(pnlMain.Width - 150, 20), pnlMain);
            lblCurrentNumber.Font = new Font("Arial", 12, FontStyle.Bold);

            // Doctor List Panel
            pnlDoctors = new Panel()
            {
                Location = new Point(0, 100),
                Size = new Size(pnlMain.Width, pnlMain.Height - 150),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom
            };
            pnlMain.Controls.Add(pnlDoctors);

            // FlowLayoutPanel for doctors
            flpDoctors = new FlowLayoutPanel()
            {
                Location = new Point(50, 20),
                Size = new Size(pnlDoctors.Width - 100, pnlDoctors.Height - 40),
                Anchor = AnchorStyles.None,
                AutoScroll = true
            };
            pnlDoctors.Controls.Add(flpDoctors);
            AddDoctorCards();

            // Navigation Arrows
            btnLeftArrow = new Button()
            {
                Text = "<",
                Location = new Point(10, pnlDoctors.Height / 2),
                Size = new Size(30, 60),
                Font = new Font("Arial", 16, FontStyle.Bold),
                BackColor = Color.LightGray,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Bottom
            };
            pnlDoctors.Controls.Add(btnLeftArrow);

            btnRightArrow = new Button()
            {
                Text = ">",
                Location = new Point(pnlDoctors.Width - 40, pnlDoctors.Height / 2),
                Size = new Size(30, 60),
                Font = new Font("Arial", 16, FontStyle.Bold),
                BackColor = Color.LightGray,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Anchor = AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom
            };
            pnlDoctors.Controls.Add(btnRightArrow);

            // Calendar Icon (Drawn)
            pbCalendarIcon = new PictureBox()
            {
                Size = new Size(60, 60),
                Location = new Point(this.Width - 100, this.Height - 100),
                BackColor = Color.Transparent,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };
            pbCalendarIcon.Paint += PbCalendarIcon_Paint;
            this.Controls.Add(pbCalendarIcon);

            // Copyright
            lblCopyright = new Label()
            {
                Text = "Copyright © 2025 Bệnh viện Hùng Vương. All rights reserved.",
                Location = new Point(0, this.Height - 30),
                Size = new Size(this.Width, 30),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            this.Controls.Add(lblCopyright);
        }

        private void btnSetAppointment_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(selectedDoctorName))
            {
                MessageBox.Show("Vui lòng chọn một bác sĩ trước khi đặt lịch.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Hiển thị thông báo "Đặt lịch thành công!"
            ShowAppointmentSuccessDialog();
        }

        private void ShowAppointmentSuccessDialog()
        {
            Form successForm = new Form();
            successForm.Text = "Đặt lịch thành công!";
            // Tăng kích thước form
            successForm.Size = new Size(500, 400);
            successForm.StartPosition = FormStartPosition.CenterScreen;
            successForm.FormBorderStyle = FormBorderStyle.FixedDialog;
            successForm.MinimizeBox = false;
            successForm.MaximizeBox = false;
            successForm.BackColor = Color.White;
            successForm.TopMost = true;

            // Header Panel
            Panel pnlHeader = new Panel()
            {
                Dock = DockStyle.Top,
                Size = new Size(successForm.Width, 60),
                BackColor = Color.FromArgb(0, 122, 204)
            };
            Label lblTitle = new Label()
            {
                Text = "Đặt lịch thành công!",
                Font = new Font("Arial", 16, FontStyle.Bold),
                ForeColor = Color.White,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter
            };
            pnlHeader.Controls.Add(lblTitle);
            successForm.Controls.Add(pnlHeader);

            // Main Content Panel
            Panel pnlContent = new Panel()
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(30)
            };

            int yPos = 30; // Vị trí y ban đầu
            int spacing = 40; // Khoảng cách giữa các dòng

            // Thông tin bác sĩ đã chọn
            Label lblDoctorInfo = new Label()
            {
                Text = $"Bác sĩ: {selectedDoctorName}",
                Font = new Font("Arial", 14, FontStyle.Bold),
                Location = new Point(30, yPos),
                AutoSize = true
            };
            pnlContent.Controls.Add(lblDoctorInfo);
            yPos += spacing;

            // Số thứ tự
            Label lblSoThuTu = new Label()
            {
                Text = "Số thứ tự: 72",
                Font = new Font("Arial", 14, FontStyle.Bold),
                Location = new Point(30, yPos),
                AutoSize = true
            };
            pnlContent.Controls.Add(lblSoThuTu);
            yPos += spacing;

            // Ngày khám
            Label lblNgayKham = new Label()
            {
                Text = $"Ngày khám: {dtpDate.Value.ToShortDateString()}",
                Font = new Font("Arial", 14, FontStyle.Bold),
                Location = new Point(30, yPos),
                AutoSize = true
            };
            pnlContent.Controls.Add(lblNgayKham);
            yPos += spacing;

            // Buổi
            Label lblBuoi = new Label()
            {
                Text = $"Buổi: {cbExaminationTime.SelectedItem}",
                Font = new Font("Arial", 14, FontStyle.Bold),
                Location = new Point(30, yPos),
                AutoSize = true
            };
            pnlContent.Controls.Add(lblBuoi);
            yPos += spacing + 20;

            // Thông báo
            Label lblMessage = new Label()
            {
                Text = "Thông tin lịch hẹn đã được gửi qua email đã đăng ký tài khoản!",
                Font = new Font("Arial", 12),
                Location = new Point(30, yPos),
                Size = new Size(pnlContent.Width - 60, 40),
                TextAlign = ContentAlignment.MiddleCenter
            };
            pnlContent.Controls.Add(lblMessage);

            // Buttons Panel
            Panel pnlButtons = new Panel()
            {
                Dock = DockStyle.Bottom,
                Size = new Size(successForm.Width, 60),
                Padding = new Padding(10)
            };

            Button btnXong = new Button()
            {
                Text = "Xong",
                Size = new Size(150, 40),
                Location = new Point(pnlButtons.Width / 2 - 160, 10),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 12, FontStyle.Bold)
            };
            btnXong.Click += (s, ev) => successForm.Close();
            pnlButtons.Controls.Add(btnXong);

            Button btnThanhToan = new Button()
            {
                Text = "Thanh toán",
                Size = new Size(150, 40),
                Location = new Point(pnlButtons.Width / 2 + 10, 10),
                BackColor = Color.Red,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 12, FontStyle.Bold)
            };
            btnThanhToan.Click += (s, ev) => { MessageBox.Show("Chức năng thanh toán đang được phát triển.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information); };
            pnlButtons.Controls.Add(btnThanhToan);

            successForm.Controls.Add(pnlContent);
            successForm.Controls.Add(pnlButtons);
            successForm.ShowDialog();
        }

        private void AddDoctorCards()
        {
            // Xóa tất cả các thẻ bác sĩ cũ nếu có
            flpDoctors.Controls.Clear();
            selectedDoctorPanel = null;
            selectedDoctorName = "";

            // Danh sách tên bác sĩ giả lập
            string[] doctors = { "Bác sĩ CKII.\nNguyễn Thị Anh P", "Bác sĩ CKI.\nLê Văn C", "Bác sĩ CKI.\nTrần Minh D", "Bác sĩ CKII.\nPhạm Thu E", "Bác sĩ CKI.\nHoàng Văn F", "Bác sĩ CKII.\nNguyễn Thu H", "Bác sĩ CKI.\nLê Bích T", "Bác sĩ CKII.\nNguyễn Nam N" };

            foreach (string doctorName in doctors)
            {
                Panel pnlCard = new Panel()
                {
                    Size = new Size(200, 250),
                    BackColor = Color.White,
                    Margin = new Padding(10),
                    BorderStyle = BorderStyle.FixedSingle
                };

                PictureBox pbDoctor = new PictureBox()
                {
                    // Thay đổi đường dẫn đến ảnh bác sĩ của bạn
                    Image = Image.FromFile(@"D:\Dow\doctor.png"),
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Size = new Size(100, 100),
                    Location = new Point(50, 20)
                };
                pnlCard.Controls.Add(pbDoctor);

                Label lblDoctorName = new Label()
                {
                    Text = doctorName,
                    Location = new Point(10, 130),
                    Font = new Font("Arial", 12, FontStyle.Bold),
                    AutoSize = false,
                    TextAlign = ContentAlignment.MiddleCenter,
                    Size = new Size(pnlCard.Width - 20, 50)
                };
                pnlCard.Controls.Add(lblDoctorName);

                Button btnChoose = new Button()
                {
                    Text = "Chọn",
                    Size = new Size(100, 30),
                    Location = new Point(50, 200),
                    BackColor = Color.FromArgb(0, 122, 204),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    FlatAppearance = { BorderSize = 0 },
                    Font = new Font("Arial", 10, FontStyle.Bold)
                };
                // Thêm sự kiện click cho nút "Chọn"
                btnChoose.Click += (s, e) =>
                {
                    // Đặt lại màu sắc của panel cũ nếu có
                    if (selectedDoctorPanel != null)
                    {
                        selectedDoctorPanel.BackColor = Color.White;
                        // Kích hoạt lại nút "Chọn" của panel cũ
                        foreach (Control control in selectedDoctorPanel.Controls)
                        {
                            if (control is Button button && button.Text == "Đã chọn")
                            {
                                button.Text = "Chọn";
                                button.BackColor = Color.FromArgb(0, 122, 204);
                                button.Enabled = true;
                            }
                        }
                    }

                    // Tô sáng panel mới và vô hiệu hóa nút "Chọn"
                    pnlCard.BackColor = Color.FromArgb(204, 230, 255); // Màu xanh nhạt
                    selectedDoctorPanel = pnlCard;
                    selectedDoctorName = doctorName;

                    btnChoose.Text = "Đã chọn";
                    btnChoose.BackColor = Color.Green; // Màu xanh lá cây
                    btnChoose.Enabled = false;

                    MessageBox.Show($"Bạn đã chọn {selectedDoctorName}. Vui lòng nhấp vào 'Đặt lịch' để xác nhận.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                };
                pnlCard.Controls.Add(btnChoose);

                flpDoctors.Controls.Add(pnlCard);
            }
        }

        private void PbCalendarIcon_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            int width = pbCalendarIcon.Width;
            int height = pbCalendarIcon.Height;
            int margin = 5;

            Rectangle rect = new Rectangle(margin, margin + 5, width - margin * 2, height - margin * 2 - 5);
            using (var brush = new SolidBrush(Color.FromArgb(0, 122, 204)))
            {
                g.FillRectangle(brush, rect);
            }
            using (var pen = new Pen(Color.White, 3))
            {
                g.DrawRectangle(pen, rect);
            }

            Rectangle topRect = new Rectangle(margin, margin, width - margin * 2, 10);
            using (var topBrush = new SolidBrush(Color.Red))
            {
                g.FillRectangle(topBrush, topRect);
            }

            using (var pen = new Pen(Color.White, 2))
            {
                g.DrawLine(pen, new Point(width / 2 - 10, margin + 1), new Point(width / 2 - 10, margin + 9));
                g.DrawLine(pen, new Point(width / 2 + 10, margin + 1), new Point(width / 2 + 10, margin + 9));
            }

            string day = DateTime.Now.Day.ToString();
            using (var font = new Font("Arial", 18, FontStyle.Bold))
            using (var brush = new SolidBrush(Color.White))
            {
                StringFormat format = new StringFormat()
                {
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center
                };
                Rectangle textRect = new Rectangle(rect.X, rect.Y + 10, rect.Width, rect.Height - 10);
                g.DrawString(day, font, brush, textRect, format);
            }
        }

        private void datlich_Resize(object sender, EventArgs e)
        {
            pnlHeader.Size = new Size(this.ClientSize.Width, 120);
            pnlMenu.Size = new Size(this.ClientSize.Width, 60);
            pnlMenu.Location = new Point(0, 120);
            pnlMain.Size = new Size(this.ClientSize.Width - 100, this.ClientSize.Height - 250);
            pnlMain.Location = new Point((this.ClientSize.Width - pnlMain.Width) / 2, 200);

            pbBannerImage.Size = new Size(this.ClientSize.Width - 260, 100);

            // Adjust menu button locations on resize
            btnLogout.Location = new Point(pnlMenu.Width - 130, 15);

            pbCalendarIcon.Location = new Point(this.ClientSize.Width - 100, this.ClientSize.Height - 100);
            lblCopyright.Size = new Size(this.ClientSize.Width, 30);
            lblCopyright.Location = new Point(0, this.ClientSize.Height - 30);
        }

        // Helper methods for creating controls
        private Label CreateLabel(string text, Point location, Control parent)
        {
            Label lbl = new Label()
            {
                Text = text,
                Location = location,
                AutoSize = true,
                Font = new Font("Arial", 12, FontStyle.Bold),
                ForeColor = Color.Black
            };
            parent.Controls.Add(lbl);
            return lbl;
        }

        private TextBox CreateTextBox(Point location, Control parent, int width)
        {
            TextBox txt = new TextBox()
            {
                Location = location,
                Size = new Size(width, 30),
                Font = new Font("Arial", 10)
            };
            parent.Controls.Add(txt);
            return txt;
        }

        private ComboBox CreateComboBox(Point location, Control parent, int width)
        {
            ComboBox cb = new ComboBox()
            {
                Location = location,
                Size = new Size(width, 30),
                Font = new Font("Arial", 10),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            parent.Controls.Add(cb);
            return cb;
        }

        private Button CreateMenuButton(string text, Point location)
        {
            return new Button()
            {
                Text = text,
                Location = location,
                Size = new Size(120, 30),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 10, FontStyle.Bold),
                Anchor = AnchorStyles.Right | AnchorStyles.Top
            };
        }
    }
}
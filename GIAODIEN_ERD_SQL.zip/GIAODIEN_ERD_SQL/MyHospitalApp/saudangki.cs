﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MyHospitalApp
{
    public class saudangki : Form
    {
        // Controls
        private Panel pnlHeader;
        private Panel pnlMenu;
        private Panel pnlMain;
        private Panel pnlServices;
        private Label lblHeaderTitle;
        private Label lblGreeting;
        private Label lblServicePrompt;
        private PictureBox pbLogo, pbBannerImage, pbCalendarIcon;
        private Button btnLogout;
        private Button btnProfile, btnSchedule, btnHistory;
        private Label lblCopyright;

        public saudangki()
        {
            this.Text = "Bệnh viện Hùng Vương";
            this.Size = new Size(1300, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Resize += new EventHandler(saudangki_Resize);

            // Initialize all components
            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Header Panel
            pnlHeader = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(this.Width, 120),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlHeader);

            // Logo Bệnh viện Hùng Vương
            pbLogo = new PictureBox()
            {
                Image = Image.FromFile(@"D:\Dow\logo.png"),
                SizeMode = PictureBoxSizeMode.Zoom,
                Location = new Point(20, 10),
                Size = new Size(200, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbLogo);

            // Banner image
            pbBannerImage = new PictureBox()
            {
                Image = Image.FromFile(@"D:\Dow\banner.png"),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Location = new Point(240, 10),
                Size = new Size(this.Width - 260, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbBannerImage);

            // Menu Panel
            pnlMenu = new Panel()
            {
                Location = new Point(0, 120),
                Size = new Size(this.Width, 60),
                BackColor = Color.FromArgb(0, 122, 204),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlMenu);

            // "Xin chào, Nguyễn Văn A!" Label
            lblGreeting = new Label()
            {
                Text = "Xin chào, Nguyễn Văn A!",
                Location = new Point(20, 15),
                AutoSize = true,
                Font = new Font("Arial", 16, FontStyle.Bold),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlMenu.Controls.Add(lblGreeting);

            // Logout Button
            btnLogout = new Button()
            {
                Text = "Đăng xuất",
                Size = new Size(120, 40),
                BackColor = Color.Red,
                ForeColor = Color.White,
                Font = new Font("Arial", 12, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0, BorderColor = Color.Red },
                Location = new Point(this.Width - 140, 10),
                Anchor = AnchorStyles.Right | AnchorStyles.Top
            };
            btnLogout.Click += BtnLogout_Click;
            pnlMenu.Controls.Add(btnLogout);

            // Main Panel
            pnlMain = new Panel()
            {
                Location = new Point(0, 180),
                Size = new Size(this.Width, this.Height - 180 - 60),
                BackColor = Color.FromArgb(240, 240, 240),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom
            };
            this.Controls.Add(pnlMain);

            // "Vui lòng chọn dịch vụ" Label
            lblServicePrompt = new Label()
            {
                Text = "Vui lòng chọn dịch vụ để được phục vụ tốt nhất",
                Location = new Point(0, 40),
                Size = new Size(pnlMain.Width, 30),
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Arial", 18, FontStyle.Bold),
                ForeColor = Color.Black,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            pnlMain.Controls.Add(lblServicePrompt);

            // Services Panel
            pnlServices = new Panel()
            {
                Location = new Point((pnlMain.Width - 1000) / 2, 120),
                Size = new Size(1000, 150),
                BackColor = Color.Transparent,
                Anchor = AnchorStyles.Top
            };
            pnlMain.Controls.Add(pnlServices);

            // Service Buttons
            btnProfile = CreateServiceButton("Hồ sơ", new Point(0, 0));
            btnSchedule = CreateServiceButton("Đặt lịch", new Point(350, 0));
            btnHistory = CreateServiceButton("Lịch sử hẹn", new Point(700, 0));

            pnlServices.Controls.Add(btnProfile);
            pnlServices.Controls.Add(btnSchedule);
            pnlServices.Controls.Add(btnHistory);

            // Calendar Icon (Drawn)
            pbCalendarIcon = new PictureBox()
            {
                Size = new Size(60, 60),
                Location = new Point(this.Width - 100, pnlMain.Height - 100),
                BackColor = Color.Transparent,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };
            pbCalendarIcon.Paint += PbCalendarIcon_Paint;
            pnlMain.Controls.Add(pbCalendarIcon);

            // Copyright
            lblCopyright = new Label()
            {
                Text = "Copyright © 2025 Bệnh viện Hùng Vương. All rights reserved.",
                Location = new Point(0, this.Height - 30),
                Size = new Size(this.Width, 30),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            this.Controls.Add(lblCopyright);
        }

        private void PbCalendarIcon_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            int width = pbCalendarIcon.Width;
            int height = pbCalendarIcon.Height;
            int margin = 5;

            // Draw the main calendar body
            Rectangle rect = new Rectangle(margin, margin + 5, width - margin * 2, height - margin * 2 - 5);
            using (var brush = new SolidBrush(Color.FromArgb(0, 122, 204)))
            {
                g.FillRectangle(brush, rect);
            }
            using (var pen = new Pen(Color.White, 3))
            {
                g.DrawRectangle(pen, rect);
            }

            // Draw the top part (tabs)
            Rectangle topRect = new Rectangle(margin, margin, width - margin * 2, 10);
            using (var topBrush = new SolidBrush(Color.Red))
            {
                g.FillRectangle(topBrush, topRect);
            }

            // Draw the vertical lines
            using (var pen = new Pen(Color.White, 2))
            {
                g.DrawLine(pen, new Point(width / 2 - 10, margin + 1), new Point(width / 2 - 10, margin + 9));
                g.DrawLine(pen, new Point(width / 2 + 10, margin + 1), new Point(width / 2 + 10, margin + 9));
            }

            // Draw the date number (e.g., "24")
            string day = DateTime.Now.Day.ToString();
            using (var font = new Font("Arial", 18, FontStyle.Bold))
            using (var brush = new SolidBrush(Color.White))
            {
                StringFormat format = new StringFormat()
                {
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center
                };
                Rectangle textRect = new Rectangle(rect.X, rect.Y + 10, rect.Width, rect.Height - 10);
                g.DrawString(day, font, brush, textRect, format);
            }
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Đã đăng xuất!");
        }

        private Button CreateServiceButton(string text, Point location)
        {
            Button btn = new Button()
            {
                Text = text,
                Location = location,
                Size = new Size(300, 150),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Font = new Font("Arial", 20, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0, BorderColor = Color.FromArgb(0, 122, 204) }
            };
            return btn;
        }

        private void saudangki_Resize(object sender, EventArgs e)
        {
            // Adjust the size and position of the main panels
            pnlHeader.Size = new Size(this.ClientSize.Width, 120);
            pnlMenu.Size = new Size(this.ClientSize.Width, 60);
            pnlMenu.Location = new Point(0, 120);
            pnlMain.Size = new Size(this.ClientSize.Width, this.ClientSize.Height - 180 - 30);
            pnlMain.Location = new Point(0, 180);

            // Update banner image location
            pbBannerImage.Size = new Size(this.ClientSize.Width - 260, 100);

            // Update logout button location
            btnLogout.Location = new Point(this.ClientSize.Width - 140, 10);

            // Center the service prompt label
            lblServicePrompt.Size = new Size(pnlMain.Width, 30);

            // Center the services panel
            pnlServices.Location = new Point((pnlMain.Width - pnlServices.Width) / 2, 120);

            // Update calendar icon location
            if (pbCalendarIcon != null)
            {
                pbCalendarIcon.Location = new Point(this.ClientSize.Width - 100, this.ClientSize.Height - 100);
            }

            // Update copyright label location
            lblCopyright.Size = new Size(this.ClientSize.Width, 30);
            lblCopyright.Location = new Point(0, this.ClientSize.Height - 30);
        }
    }
}
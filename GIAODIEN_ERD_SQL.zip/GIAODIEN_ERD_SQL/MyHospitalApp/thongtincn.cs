﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MyHospitalApp
{
    public class thongtincn : Form
    {
        // Controls
        private Panel pnlHeader;
        private Panel pnlMenu;
        private Panel pnlMain;
        private PictureBox pbLogo, pbBannerImage, pbCalendarIcon;
        private Label lblHeaderTitle;
        private Button btnHome, btnHistory, btnSchedule, btnLogout, btnBack, btnForgotPassword;
        private Label lblFullName, lblCCCD, lblEmail, lblNotes, lblDOB, lblGender;
        private TextBox txtFullName, txtCCCD, txtEmail;
        private RichTextBox rtbNotes;
        private DateTimePicker dtpDOB;
        private Label lblCopyright;
        private RadioButton rbMale, rbFemale;
        private GroupBox gbGender;

        public thongtincn()
        {
            this.Text = "Thông tin cá nhân - Bệnh viện Hùng Vương";
            this.Size = new Size(1300, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Resize += new EventHandler(thongtincn_Resize);

            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Header Panel
            pnlHeader = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(this.Width, 120),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlHeader);

            // Logo Bệnh viện Hùng Vương
            pbLogo = new PictureBox()
            {
                Image = Image.FromFile(@"D:\Dow\logo.png"),
                SizeMode = PictureBoxSizeMode.Zoom,
                Location = new Point(20, 10),
                Size = new Size(200, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbLogo);

            // Banner image
            pbBannerImage = new PictureBox()
            {
                Image = Image.FromFile(@"D:\Dow\banner.png"),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Location = new Point(240, 10),
                Size = new Size(this.Width - 260, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbBannerImage);

            // Menu Panel
            pnlMenu = new Panel()
            {
                Location = new Point(0, 120),
                Size = new Size(this.Width, 60),
                BackColor = Color.FromArgb(0, 122, 204),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlMenu);

            // "Thông tin cá nhân" Label
            lblHeaderTitle = new Label()
            {
                Text = "Thông tin cá nhân",
                Location = new Point(20, 15),
                AutoSize = true,
                Font = new Font("Arial", 16, FontStyle.Bold),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlMenu.Controls.Add(lblHeaderTitle);

            // Menu Buttons
            btnHome = CreateMenuButton("Trang chủ", new Point(pnlMenu.Width - 450, 15));
            btnHistory = CreateMenuButton("Lịch sử hẹn", new Point(pnlMenu.Width - 300, 15));
            btnSchedule = CreateMenuButton("Đặt lịch", new Point(pnlMenu.Width - 150, 15));
            pnlMenu.Controls.Add(btnHome);
            pnlMenu.Controls.Add(btnHistory);
            pnlMenu.Controls.Add(btnSchedule);

            // Main Panel
            pnlMain = new Panel()
            {
                Location = new Point(50, 200),
                Size = new Size(1180, 450),
                BackColor = Color.White,
                Anchor = AnchorStyles.None
            };
            pnlMain.Paint += PnlMain_Paint;
            this.Controls.Add(pnlMain);

            // Left side controls (adjusted for spacing)
            lblFullName = CreateLabel("Họ và tên", new Point(50, 30), pnlMain);
            txtFullName = CreateTextBox(new Point(50, 60), pnlMain);

            lblCCCD = CreateLabel("Căn cước công dân", new Point(50, 150), pnlMain);
            txtCCCD = CreateTextBox(new Point(50, 180), pnlMain);

            lblEmail = CreateLabel("Địa chỉ email", new Point(50, 270), pnlMain);
            txtEmail = CreateTextBox(new Point(50, 300), pnlMain);

            // Right side controls (adjusted for spacing)
            lblNotes = CreateLabel("Ghi chú", new Point(600, 30), pnlMain);

            rtbNotes = new RichTextBox()
            {
                Location = new Point(600, 60),
                Size = new Size(230, 260),
                Font = new Font("Arial", 10),
                BorderStyle = BorderStyle.FixedSingle
            };
            pnlMain.Controls.Add(rtbNotes);

            lblDOB = CreateLabel("Ngày sinh", new Point(850, 30), pnlMain);
            dtpDOB = new DateTimePicker()
            {
                Location = new Point(850, 60),
                Size = new Size(250, 30),
                Font = new Font("Arial", 10),
                Format = DateTimePickerFormat.Short
            };
            pnlMain.Controls.Add(dtpDOB);

            // New: Gender GroupBox and RadioButtons
            lblGender = CreateLabel("Giới tính", new Point(850, 120), pnlMain);

            gbGender = new GroupBox()
            {
                Location = new Point(850, 150),
                Size = new Size(250, 50),
                Text = "", // No text for the groupbox
                FlatStyle = FlatStyle.Flat
            };
            gbGender.Controls.Clear();
            pnlMain.Controls.Add(gbGender);

            rbMale = new RadioButton()
            {
                Text = "Nam",
                Location = new Point(10, 15),
                AutoSize = true,
                Font = new Font("Arial", 10)
            };
            gbGender.Controls.Add(rbMale);

            rbFemale = new RadioButton()
            {
                Text = "Nữ",
                Location = new Point(100, 15),
                AutoSize = true,
                Font = new Font("Arial", 10)
            };
            gbGender.Controls.Add(rbFemale);

            // Buttons - Adjusted to be on the same horizontal line
            btnForgotPassword = CreateButton("Quên mật khẩu?", Color.White, new Point(600, 370), pnlMain);
            btnForgotPassword.ForeColor = Color.Black;
            btnForgotPassword.Font = new Font("Arial", 10, FontStyle.Underline);

            btnBack = CreateButton("Trở lại", Color.DodgerBlue, new Point(780, 370), pnlMain);
            btnLogout = CreateButton("Đăng xuất", Color.Red, new Point(980, 370), pnlMain);

            // Calendar Icon (Drawn)
            pbCalendarIcon = new PictureBox()
            {
                Size = new Size(60, 60),
                Location = new Point(this.Width - 100, this.Height - 100),
                BackColor = Color.Transparent,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };
            pbCalendarIcon.Paint += PbCalendarIcon_Paint;
            this.Controls.Add(pbCalendarIcon);

            // Copyright
            lblCopyright = new Label()
            {
                Text = "Copyright © 2025 Bệnh viện Hùng Vương. All rights reserved.",
                Location = new Point(0, this.Height - 30),
                Size = new Size(this.Width, 30),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            this.Controls.Add(lblCopyright);
        }

        private void PnlMain_Paint(object sender, PaintEventArgs e)
        {
            Panel p = sender as Panel;
            using (var pen = new Pen(Color.LightGray, 1))
            {
                e.Graphics.DrawRectangle(pen, 0, 0, p.Width - 1, p.Height - 1);
            }
        }

        private void PbCalendarIcon_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            int width = pbCalendarIcon.Width;
            int height = pbCalendarIcon.Height;
            int margin = 5;

            // Draw the main calendar body
            Rectangle rect = new Rectangle(margin, margin + 5, width - margin * 2, height - margin * 2 - 5);
            using (var brush = new SolidBrush(Color.FromArgb(0, 122, 204)))
            {
                g.FillRectangle(brush, rect);
            }
            using (var pen = new Pen(Color.White, 3))
            {
                g.DrawRectangle(pen, rect);
            }

            // Draw the top part (tabs)
            Rectangle topRect = new Rectangle(margin, margin, width - margin * 2, 10);
            using (var topBrush = new SolidBrush(Color.Red))
            {
                g.FillRectangle(topBrush, topRect);
            }

            // Draw the vertical lines
            using (var pen = new Pen(Color.White, 2))
            {
                g.DrawLine(pen, new Point(width / 2 - 10, margin + 1), new Point(width / 2 - 10, margin + 9));
                g.DrawLine(pen, new Point(width / 2 + 10, margin + 1), new Point(width / 2 + 10, margin + 9));
            }

            // Draw the date number (e.g., "24")
            string day = DateTime.Now.Day.ToString();
            using (var font = new Font("Arial", 18, FontStyle.Bold))
            using (var brush = new SolidBrush(Color.White))
            {
                StringFormat format = new StringFormat()
                {
                    Alignment = StringAlignment.Center,
                    LineAlignment = StringAlignment.Center
                };
                Rectangle textRect = new Rectangle(rect.X, rect.Y + 10, rect.Width, rect.Height - 10);
                g.DrawString(day, font, brush, textRect, format);
            }
        }

        private void thongtincn_Resize(object sender, EventArgs e)
        {
            // Adjust the size and position of the main panels
            pnlHeader.Size = new Size(this.ClientSize.Width, 120);
            pnlMenu.Size = new Size(this.ClientSize.Width, 60);
            pnlMenu.Location = new Point(0, 120);
            pnlMain.Size = new Size(this.ClientSize.Width - 100, this.ClientSize.Height - 250);
            pnlMain.Location = new Point((this.ClientSize.Width - pnlMain.Width) / 2, 200);

            // Update banner image location
            pbBannerImage.Size = new Size(this.ClientSize.Width - 260, 100);

            // Update menu button locations
            btnHome.Location = new Point(pnlMenu.Width - 450, 15);
            btnHistory.Location = new Point(pnlMenu.Width - 300, 15);
            btnSchedule.Location = new Point(pnlMenu.Width - 150, 15);

            // Update calendar icon location
            if (pbCalendarIcon != null)
            {
                pbCalendarIcon.Location = new Point(this.ClientSize.Width - 100, this.ClientSize.Height - 100);
            }

            // Update copyright label location
            lblCopyright.Size = new Size(this.ClientSize.Width, 30);
            lblCopyright.Location = new Point(0, this.ClientSize.Height - 30);
        }

        // Helper methods for creating controls
        private Label CreateLabel(string text, Point location, Control parent)
        {
            Label lbl = new Label()
            {
                Text = text,
                Location = location,
                AutoSize = true,
                Font = new Font("Arial", 12, FontStyle.Bold),
                ForeColor = Color.Black
            };
            parent.Controls.Add(lbl);
            return lbl;
        }

        private TextBox CreateTextBox(Point location, Control parent)
        {
            TextBox txt = new TextBox()
            {
                Location = location,
                Size = new Size(450, 30),
                Font = new Font("Arial", 10)
            };
            parent.Controls.Add(txt);
            return txt;
        }

        private Button CreateMenuButton(string text, Point location)
        {
            return new Button()
            {
                Text = text,
                Location = location,
                Size = new Size(120, 30),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 10, FontStyle.Bold),
                Anchor = AnchorStyles.Right | AnchorStyles.Top
            };
        }

        private Button CreateButton(string text, Color backColor, Point location, Control parent)
        {
            Button btn = new Button()
            {
                Text = text,
                Location = location,
                Size = new Size(170, 50), // Increased width for better spacing
                BackColor = backColor,
                ForeColor = Color.White,
                Font = new Font("Arial", 12, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0, BorderColor = backColor }
            };
            parent.Controls.Add(btn);
            return btn;
        }
    }
}
﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace MyHospitalApp
{
    public class thanhtoan : Form
    {
        // Controls
        private Panel pnlHeader, pnlMenu, pnlMain, pnlPaymentInfo, pnlPaymentMethods;
        private PictureBox pbLogo, pbBannerImage, pbCalendarIcon;
        private Label lblHeaderTitle, lblPaymentInfoTitle, lblPaymentMethodsTitle, lblTotal, lblCopyright;
        private TextBox txtPaymentCode, txtDate, txtTotal;
        private DataGridView dgvServices;
        private Button btnCancel, btnPay;

        public thanhtoan()
        {
            this.Text = "Thanh toán - Bệnh viện Hùng Vương";
            this.Size = new Size(1300, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Resize += new EventHandler(thanhtoan_Resize);

            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Header Panel
            pnlHeader = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(this.Width, 120),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlHeader);

            // Logo Bệnh viện Hùng Vương
            pbLogo = new PictureBox()
            {
                Image = Image.FromFile(@"D:\Dow\logo.png"),
                SizeMode = PictureBoxSizeMode.Zoom,
                Location = new Point(20, 10),
                Size = new Size(200, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbLogo);

            // Banner image
            pbBannerImage = new PictureBox()
            {
                Image = Image.FromFile(@"D:\Dow\banner.png"),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Location = new Point(240, 10),
                Size = new Size(this.Width - 260, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbBannerImage);

            // Menu Panel
            pnlMenu = new Panel()
            {
                Location = new Point(0, 120),
                Size = new Size(this.Width, 60),
                BackColor = Color.FromArgb(0, 122, 204),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlMenu);

            // "Thanh toán" Label
            lblHeaderTitle = new Label()
            {
                Text = "Thanh toán",
                Location = new Point(20, 15),
                AutoSize = true,
                Font = new Font("Arial", 16, FontStyle.Bold),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlMenu.Controls.Add(lblHeaderTitle);

            // Menu Buttons
            Button btnHistory = CreateMenuButton("Lịch sử hẹn", new Point(pnlMenu.Width - 580, 15));
            Button btnHome = CreateMenuButton("Trang chủ", new Point(pnlMenu.Width - 430, 15));
            Button btnProfile = CreateMenuButton("Hồ sơ", new Point(pnlMenu.Width - 280, 15));
            pnlMenu.Controls.Add(btnHistory);
            pnlMenu.Controls.Add(btnHome);
            pnlMenu.Controls.Add(btnProfile);

            // Logout Button
            Button btnLogout = new Button()
            {
                Text = "Đăng xuất",
                Location = new Point(pnlMenu.Width - 130, 15),
                Size = new Size(120, 30),
                BackColor = Color.Red,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 10, FontStyle.Bold),
                Anchor = AnchorStyles.Right | AnchorStyles.Top
            };
            pnlMenu.Controls.Add(btnLogout);

            // Main Panel
            pnlMain = new Panel()
            {
                Location = new Point(50, 200),
                Size = new Size(this.Width - 100, this.Height - 300),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom
            };
            this.Controls.Add(pnlMain);

            // Payment Info Panel (Left side)
            pnlPaymentInfo = new Panel()
            {
                Location = new Point(20, 20),
                Size = new Size(pnlMain.Width * 3 / 5 - 30, pnlMain.Height - 40),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Bottom
            };
            pnlMain.Controls.Add(pnlPaymentInfo);

            // Payment Info Title
            lblPaymentInfoTitle = new Label()
            {
                Text = "Thông tin thanh toán",
                Location = new Point(10, 10),
                Font = new Font("Arial", 14, FontStyle.Bold),
                AutoSize = true,
                Anchor = AnchorStyles.Top | AnchorStyles.Left
            };
            pnlPaymentInfo.Controls.Add(lblPaymentInfoTitle);

            // Payment Code and Date
            Label lblPaymentCode = CreateLabel("Mã thanh toán:", new Point(10, 50), pnlPaymentInfo);
            txtPaymentCode = CreateTextBox(new Point(10, 75), pnlPaymentInfo, (pnlPaymentInfo.Width - 40) / 2);

            Label lblDate = CreateLabel("Ngày:", new Point(pnlPaymentInfo.Width / 2, 50), pnlPaymentInfo);
            txtDate = CreateTextBox(new Point(pnlPaymentInfo.Width / 2, 75), pnlPaymentInfo, (pnlPaymentInfo.Width - 40) / 2);

            // DataGridView for services
            dgvServices = new DataGridView()
            {
                Location = new Point(10, 120),
                Size = new Size(pnlPaymentInfo.Width - 20, pnlPaymentInfo.Height - 200),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom,
                BackgroundColor = Color.White,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            };
            dgvServices.Columns.Add("ServiceName", "Tên dịch vụ");
            dgvServices.Columns.Add("Amount", "Thành tiền");
            pnlPaymentInfo.Controls.Add(dgvServices);

            // Populate DataGridView with sample data
            dgvServices.Rows.Add("Khám bệnh", "300,000");
            dgvServices.Rows.Add("Xét nghiệm", "150,000");

            // Total Label and TextBox
            lblTotal = new Label()
            {
                Text = "Tổng thanh toán:",
                Location = new Point(10, pnlPaymentInfo.Height - 60),
                Font = new Font("Arial", 14, FontStyle.Bold),
                AutoSize = true,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Left
            };
            pnlPaymentInfo.Controls.Add(lblTotal);

            txtTotal = new TextBox()
            {
                Location = new Point(10, pnlPaymentInfo.Height - 30),
                Size = new Size(pnlPaymentInfo.Width - 20, 30),
                Font = new Font("Arial", 12),
                ReadOnly = true,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };
            pnlPaymentInfo.Controls.Add(txtTotal);

            // Payment Methods Panel (Right side)
            pnlPaymentMethods = new Panel()
            {
                Location = new Point(pnlMain.Width * 3 / 5, 20),
                Size = new Size(pnlMain.Width * 2 / 5 - 30, pnlMain.Height - 40),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Anchor = AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom
            };
            pnlMain.Controls.Add(pnlPaymentMethods);

            // Payment Methods Title
            lblPaymentMethodsTitle = new Label()
            {
                Text = "Phương thức",
                Location = new Point(10, 10),
                Font = new Font("Arial", 14, FontStyle.Bold),
                AutoSize = true,
                Anchor = AnchorStyles.Top | AnchorStyles.Left
            };
            pnlPaymentMethods.Controls.Add(lblPaymentMethodsTitle);

            // Payment method buttons
            Button btnNapas = CreatePaymentMethodButton("napas", new Point(10, 50), pnlPaymentMethods);
            Button btnDirect = CreatePaymentMethodButton("Thanh toán trực tiếp", new Point(10, 120), pnlPaymentMethods);
            Button btnQR = CreatePaymentMethodButton("Mã QR", new Point(10, 190), pnlPaymentMethods);

            // Add Click event for "Thanh toán trực tiếp" button
            btnDirect.Click += (s, e) =>
            {
                Form popupForm = new Form();
                popupForm.StartPosition = FormStartPosition.CenterParent;
                popupForm.Size = new Size(400, 200);
                popupForm.Text = "Thanh toán";
                popupForm.FormBorderStyle = FormBorderStyle.FixedDialog;
                popupForm.MaximizeBox = false;
                popupForm.MinimizeBox = false;
                popupForm.BackColor = Color.White;

                Label lblMessage = new Label()
                {
                    Text = "Vui lòng thanh toán trực tiếp khi đến bệnh viện!",
                    Font = new Font("Arial", 14, FontStyle.Bold),
                    Location = new Point(20, 30),
                    Size = new Size(popupForm.Width - 40, 50),
                    TextAlign = ContentAlignment.MiddleCenter,
                    ForeColor = Color.Black
                };
                popupForm.Controls.Add(lblMessage);

                Label lblAmount = new Label()
                {
                    Text = "Số tiền:",
                    Font = new Font("Arial", 14, FontStyle.Bold),
                    Location = new Point(20, 80),
                    Size = new Size(popupForm.Width - 40, 30),
                    TextAlign = ContentAlignment.MiddleCenter,
                    ForeColor = Color.Black
                };
                popupForm.Controls.Add(lblAmount);

                Button btnOK = new Button()
                {
                    Text = "Xong",
                    Size = new Size(100, 40),
                    Location = new Point((popupForm.Width - 100) / 2, popupForm.Height - 80),
                    BackColor = Color.FromArgb(0, 122, 204),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    FlatAppearance = { BorderSize = 0 },
                    Font = new Font("Arial", 12, FontStyle.Bold)
                };
                btnOK.Click += (sender, args) => popupForm.Close();
                popupForm.Controls.Add(btnOK);

                popupForm.ShowDialog();
            };

            // Add Click event for "Mã QR" button
            btnQR.Click += (s, e) =>
            {
                Form popupQRForm = new Form();
                popupQRForm.StartPosition = FormStartPosition.CenterParent;
                popupQRForm.Size = new Size(400, 450);
                popupQRForm.Text = "Thanh toán bằng Mã QR";
                popupQRForm.FormBorderStyle = FormBorderStyle.FixedDialog;
                popupQRForm.MaximizeBox = false;
                popupQRForm.MinimizeBox = false;
                popupQRForm.BackColor = Color.White;

                Label lblMessage = new Label()
                {
                    Text = "Vui lòng quét mã QR để thanh toán!",
                    Font = new Font("Arial", 14, FontStyle.Bold),
                    Location = new Point(20, 30),
                    Size = new Size(popupQRForm.Width - 40, 50),
                    TextAlign = ContentAlignment.MiddleCenter,
                    ForeColor = Color.Black
                };
                popupQRForm.Controls.Add(lblMessage);

                PictureBox pbQRImage = new PictureBox()
                {
                    Image = Image.FromFile(@"D:\Dow\maqr.png"), // Tên file QR code của bạn
                    SizeMode = PictureBoxSizeMode.Zoom,
                    Location = new Point((popupQRForm.Width - 200) / 2, 90),
                    Size = new Size(200, 200)
                };
                popupQRForm.Controls.Add(pbQRImage);

                Label lblAmount = new Label()
                {
                    Text = "Số tiền:",
                    Font = new Font("Arial", 14, FontStyle.Bold),
                    Location = new Point(20, 300),
                    Size = new Size(popupQRForm.Width - 40, 30),
                    TextAlign = ContentAlignment.MiddleCenter,
                    ForeColor = Color.Black
                };
                popupQRForm.Controls.Add(lblAmount);

                Button btnOK = new Button()
                {
                    Text = "Xong",
                    Size = new Size(100, 40),
                    Location = new Point((popupQRForm.Width - 100) / 2, popupQRForm.Height - 80),
                    BackColor = Color.FromArgb(0, 122, 204),
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat,
                    FlatAppearance = { BorderSize = 0 },
                    Font = new Font("Arial", 12, FontStyle.Bold)
                };
                btnOK.Click += (sender, args) => popupQRForm.Close();
                popupQRForm.Controls.Add(btnOK);

                popupQRForm.ShowDialog();
            };

            // Action Buttons
            btnCancel = new Button()
            {
                Text = "Hủy",
                Size = new Size(100, 40),
                Location = new Point(pnlPaymentMethods.Width / 2 - 120, pnlPaymentMethods.Height - 60),
                BackColor = Color.Red,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 12, FontStyle.Bold),
                Anchor = AnchorStyles.Bottom
            };
            btnCancel.Click += (s, e) => this.Close();
            pnlPaymentMethods.Controls.Add(btnCancel);

            btnPay = new Button()
            {
                Text = "Thanh toán",
                Size = new Size(150, 40),
                Location = new Point(pnlPaymentMethods.Width / 2 + 10, pnlPaymentMethods.Height - 60),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 12, FontStyle.Bold),
                Anchor = AnchorStyles.Bottom
            };
            // Modified btnPay.Click event handler
            btnPay.Click += (s, e) => ShowPaymentSuccessPopup();
            pnlPaymentMethods.Controls.Add(btnPay);

            // Calendar Icon (Drawn)
            pbCalendarIcon = new PictureBox()
            {
                Size = new Size(60, 60),
                Location = new Point(this.Width - 100, this.Height - 100),
                BackColor = Color.Transparent,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };
            this.Controls.Add(pbCalendarIcon);

            // Copyright
            lblCopyright = new Label()
            {
                Text = "Copyright © 2025 Bệnh viện Hùng Vương. All rights reserved.",
                Location = new Point(0, this.Height - 30),
                Size = new Size(this.Width, 30),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            this.Controls.Add(lblCopyright);
        }

        private void thanhtoan_Resize(object sender, EventArgs e)
        {
            pnlHeader.Size = new Size(this.ClientSize.Width, 120);
            pnlMenu.Size = new Size(this.ClientSize.Width, 60);
            pnlMenu.Location = new Point(0, 120);
            pnlMain.Size = new Size(this.ClientSize.Width - 100, this.ClientSize.Height - 250);
            pnlMain.Location = new Point((this.ClientSize.Width - pnlMain.Width) / 2, 200);

            pbBannerImage.Size = new Size(this.ClientSize.Width - 260, 100);

            // Adjust menu button locations on resize
            var btnLogout = (Button)pnlMenu.Controls[pnlMenu.Controls.Count - 1];
            if (btnLogout != null)
            {
                btnLogout.Location = new Point(pnlMenu.Width - 130, 15);
            }

            pbCalendarIcon.Location = new Point(this.ClientSize.Width - 100, this.ClientSize.Height - 100);
            lblCopyright.Size = new Size(this.ClientSize.Width, 30);
            lblCopyright.Location = new Point(0, this.ClientSize.Height - 30);

            // Adjust sizes of panels inside pnlMain
            pnlPaymentInfo.Size = new Size(pnlMain.Width * 3 / 5 - 30, pnlMain.Height - 40);
            pnlPaymentMethods.Size = new Size(pnlMain.Width * 2 / 5 - 30, pnlMain.Height - 40);
            pnlPaymentMethods.Location = new Point(pnlMain.Width * 3 / 5, 20);
        }

        // Helper methods for creating controls
        private Label CreateLabel(string text, Point location, Control parent)
        {
            Label lbl = new Label()
            {
                Text = text,
                Location = location,
                AutoSize = true,
                Font = new Font("Arial", 12, FontStyle.Bold),
                ForeColor = Color.Black
            };
            parent.Controls.Add(lbl);
            return lbl;
        }

        private TextBox CreateTextBox(Point location, Control parent, int width)
        {
            TextBox txt = new TextBox()
            {
                Location = location,
                Size = new Size(width, 30),
                Font = new Font("Arial", 10),
            };
            parent.Controls.Add(txt);
            return txt;
        }

        private Button CreateMenuButton(string text, Point location)
        {
            return new Button()
            {
                Text = text,
                Location = location,
                Size = new Size(120, 30),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 10, FontStyle.Bold),
                Anchor = AnchorStyles.Right | AnchorStyles.Top
            };
        }

        private Button CreatePaymentMethodButton(string text, Point location, Control parent)
        {
            Button btn = new Button()
            {
                Text = text,
                Size = new Size(parent.Width - 20, 60),
                Location = location,
                BackColor = Color.White,
                ForeColor = Color.Black,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 1, BorderColor = Color.LightGray },
                Font = new Font("Arial", 12, FontStyle.Bold),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            parent.Controls.Add(btn);
            return btn;
        }

        private void ShowPaymentSuccessPopup()
        {
            // Create a new Form for the pop-up
            Form popupForm = new Form();
            popupForm.StartPosition = FormStartPosition.CenterParent;
            popupForm.Size = new Size(400, 200);
            popupForm.Text = "Thanh toán thành công";
            popupForm.FormBorderStyle = FormBorderStyle.FixedDialog;
            popupForm.MaximizeBox = false;
            popupForm.MinimizeBox = false;
            popupForm.BackColor = Color.White;
            popupForm.ShowInTaskbar = false;

            // Main Label for the success message
            Label lblMessage = new Label()
            {
                Text = "Thanh toán thành công, vui lòng theo dõi email để xác nhận lịch hẹn!",
                Font = new Font("Arial", 14, FontStyle.Bold),
                Location = new Point(20, 30),
                Size = new Size(popupForm.Width - 40, 80),
                TextAlign = ContentAlignment.MiddleCenter,
                ForeColor = Color.Black
            };
            popupForm.Controls.Add(lblMessage);

            // "Xong" (Done) button
            Button btnOK = new Button()
            {
                Text = "Xong",
                Size = new Size(100, 40),
                Location = new Point((popupForm.Width - 100) / 2, popupForm.Height - 80),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 12, FontStyle.Bold)
            };
            // Closes the pop-up when clicked
            btnOK.Click += (s, e) => popupForm.Close();
            popupForm.Controls.Add(btnOK);

            // Display the pop-up
            popupForm.ShowDialog();
        }
    }
}
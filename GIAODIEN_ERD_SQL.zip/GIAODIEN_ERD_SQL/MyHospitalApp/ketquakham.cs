﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace MyHospitalApp
{
    public class ketquakham : Form
    {
        // Controls
        private Panel pnlHeader, pnlMenu, pnlMain, pnlInfo, pnlResult, pnlAction;
        private PictureBox pbLogo, pbBannerImage, pbCalendarIcon;
        private Label lblHeaderTitle, lblDate, lblTime, lblDoctor, lblSpecialty, lblConclusion, lblTreatment, lblPrescription, lblCopyright;
        private TextBox txtDate, txtTime, txtDoctor, txtSpecialty, txtConclusion, txtTreatment, txtPrescription;
        private Button btnAppointment, btnHome, btnProfile, btnLogout, btnBack;

        public ketquakham()
        {
            this.Text = "Kết quả khám - Bệnh viện Hùng Vương";
            this.Size = new Size(1300, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Resize += new EventHandler(ketquakham_Resize);

            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Header Panel
            pnlHeader = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(this.Width, 120),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlHeader);

            // Logo Bệnh viện Hùng Vương
            pbLogo = new PictureBox()
            {
                Image = Image.FromFile(@"D:\Dow\logo.png"),
                SizeMode = PictureBoxSizeMode.Zoom,
                Location = new Point(20, 10),
                Size = new Size(200, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbLogo);

            // Banner image
            pbBannerImage = new PictureBox()
            {
                Image = Image.FromFile(@"D:\Dow\banner.png"),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Location = new Point(240, 10),
                Size = new Size(this.Width - 260, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbBannerImage);

            // Menu Panel
            pnlMenu = new Panel()
            {
                Location = new Point(0, 120),
                Size = new Size(this.Width, 60),
                BackColor = Color.FromArgb(0, 122, 204),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlMenu);

            // "Kết quả khám" Label
            lblHeaderTitle = new Label()
            {
                Text = "Kết quả khám",
                Location = new Point(20, 15),
                AutoSize = true,
                Font = new Font("Arial", 16, FontStyle.Bold),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlMenu.Controls.Add(lblHeaderTitle);

            // Menu Buttons
            btnAppointment = CreateMenuButton("Đặt lịch", new Point(pnlMenu.Width - 580, 15));
            btnHome = CreateMenuButton("Trang chủ", new Point(pnlMenu.Width - 430, 15));
            btnProfile = CreateMenuButton("Hồ sơ", new Point(pnlMenu.Width - 280, 15));
            pnlMenu.Controls.Add(btnAppointment);
            pnlMenu.Controls.Add(btnHome);
            pnlMenu.Controls.Add(btnProfile);

            // Logout Button
            btnLogout = new Button()
            {
                Text = "Đăng xuất",
                Location = new Point(pnlMenu.Width - 130, 15),
                Size = new Size(120, 30),
                BackColor = Color.Red,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 10, FontStyle.Bold),
                Anchor = AnchorStyles.Right | AnchorStyles.Top
            };
            pnlMenu.Controls.Add(btnLogout);

            // Main Panel
            pnlMain = new Panel()
            {
                Location = new Point(50, 200),
                Size = new Size(this.Width - 100, this.Height - 300),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom
            };
            this.Controls.Add(pnlMain);

            // Appointment Info Panel (Left side)
            pnlInfo = new Panel()
            {
                Location = new Point(20, 20),
                Size = new Size(pnlMain.Width * 1 / 3 - 30, pnlMain.Height - 40),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Bottom
            };
            pnlMain.Controls.Add(pnlInfo);

            // Info Labels
            lblDate = CreateLabel("Ngày khám", new Point(10, 20), pnlInfo, true);
            txtDate = CreateTextBox(new Point(10, 50), pnlInfo, pnlInfo.Width - 20, "17/09/2025");

            lblTime = CreateLabel("Giờ khám", new Point(10, 100), pnlInfo, true);
            txtTime = CreateTextBox(new Point(10, 130), pnlInfo, pnlInfo.Width - 20, "Sáng - 9:15");

            lblDoctor = CreateLabel("Bác sĩ", new Point(10, 180), pnlInfo, true);
            txtDoctor = CreateTextBox(new Point(10, 210), pnlInfo, pnlInfo.Width - 20, "Nguyễn Văn A");

            // Result Panel (Right side)
            pnlResult = new Panel()
            {
                Location = new Point(pnlMain.Width * 1 / 3, 20),
                Size = new Size(pnlMain.Width * 2 / 3 - 20, pnlMain.Height - 40),
                BackColor = Color.White,
                Anchor = AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom
            };
            pnlMain.Controls.Add(pnlResult);

            // Result Labels and TextBoxes
            lblSpecialty = CreateLabel("Khoa", new Point(10, 20), pnlResult, true);
            txtSpecialty = CreateTextBox(new Point(10, 50), pnlResult, (pnlResult.Width / 2) - 20, "Phụ nội - Nội tiết");

            lblTreatment = CreateLabel("Kiểu điều trị", new Point(pnlResult.Width / 2 + 10, 20), pnlResult, true);
            txtTreatment = CreateTextBox(new Point(pnlResult.Width / 2 + 10, 50), pnlResult, (pnlResult.Width / 2) - 20, "Ngoại trú");

            lblConclusion = CreateLabel("Kết luận", new Point(10, 100), pnlResult, true);
            txtConclusion = CreateTextBox(new Point(10, 130), pnlResult, (pnlResult.Width / 2) - 20, "Rối loạn nội tiết.");
            txtConclusion.Multiline = true;
            txtConclusion.Size = new Size(txtConclusion.Width, 100);

            // The "Đơn thuốc" label is now a clickable link-like label
            lblPrescription = new Label()
            {
                Text = "Đơn thuốc",
                Location = new Point(pnlResult.Width / 2 + 10, 100),
                AutoSize = true,
                Font = new Font("Arial", 14, FontStyle.Bold),
                ForeColor = Color.Blue, // Make it look like a link
                Cursor = Cursors.Hand, // Change cursor on hover
                Anchor = AnchorStyles.Top | AnchorStyles.Left
            };
            lblPrescription.Click += new EventHandler(lblPrescription_Click);
            pnlResult.Controls.Add(lblPrescription);

            txtPrescription = CreateTextBox(new Point(pnlResult.Width / 2 + 10, 130), pnlResult, (pnlResult.Width / 2) - 20, "");
            txtPrescription.Multiline = true;
            txtPrescription.Size = new Size(txtPrescription.Width, 100);

            // Back Button
            btnBack = new Button()
            {
                Text = "Trở lại",
                Size = new Size(120, 40),
                Location = new Point(pnlResult.Width - 140, pnlResult.Height - 60),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 12, FontStyle.Bold),
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };
            btnBack.Click += (s, e) => this.Close(); // Or navigate to the previous form
            pnlResult.Controls.Add(btnBack);

            // Calendar Icon (Drawn)
            pbCalendarIcon = new PictureBox()
            {
                Size = new Size(60, 60),
                Location = new Point(this.Width - 100, this.Height - 100),
                BackColor = Color.Transparent,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };
            this.Controls.Add(pbCalendarIcon);

            // Copyright
            lblCopyright = new Label()
            {
                Text = "Copyright © 2025 Bệnh viện Hùng Vương. All rights reserved.",
                Location = new Point(0, this.Height - 30),
                Size = new Size(this.Width, 30),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            this.Controls.Add(lblCopyright);
        }

        private void lblPrescription_Click(object sender, EventArgs e)
        {
            // Create a new form to display the prescription details
            Form prescriptionForm = new Form()
            {
                Text = "Chi tiết đơn thuốc",
                StartPosition = FormStartPosition.CenterParent,
                Size = new Size(600, 450),
                BackColor = Color.White
            };

            // Create a Panel to hold the DataGridView and other controls
            Panel pnlPrescription = new Panel()
            {
                Size = new Size(prescriptionForm.Width - 40, prescriptionForm.Height - 60),
                Location = new Point(20, 20),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom,
                BorderStyle = BorderStyle.FixedSingle
            };
            prescriptionForm.Controls.Add(pnlPrescription);

            // Header for the prescription form
            Label lblPrescriptionHeader = new Label()
            {
                Text = "Đơn thuốc",
                Location = new Point(20, 20),
                AutoSize = true,
                Font = new Font("Arial", 16, FontStyle.Bold),
                Anchor = AnchorStyles.Top | AnchorStyles.Left
            };
            pnlPrescription.Controls.Add(lblPrescriptionHeader);

            // Prescription Info (Mã đơn, Ngày)
            Label lblPrescriptionID = new Label() { Text = "Mã đơn: ", Location = new Point(20, 60), AutoSize = true, Font = new Font("Arial", 10), ForeColor = Color.Black };
            pnlPrescription.Controls.Add(lblPrescriptionID);

            Label lblPrescriptionDate = new Label() { Text = "Ngày: ", Location = new Point(20, 80), AutoSize = true, Font = new Font("Arial", 10), ForeColor = Color.Black };
            pnlPrescription.Controls.Add(lblPrescriptionDate);

            // DataGridView for drugs
            DataGridView dgvDrugs = new DataGridView()
            {
                Location = new Point(20, 120),
                Size = new Size(pnlPrescription.Width - 40, pnlPrescription.Height - 180),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom,
                BackgroundColor = Color.White,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                DefaultCellStyle = { Font = new Font("Arial", 10) },
                ColumnHeadersDefaultCellStyle = { Font = new Font("Arial", 10, FontStyle.Bold), BackColor = Color.LightGray, ForeColor = Color.Black }
            };

            // Set DataGridView columns
            dgvDrugs.Columns.Add("DrugName", "Tên thuốc");
            dgvDrugs.Columns.Add("Quantity", "Số lượng");
            dgvDrugs.Columns.Add("Instructions", "Hướng dẫn");
            pnlPrescription.Controls.Add(dgvDrugs);

            // Populate with sample data
            dgvDrugs.Rows.Add("Thuốc A", "1 viên", "Sáng, trưa, tối");
            dgvDrugs.Rows.Add("Thuốc B", "1 viên", "Sáng, tối");
            dgvDrugs.Rows.Add("Thuốc C", "2 viên", "Mỗi khi đau");

            // OK Button
            Button btnOK = new Button()
            {
                Text = "Xong",
                Size = new Size(100, 40),
                Location = new Point((prescriptionForm.Width - 140) / 2, prescriptionForm.Height - 100),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 12, FontStyle.Bold)
            };
            btnOK.Click += (s, ev) => prescriptionForm.Close();
            prescriptionForm.Controls.Add(btnOK);

            prescriptionForm.ShowDialog();
        }

        private void ketquakham_Resize(object sender, EventArgs e)
        {
            pnlHeader.Size = new Size(this.ClientSize.Width, 120);
            pnlMenu.Size = new Size(this.ClientSize.Width, 60);
            pnlMenu.Location = new Point(0, 120);
            pnlMain.Size = new Size(this.ClientSize.Width - 100, this.ClientSize.Height - 250);
            pnlMain.Location = new Point((this.ClientSize.Width - pnlMain.Width) / 2, 200);

            pbBannerImage.Size = new Size(this.ClientSize.Width - 260, 100);

            // Adjust menu button locations on resize
            btnAppointment.Location = new Point(pnlMenu.Width - 580, 15);
            btnHome.Location = new Point(pnlMenu.Width - 430, 15);
            btnProfile.Location = new Point(pnlMenu.Width - 280, 15);
            btnLogout.Location = new Point(pnlMenu.Width - 130, 15);

            pbCalendarIcon.Location = new Point(this.ClientSize.Width - 100, this.ClientSize.Height - 100);
            lblCopyright.Size = new Size(this.ClientSize.Width, 30);
            lblCopyright.Location = new Point(0, this.ClientSize.Height - 30);

            // Adjust sizes of panels inside pnlMain
            pnlInfo.Size = new Size(pnlMain.Width * 1 / 3 - 30, pnlMain.Height - 40);
            pnlResult.Size = new Size(pnlMain.Width * 2 / 3 - 20, pnlMain.Height - 40);
            pnlResult.Location = new Point(pnlMain.Width * 1 / 3, 20);
        }

        // Helper methods for creating controls
        private Label CreateLabel(string text, Point location, Control parent, bool bold = false)
        {
            Label lbl = new Label()
            {
                Text = text,
                Location = location,
                AutoSize = true,
                Font = new Font("Arial", 14, bold ? FontStyle.Bold : FontStyle.Regular),
                ForeColor = Color.Black
            };
            parent.Controls.Add(lbl);
            return lbl;
        }

        private TextBox CreateTextBox(Point location, Control parent, int width, string text)
        {
            TextBox txt = new TextBox()
            {
                Location = location,
                Size = new Size(width, 30),
                Font = new Font("Arial", 12),
                Text = text,
                ReadOnly = true,
                BorderStyle = BorderStyle.None,
                BackColor = Color.FromArgb(240, 240, 240),
            };
            parent.Controls.Add(txt);
            return txt;
        }

        private Button CreateMenuButton(string text, Point location)
        {
            return new Button()
            {
                Text = text,
                Location = location,
                Size = new Size(120, 30),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 10, FontStyle.Bold),
                Anchor = AnchorStyles.Right | AnchorStyles.Top
            };
        }
    }
}
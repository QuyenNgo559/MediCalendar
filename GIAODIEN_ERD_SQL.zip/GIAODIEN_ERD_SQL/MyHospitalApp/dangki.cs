﻿// dangki.cs
// Target: .NET Framework 4.7.2, WinForms
using System;
using System.Drawing;
using System.Windows.Forms;

namespace MyHospitalApp
{
    public class dangki : Form
    {
        // Controls
        private Panel pnlHeader;
        private Panel pnlMenu;
        private Panel pnlMain;
        private Label lblHeaderTitle;
        private PictureBox pbLogo, pbBannerImage;
        private Label lblEmailLabel, lblPhoneLabel, lblPasswordLabel, lblFullNameLabel, lblCCCDLabel, lblGenderLabel, lblDOBLabel;
        private TextBox txtEmail, txtPhone, txtPassword, txtFullName, txtCCCD;
        private ComboBox cmbGender;
        private DateTimePicker dtpDOB;
        private Button btnLogin, btnRegister;
        private Button btnHome, btnHistory, btnSchedule;
        private Label lblEmailHint, lblPasswordHint;
        private Label lblCopyright;

        // Pop-up panel
        private Panel pnlPopup;
        private Label lblPopupTitle;
        private Label lblPopupMessage;
        private Button btnPopupHome;
        private Button btnPopupLogin;

        public dangki()
        {
            this.Text = "Đăng ký - Bệnh viện Hùng Vương";
            this.Size = new Size(1300, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Resize += new EventHandler(dangki_Resize);

            // Header Panel
            pnlHeader = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(this.Width, 120),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlHeader);

            // Logo Bệnh viện Hùng Vương
            pbLogo = new PictureBox()
            {
                Image = Image.FromFile(@"D:\Dow\logo.png"),
                SizeMode = PictureBoxSizeMode.Zoom,
                Location = new Point(20, 10),
                Size = new Size(200, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbLogo);

            // Banner image
            pbBannerImage = new PictureBox()
            {
                Image = Image.FromFile(@"D:\Dow\banner.png"),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Location = new Point(240, 10),
                Size = new Size(this.Width - 260, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbBannerImage);

            // Thanh menu
            pnlMenu = new Panel()
            {
                Location = new Point(0, 120),
                Size = new Size(this.Width, 60),
                BackColor = Color.FromArgb(0, 122, 204),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlMenu);

            lblHeaderTitle = new Label()
            {
                Text = "Đăng ký",
                Location = new Point(20, 15),
                AutoSize = true,
                Font = new Font("Arial", 16, FontStyle.Bold),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlMenu.Controls.Add(lblHeaderTitle);

            btnHome = CreateMenuButton("Trang chủ", new Point(pnlMenu.Width - 450, 15));
            btnHistory = CreateMenuButton("Lịch sử hẹn", new Point(pnlMenu.Width - 300, 15));
            btnSchedule = CreateMenuButton("Đặt lịch", new Point(pnlMenu.Width - 150, 15));
            pnlMenu.Controls.Add(btnHome);
            pnlMenu.Controls.Add(btnHistory);
            pnlMenu.Controls.Add(btnSchedule);

            // Main Panel
            pnlMain = new Panel()
            {
                Location = new Point(50, 200),
                Size = new Size(1180, 450),
                BackColor = Color.White,
                Anchor = AnchorStyles.None
            };
            pnlMain.Paint += PnlMain_Paint;
            this.Controls.Add(pnlMain);

            // Labels and TextBoxes
            lblEmailLabel = CreateLabel("Địa chỉ email *", new Point(50, 30), pnlMain);
            txtEmail = CreateTextBox(new Point(50, 60), pnlMain);
            lblPhoneLabel = CreateLabel("Số điện thoại*", new Point(50, 120), pnlMain);
            txtPhone = CreateTextBox(new Point(50, 150), pnlMain);
            lblEmailHint = CreateHintLabel("Tên đăng nhập là số điện thoại đã đăng ký", new Point(50, 185), pnlMain);
            lblPasswordLabel = CreateLabel("Mật khẩu*", new Point(50, 240), pnlMain);
            txtPassword = CreateTextBox(new Point(50, 270), pnlMain);
            txtPassword.PasswordChar = '•';
            lblPasswordHint = CreateHintLabel("Mật khẩu ít nhất 8 chữ số, bao gồm các ký tự chữ hoa, chữ thường,\nvà các ký tự đặc biệt (!, @, #, $, %, &)", new Point(50, 305), pnlMain);
            lblFullNameLabel = CreateLabel("Họ và tên*", new Point(600, 30), pnlMain);
            txtFullName = CreateTextBox(new Point(600, 60), pnlMain);
            lblCCCDLabel = CreateLabel("Căn cước công dân*", new Point(600, 120), pnlMain);
            txtCCCD = CreateTextBox(new Point(600, 150), pnlMain);
            lblGenderLabel = CreateLabel("Giới tính", new Point(600, 240), pnlMain);
            cmbGender = new ComboBox()
            {
                Location = new Point(600, 270),
                Size = new Size(200, 30),
                Font = new Font("Arial", 10),
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbGender.Items.AddRange(new object[] { "Nam", "Nữ", "Khác" });
            pnlMain.Controls.Add(cmbGender);
            lblDOBLabel = CreateLabel("Ngày sinh*", new Point(850, 240), pnlMain);
            dtpDOB = new DateTimePicker()
            {
                Location = new Point(850, 270),
                Size = new Size(250, 30),
                Font = new Font("Arial", 10),
                Format = DateTimePickerFormat.Short
            };
            pnlMain.Controls.Add(dtpDOB);
            btnLogin = CreateButton("Đăng nhập", Color.DodgerBlue, new Point(600, 370), pnlMain);
            btnRegister = CreateButton("Đăng ký", Color.Red, new Point(850, 370), pnlMain);
            btnRegister.Click += BtnRegister_Click;

            // Copyright
            lblCopyright = new Label()
            {
                Text = "Copyright © 2025 Bệnh viện Hùng Vương. All rights reserved.",
                Location = new Point(0, this.Height - 60),
                Size = new Size(this.Width, 30),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            this.Controls.Add(lblCopyright);

            // Khởi tạo và cấu hình Pop-up Panel
            CreatePopupPanel();
        }

        private void CreatePopupPanel()
        {
            pnlPopup = new Panel()
            {
                Size = new Size(450, 250),
                BackColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                Visible = false // Ban đầu ẩn đi
            };

            // Thêm pnlPopup vào Form trước khi gọi BringToFront
            this.Controls.Add(pnlPopup);
            pnlPopup.BringToFront();

            lblPopupTitle = new Label()
            {
                Text = "Đăng ký thành công",
                Font = new Font("Arial", 18, FontStyle.Bold),
                ForeColor = Color.Red,
                Location = new Point(0, 30),
                Size = new Size(pnlPopup.Width, 30),
                TextAlign = ContentAlignment.MiddleCenter
            };
            pnlPopup.Controls.Add(lblPopupTitle);

            lblPopupMessage = new Label()
            {
                Text = "Tài khoản đã được đăng ký!",
                Font = new Font("Arial", 12, FontStyle.Regular),
                ForeColor = Color.Black,
                Location = new Point(0, 80),
                Size = new Size(pnlPopup.Width, 20),
                TextAlign = ContentAlignment.MiddleCenter
            };
            pnlPopup.Controls.Add(lblPopupMessage);

            btnPopupHome = CreateButton("Trang chủ", Color.Red, new Point(pnlPopup.Width / 2 - 220, 150), pnlPopup);
            btnPopupLogin = CreateButton("Đăng nhập", Color.DodgerBlue, new Point(pnlPopup.Width / 2 + 20, 150), pnlPopup);
        }

        private void BtnRegister_Click(object sender, EventArgs e)
        {
            pnlPopup.Location = new Point((this.ClientSize.Width - pnlPopup.Width) / 2, (this.ClientSize.Height - pnlPopup.Height) / 2);
            pnlPopup.Visible = true;
            // Có thể thêm logic xác thực dữ liệu tại đây trước khi hiển thị pop-up
        }

        private void dangki_Resize(object sender, EventArgs e)
        {
            // Điều chỉnh kích thước và vị trí của các Panel chính
            pnlHeader.Size = new Size(this.ClientSize.Width, 120);
            pnlMenu.Size = new Size(this.ClientSize.Width, 60);
            pnlMenu.Location = new Point(0, 120);

            // Cập nhật vị trí và kích thước của các nút menu
            btnHome.Location = new Point(pnlMenu.Width - 450, 15);
            btnHistory.Location = new Point(pnlMenu.Width - 300, 15);
            btnSchedule.Location = new Point(pnlMenu.Width - 150, 15);

            // Căn giữa pnlMain
            pnlMain.Location = new Point((this.ClientSize.Width - pnlMain.Width) / 2, (this.ClientSize.Height - pnlMain.Height) / 2);

            // Căn giữa pop-up
            if (pnlPopup != null && pnlPopup.Visible)
            {
                pnlPopup.Location = new Point((this.ClientSize.Width - pnlPopup.Width) / 2, (this.ClientSize.Height - pnlPopup.Height) / 2);
            }

            // Cập nhật vị trí của copyright
            lblCopyright.Size = new Size(this.ClientSize.Width, 30);
            lblCopyright.Location = new Point(0, this.ClientSize.Height - 30);
        }

        private Button CreateMenuButton(string text, Point location)
        {
            return new Button()
            {
                Text = text,
                Location = location,
                Size = new Size(120, 30),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 10, FontStyle.Bold),
                Anchor = AnchorStyles.Right | AnchorStyles.Top
            };
        }

        private Label CreateLabel(string text, Point location, Control parent)
        {
            Label lbl = new Label()
            {
                Text = text,
                Location = location,
                AutoSize = true,
                Font = new Font("Arial", 12, FontStyle.Bold),
                ForeColor = Color.Black
            };
            parent.Controls.Add(lbl);
            return lbl;
        }

        private Label CreateHintLabel(string text, Point location, Control parent)
        {
            Label lbl = new Label()
            {
                Text = text,
                Location = location,
                AutoSize = true,
                Font = new Font("Arial", 8, FontStyle.Regular),
                ForeColor = Color.Gray
            };
            parent.Controls.Add(lbl);
            return lbl;
        }

        private TextBox CreateTextBox(Point location, Control parent)
        {
            TextBox txt = new TextBox()
            {
                Location = location,
                Size = new Size(450, 30),
                Font = new Font("Arial", 10)
            };
            parent.Controls.Add(txt);
            return txt;
        }

        private Button CreateButton(string text, Color backColor, Point location, Control parent)
        {
            Button btn = new Button()
            {
                Text = text,
                Location = location,
                Size = new Size(200, 50),
                BackColor = backColor,
                ForeColor = Color.White,
                Font = new Font("Arial", 12, FontStyle.Bold),
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0, BorderColor = backColor }
            };
            parent.Controls.Add(btn);
            return btn;
        }

        private void PnlMain_Paint(object sender, PaintEventArgs e)
        {
            Panel p = sender as Panel;
            using (var pen = new Pen(Color.LightGray, 1))
            {
                e.Graphics.DrawRectangle(pen, 0, 0, p.Width - 1, p.Height - 1);
            }
        }
    }
}
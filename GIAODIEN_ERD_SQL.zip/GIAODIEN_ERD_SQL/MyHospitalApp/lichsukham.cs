﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace MyHospitalApp
{
    public class lichsukham : Form
    {
        // Controls
        private Panel pnlHeader, pnlMenu, pnlMain, pnlFilter, pnlResults;
        private PictureBox pbLogo, pbBannerImage, pbCalendarIcon;
        private Label lblHeaderTitle, lblFilterTitle, lblResultsTitle, lblDateFilter, lblDoctorFilter, lblCopyright;
        private TextBox txtDateFilter, txtDoctorFilter;
        private Button btnHistory, btnHome, btnAppointment, btnLogout, btnSearch, btnClearFilter;
        private DataGridView dgvAppointmentHistory;

        public lichsukham()
        {
            this.Text = "Lịch sử hẹn khám - Bệnh viện Hùng Vương";
            this.Size = new Size(1300, 750);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(240, 240, 240);
            this.Resize += new EventHandler(lichsukham_Resize);

            InitializeComponents();
        }

        private void InitializeComponents()
        {
            // Header Panel
            pnlHeader = new Panel()
            {
                Location = new Point(0, 0),
                Size = new Size(this.Width, 120),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlHeader);

            // Logo Bệnh viện Hùng Vương
            pbLogo = new PictureBox()
            {
                Image = Image.FromFile(@"D:\Dow\logo.png"),
                SizeMode = PictureBoxSizeMode.Zoom,
                Location = new Point(20, 10),
                Size = new Size(200, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbLogo);

            // Banner image
            pbBannerImage = new PictureBox()
            {
                Image = Image.FromFile(@"D:\Dow\banner.png"),
                SizeMode = PictureBoxSizeMode.StretchImage,
                Location = new Point(240, 10),
                Size = new Size(this.Width - 260, 100),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            pnlHeader.Controls.Add(pbBannerImage);

            // Menu Panel
            pnlMenu = new Panel()
            {
                Location = new Point(0, 120),
                Size = new Size(this.Width, 60),
                BackColor = Color.FromArgb(0, 122, 204),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top
            };
            this.Controls.Add(pnlMenu);

            // "Lịch sử hẹn khám" Label
            lblHeaderTitle = new Label()
            {
                Text = "Lịch sử hẹn khám",
                Location = new Point(20, 15),
                AutoSize = true,
                Font = new Font("Arial", 16, FontStyle.Bold),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Top
            };
            pnlMenu.Controls.Add(lblHeaderTitle);

            // Menu Buttons
            btnAppointment = CreateMenuButton("Đặt lịch", new Point(pnlMenu.Width - 580, 15));
            btnHome = CreateMenuButton("Trang chủ", new Point(pnlMenu.Width - 430, 15));
            btnHistory = CreateMenuButton("Hồ sơ", new Point(pnlMenu.Width - 280, 15));
            pnlMenu.Controls.Add(btnAppointment);
            pnlMenu.Controls.Add(btnHome);
            pnlMenu.Controls.Add(btnHistory);

            // Logout Button
            btnLogout = new Button()
            {
                Text = "Đăng xuất",
                Location = new Point(pnlMenu.Width - 130, 15),
                Size = new Size(120, 30),
                BackColor = Color.Red,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 10, FontStyle.Bold),
                Anchor = AnchorStyles.Right | AnchorStyles.Top
            };
            pnlMenu.Controls.Add(btnLogout);

            // Main Panel
            pnlMain = new Panel()
            {
                Location = new Point(50, 200),
                Size = new Size(this.Width - 100, this.Height - 300),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom
            };
            this.Controls.Add(pnlMain);

            // Filter Panel (Left side)
            pnlFilter = new Panel()
            {
                Location = new Point(20, 20),
                Size = new Size(pnlMain.Width * 1 / 4, pnlMain.Height - 40),
                BackColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Top | AnchorStyles.Bottom
            };
            pnlMain.Controls.Add(pnlFilter);

            // Filter Title
            lblFilterTitle = new Label()
            {
                Text = "Bộ lọc",
                Location = new Point(10, 10),
                Font = new Font("Arial", 14, FontStyle.Bold),
                AutoSize = true,
                Anchor = AnchorStyles.Top | AnchorStyles.Left
            };
            pnlFilter.Controls.Add(lblFilterTitle);

            // Date Filter
            lblDateFilter = CreateLabel("Theo ngày", new Point(10, 50), pnlFilter);
            txtDateFilter = CreateTextBox(new Point(10, 80), pnlFilter, pnlFilter.Width - 20);

            // Doctor Filter
            lblDoctorFilter = CreateLabel("Theo bác sĩ", new Point(10, 120), pnlFilter);
            txtDoctorFilter = CreateTextBox(new Point(10, 150), pnlFilter, pnlFilter.Width - 20);

            // Search Button
            btnSearch = new Button()
            {
                Text = "Tìm kiếm",
                Location = new Point(10, 190),
                Size = new Size(pnlFilter.Width - 20, 40),
                BackColor = Color.FromArgb(255, 102, 0),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 12, FontStyle.Bold),
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right
            };
            pnlFilter.Controls.Add(btnSearch);

            // Results Panel (Right side)
            pnlResults = new Panel()
            {
                Location = new Point(pnlMain.Width * 1 / 4 + 40, 20),
                Size = new Size(pnlMain.Width * 3 / 4 - 60, pnlMain.Height - 40),
                BackColor = Color.White,
                Anchor = AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom
            };
            pnlMain.Controls.Add(pnlResults);

            // Results Title
            lblResultsTitle = new Label()
            {
                Text = "Kết quả tìm kiếm",
                Location = new Point(10, 10),
                Font = new Font("Arial", 14, FontStyle.Bold),
                AutoSize = true,
                Anchor = AnchorStyles.Top | AnchorStyles.Left
            };
            pnlResults.Controls.Add(lblResultsTitle);

            // Clear Filter Button
            btnClearFilter = new Button()
            {
                Text = "Xóa bộ lọc?",
                Location = new Point(pnlResults.Width - 150, 10),
                Size = new Size(120, 30),
                BackColor = Color.White,
                ForeColor = Color.FromArgb(0, 122, 204),
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 10, FontStyle.Bold),
                Anchor = AnchorStyles.Top | AnchorStyles.Right
            };
            pnlResults.Controls.Add(btnClearFilter);

            // DataGridView for appointment history
            dgvAppointmentHistory = new DataGridView()
            {
                Location = new Point(10, 50),
                Size = new Size(pnlResults.Width - 20, pnlResults.Height - 60),
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Top | AnchorStyles.Bottom,
                BackgroundColor = Color.White,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                DefaultCellStyle = { Font = new Font("Arial", 10) },
                ColumnHeadersDefaultCellStyle = { Font = new Font("Arial", 10, FontStyle.Bold), BackColor = Color.FromArgb(0, 122, 204), ForeColor = Color.White }
            };

            // Set DataGridView columns
            dgvAppointmentHistory.Columns.Add("Date", "Ngày");
            dgvAppointmentHistory.Columns.Add("Time", "Giờ");
            dgvAppointmentHistory.Columns.Add("Doctor", "Bác sĩ");
            dgvAppointmentHistory.Columns.Add("Type", "Nội trú/ngoại trú");
            dgvAppointmentHistory.Columns.Add("Conclusion", "Kết luận");
            pnlResults.Controls.Add(dgvAppointmentHistory);

            // Populate DataGridView with sample data
            dgvAppointmentHistory.Rows.Add("17/09/2025", "9:15", "Nguyễn Văn A", "Ngoại trú", "Rối loạn nội tiết");
            dgvAppointmentHistory.Rows.Add("17/09/2025", "9:15", "Nguyễn Văn A", "Ngoại trú", "Rối loạn nội tiết");
            dgvAppointmentHistory.Rows.Add("17/09/2025", "9:15", "Nguyễn Văn A", "Ngoại trú", "Rối loạn nội tiết");

            // Calendar Icon (Drawn)
            pbCalendarIcon = new PictureBox()
            {
                Size = new Size(60, 60),
                Location = new Point(this.Width - 100, this.Height - 100),
                BackColor = Color.Transparent,
                Anchor = AnchorStyles.Bottom | AnchorStyles.Right
            };
            this.Controls.Add(pbCalendarIcon);

            // Copyright
            lblCopyright = new Label()
            {
                Text = "Copyright © 2025 Bệnh viện Hùng Vương. All rights reserved.",
                Location = new Point(0, this.Height - 30),
                Size = new Size(this.Width, 30),
                TextAlign = ContentAlignment.MiddleCenter,
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                Anchor = AnchorStyles.Left | AnchorStyles.Right | AnchorStyles.Bottom
            };
            this.Controls.Add(lblCopyright);
        }

        private void lichsukham_Resize(object sender, EventArgs e)
        {
            pnlHeader.Size = new Size(this.ClientSize.Width, 120);
            pnlMenu.Size = new Size(this.ClientSize.Width, 60);
            pnlMenu.Location = new Point(0, 120);
            pnlMain.Size = new Size(this.ClientSize.Width - 100, this.ClientSize.Height - 250);
            pnlMain.Location = new Point((this.ClientSize.Width - pnlMain.Width) / 2, 200);

            pbBannerImage.Size = new Size(this.ClientSize.Width - 260, 100);

            // Adjust menu button locations on resize
            btnAppointment.Location = new Point(pnlMenu.Width - 580, 15);
            btnHome.Location = new Point(pnlMenu.Width - 430, 15);
            btnHistory.Location = new Point(pnlMenu.Width - 280, 15);
            btnLogout.Location = new Point(pnlMenu.Width - 130, 15);

            pbCalendarIcon.Location = new Point(this.ClientSize.Width - 100, this.ClientSize.Height - 100);
            lblCopyright.Size = new Size(this.ClientSize.Width, 30);
            lblCopyright.Location = new Point(0, this.ClientSize.Height - 30);

            // Adjust sizes of panels inside pnlMain
            pnlFilter.Size = new Size(pnlMain.Width * 1 / 4, pnlMain.Height - 40);
            pnlResults.Size = new Size(pnlMain.Width * 3 / 4 - 60, pnlMain.Height - 40);
            pnlResults.Location = new Point(pnlMain.Width * 1 / 4 + 40, 20);
        }

        // Helper methods for creating controls
        private Label CreateLabel(string text, Point location, Control parent)
        {
            Label lbl = new Label()
            {
                Text = text,
                Location = location,
                AutoSize = true,
                Font = new Font("Arial", 12, FontStyle.Bold),
                ForeColor = Color.Black
            };
            parent.Controls.Add(lbl);
            return lbl;
        }

        private TextBox CreateTextBox(Point location, Control parent, int width)
        {
            TextBox txt = new TextBox()
            {
                Location = location,
                Size = new Size(width, 30),
                Font = new Font("Arial", 10),
            };
            parent.Controls.Add(txt);
            return txt;
        }

        private Button CreateMenuButton(string text, Point location)
        {
            return new Button()
            {
                Text = text,
                Location = location,
                Size = new Size(120, 30),
                BackColor = Color.FromArgb(0, 122, 204),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Font = new Font("Arial", 10, FontStyle.Bold),
                Anchor = AnchorStyles.Right | AnchorStyles.Top
            };
        }
    }
}
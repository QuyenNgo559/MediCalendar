﻿// TrangChuUser.cs
// Target: .NET Framework 4.7.2, WinForms
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace MyHospitalApp
{
   
    public class TrangChuUser : Form
    {
        // Controls
        private PictureBox pbLogo;
        private PictureBox pbBanner;
        private Panel topPanel;
        private Panel headerBluePanel;
        private Label lblWelcome;
        private Label lblChoose;
        private Panel contentPanel;
        private RoundedButton btnDangNhap, btnDatLich, btnLichSu;
        private PictureBox pbCalendar;
        private Panel footerPanel;
        private Label lblCopyright;

        public TrangChuUser()
        {
            InitializeComponent();
        }

        // --- Toàn bộ InitializeComponent (đã tinh chỉnh layout để không bị "dính vào nhau") ---
        private void InitializeComponent()
        {
            // Form
            this.Text = "Trang chủ - User";
            this.BackColor = Color.FromArgb(245, 247, 249); // light grey
            this.WindowState = FormWindowState.Maximized;
            this.MinimumSize = new Size(1000, 700);

            // Header container: chứa topPanel (logo/contact) và headerBluePanel (welcome)
            Panel headerContainer = new Panel
            {
                Dock = DockStyle.Top,
                AutoSize = false,
                Height = 230,
                BackColor = Color.Transparent
            };

            // --- Top panel for logo + banner (white background) ---
            topPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 140,
                BackColor = Color.White,
                Padding = new Padding(10)
            };

            // Logo (left)
            pbLogo = new PictureBox
            {
                Dock = DockStyle.Left,
                Width = 360,
                SizeMode = PictureBoxSizeMode.Zoom,
                BorderStyle = BorderStyle.None,
                Margin = new Padding(0)
            };
            try
            {
                pbLogo.Image = Image.FromFile(@"D:\\Dow\logo.png");
            }
            catch
            {
                pbLogo.BackColor = Color.LightGray;
                pbLogo.Paint += (s, e) =>
                {
                    TextRenderer.DrawText(e.Graphics, "Logo\n(D:\\Dow-logo.png)", this.Font, new Rectangle(0, 0, pbLogo.Width, pbLogo.Height), Color.DimGray, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                };
            }
            topPanel.Controls.Add(pbLogo);

            // Banner (right)
            pbBanner = new PictureBox
            {
                Dock = DockStyle.Right,
                Width = 640,
                SizeMode = PictureBoxSizeMode.StretchImage,
                Margin = new Padding(0)
            };
            try
            {
                pbBanner.Image = Image.FromFile(@"D:\\Dow\banner.png");
            }
            catch
            {
                pbBanner.BackColor = Color.LightGray;
                pbBanner.Paint += (s, e) =>
                {
                    TextRenderer.DrawText(e.Graphics, "Banner\n(D:\\Dow-banner.png)", this.Font, new Rectangle(0, 0, pbBanner.Width, pbBanner.Height), Color.DimGray, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
                };
            }
            topPanel.Controls.Add(pbBanner);

            // --- Header blue welcome panel (under the white top panel) ---
            headerBluePanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 90,
                BackColor = Color.FromArgb(0, 140, 200) // bright blue
            };

            lblWelcome = new Label
            {
                Text = "Chào mừng đến với hệ thống đặt lịch khám trực tuyến!",
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 22, FontStyle.Bold),
                ForeColor = Color.White
            };
            headerBluePanel.Controls.Add(lblWelcome);

            // Add header controls in correct order: topPanel (white) first, then headerBluePanel (blue) so blue sits under
            headerContainer.Controls.Add(headerBluePanel);
            headerContainer.Controls.Add(topPanel);

            // Add header container to form
            this.Controls.Add(headerContainer);

            // Main content panel
            contentPanel = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(245, 247, 249),
                Padding = new Padding(40)
            };
            this.Controls.Add(contentPanel);

            // TẠO MỘT PANEL MỚI ĐỂ CHỨA VÀ CĂN GIỮA TIÊU ĐỀ VÀ CÁC NÚT
            Panel centerContainer = new Panel
            {
                Dock = DockStyle.None, // Quan trọng: Đổi từ DockStyle.Fill sang None
                Width = 1000,
                Height = 350,
                BackColor = Color.Transparent,
                Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right // Neo để tự động căn giữa
            };
            contentPanel.Controls.Add(centerContainer);

            // Cập nhật vị trí của centerContainer khi form thay đổi kích thước
            this.Resize += (s, e) =>
            {
                centerContainer.Left = (contentPanel.ClientSize.Width - centerContainer.Width) / 2;
                centerContainer.Top = (contentPanel.ClientSize.Height - centerContainer.Height) / 2;
            };

            // Instruction title
            lblChoose = new Label
            {
                Text = "Vui lòng chọn dịch vụ để được phục vụ tốt nhất",
                AutoSize = false,
                Height = 60,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 20, FontStyle.Bold),
                Dock = DockStyle.Top,
                ForeColor = Color.FromArgb(40, 40, 40)
            };
            centerContainer.Controls.Add(lblChoose);

            // --- Sử dụng TableLayoutPanel để giữ 3 cột bằng nhau cho các nút ---
            TableLayoutPanel buttonsTable = new TableLayoutPanel
            {
                Dock = DockStyle.Top, // Đã đổi lại thành DockStyle.Top
                Height = 260,
                ColumnCount = 3,
                RowCount = 1,
                AutoSize = false,
                BackColor = Color.Transparent,
                Margin = new Padding(0),
                Padding = new Padding(40, 10, 40, 10)
            };

            // Cột bằng nhau
            buttonsTable.ColumnStyles.Clear();
            buttonsTable.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
            buttonsTable.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));
            buttonsTable.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.34f));

            // Tạo panel cho mỗi ô để cho phép đặt avatar và căn chỉnh vị trí linh hoạt
            Panel cell1 = CreateButtonCell(out btnDangNhap);
            Panel cell2 = CreateButtonCell(out btnDatLich);
            Panel cell3 = CreateButtonCell(out btnLichSu);

            // Đặt văn bản và kích thước
            btnDangNhap.Text = "Đăng nhập";
            btnDatLich.Text = "Đặt lịch";
            btnLichSu.Text = "Lịch sử hẹn";

            btnDangNhap.Width = btnDatLich.Width = btnLichSu.Width = 320;
            btnDangNhap.Height = btnDatLich.Height = btnLichSu.Height = 140;
            btnDangNhap.Font = btnDatLich.Font = btnLichSu.Font = new Font("Segoe UI", 18, FontStyle.Bold);

            // Thêm các ô vào bảng
            buttonsTable.Controls.Add(cell1, 0, 0);
            buttonsTable.Controls.Add(cell2, 1, 0);
            buttonsTable.Controls.Add(cell3, 2, 0);

            // Thêm bảng vào centerContainer sau lblChoose
            centerContainer.Controls.Add(buttonsTable);

            // Calendar floating icon bottom-right (keep on top)
            pbCalendar = new PictureBox
            {
                Size = new Size(80, 80),
                BackColor = Color.FromArgb(19, 55, 93),
                SizeMode = PictureBoxSizeMode.CenterImage
            };
            pbCalendar.Paint += (s, e) =>
            {
                Graphics g = e.Graphics;
                g.SmoothingMode = SmoothingMode.AntiAlias;
                using (Brush b = new SolidBrush(pbCalendar.BackColor)) g.FillEllipse(b, 0, 0, pbCalendar.Width, pbCalendar.Height);
                using (Pen pen = new Pen(Color.White, 3))
                {
                    Rectangle r = new Rectangle(16, 22, 48, 40);
                    g.DrawRectangle(pen, r);
                    g.DrawLine(pen, r.Left, r.Top + 10, r.Right, r.Top + 10);
                    g.FillRectangle(Brushes.White, r.Left + 6, r.Bottom - 12, 6, 6);
                    g.FillRectangle(Brushes.White, r.Left + 20, r.Bottom - 12, 6, 6);
                }
            };
            this.Controls.Add(pbCalendar);
            pbCalendar.BringToFront();

            // Keep calendar anchored bottom-right on resize
            Action placeCalendar = () =>
            {
                pbCalendar.Location = new Point(this.ClientSize.Width - pbCalendar.Width - 30, this.ClientSize.Height - pbCalendar.Height - 80);
            };
            this.Resize += (s, e) => placeCalendar();
            // initial place after form is created
            this.Load += (s, e) => placeCalendar();

            // Footer blue bar
            footerPanel = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 50,
                BackColor = Color.FromArgb(0, 140, 200)
            };
            this.Controls.Add(footerPanel);

            lblCopyright = new Label
            {
                Text = "Copyright © 2025 Bệnh Viện Hùng Vương. All rights reserved.",
                ForeColor = Color.White,
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 10, FontStyle.Regular)
            };
            footerPanel.Controls.Add(lblCopyright);

            // Events - simple handlers
            btnDangNhap.Click += (s, e) => MessageBox.Show("Bạn ấn Đăng nhập");
            btnDatLich.Click += (s, e) => MessageBox.Show("Bạn ấn Đặt lịch");
            btnLichSu.Click += (s, e) => MessageBox.Show("Bạn ấn Lịch sử hẹn");
            pbCalendar.Click += (s, e) => MessageBox.Show("Mở lịch...");
        }

        // Helper to create a cell Panel with centered rounded button
        private Panel CreateButtonCell(out RoundedButton btn)
        {
            Panel cell = new Panel
            {
                Dock = DockStyle.Fill,
                Margin = new Padding(10),
                BackColor = Color.Transparent
            };

            btn = new RoundedButton
            {
                Width = 320,
                Height = 140,
                Anchor = AnchorStyles.None
            };

            // Use a local variable so the lambda captures a non-ref/out variable
            RoundedButton localBtn = btn;

            // Add the button to the cell first
            cell.Controls.Add(localBtn);

            // Ensure the button is centered whenever the cell lays out
            cell.Layout += (s, e) =>
            {
                localBtn.Location = new Point(Math.Max(10, (cell.ClientSize.Width - localBtn.Width) / 2), Math.Max(8, (cell.ClientSize.Height - localBtn.Height) / 2));
            };

            // Also trigger initial layout when size changes (helps at startup)
            cell.SizeChanged += (s, e) => cell.PerformLayout();

            return cell;
        }
    }

    // Custom rounded button
    public class RoundedButton : Button
    {
        public int CornerRadius { get; set; } = 28;
        public Color ButtonColor { get; set; } = Color.FromArgb(0, 140, 200);
        public Color HoverColor { get; set; } = Color.FromArgb(0, 120, 180);
        private bool isHover = false;

        public RoundedButton()
        {
            this.FlatStyle = FlatStyle.Flat;
            this.FlatAppearance.BorderSize = 0;
            this.ForeColor = Color.White;
            this.BackColor = Color.Transparent;
            this.Cursor = Cursors.Hand;
            this.DoubleBuffered = true;
            this.Padding = new Padding(10);
            this.MouseEnter += (s, e) => { isHover = true; Invalidate(); };
            this.MouseLeave += (s, e) => { isHover = false; Invalidate(); };
        }

        protected override void OnPaint(PaintEventArgs pevent)
        {
            pevent.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            Rectangle rect = this.ClientRectangle;
            rect.Inflate(-1, -1);
            Color fill = isHover ? HoverColor : ButtonColor;

            using (GraphicsPath path = RoundRect(rect, CornerRadius))
            using (SolidBrush brush = new SolidBrush(fill))
            {
                pevent.Graphics.FillPath(brush, path);
            }

            // Draw text centered
            TextFormatFlags flags = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.SingleLine;
            TextRenderer.DrawText(pevent.Graphics, this.Text, this.Font, rect, this.ForeColor, flags);
        }

        private GraphicsPath RoundRect(Rectangle r, int radius)
        {
            GraphicsPath gp = new GraphicsPath();
            int d = radius * 2;
            gp.AddArc(r.Left, r.Top, d, d, 180, 90);
            gp.AddArc(r.Right - d, r.Top, d, d, 270, 90);
            gp.AddArc(r.Right - d, r.Bottom - d, d, d, 0, 90);
            gp.AddArc(r.Left, r.Bottom - d, d, d, 90, 90);
            gp.CloseFigure();
            return gp;
        }
    }
}
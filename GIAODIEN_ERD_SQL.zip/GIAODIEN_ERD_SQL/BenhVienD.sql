﻿CREATE DATABASE BenhVienD
GO
USE BenhVienD;
GO
-- Bảng BenhNhan
CREATE TABLE BenhNhan (
  MaBN VARCHAR(20) NOT NULL PRIMARY KEY,
  HoTen VARCHAR(100) NOT NULL,
  NgaySinh DATE,
  SDT VARCHAR(20),
  Email VARCHAR(100),
  CCCD VARCHAR(20) UNIQUE,
  MatKhau VARCHAR(255) NOT NULL, -- lưu hashed password
  Diachi VARCHAR(255),
) 

-- Bảng BacSi
CREATE TABLE BacSi (
  MaBS VARCHAR(20) NOT NULL PRIMARY KEY,
  HoTen VARCHAR(100) NOT NULL,
  ChuyenKhoa VARCHAR(100),
  MatKhau VARCHAR(255) NOT NULL,
) 

-- Bảng LichKham
CREATE TABLE LichKham (
  MaLich VARCHAR(30) NOT NULL PRIMARY KEY,
  MaBN VARCHAR(20) NOT NULL,
  MaBS VARCHAR(20) NOT NULL,
  NgayGio DATETIME NOT NULL,
  STT INT,                           -- số thứ tự trong ngày
  TrangThai VARCHAR(30) DEFAULT 'DangCho',
  GhiChu TEXT,
  FOREIGN KEY (MaBN) REFERENCES BenhNhan(MaBN),
  FOREIGN KEY (MaBS) REFERENCES BacSi(MaBS),
) 

-- Bảng DonThuoc
CREATE TABLE DonThuoc (
  MaDon VARCHAR(30) NOT NULL PRIMARY KEY,
  MaLich VARCHAR(30) NOT NULL,
  NgayLap DATETIME DEFAULT CURRENT_TIMESTAMP,
  TenThuoc TEXT NOT NULL,
  SoLuong INT DEFAULT 1,
  HuongDan TEXT,
  FOREIGN KEY (MaLich) REFERENCES LichKham(MaLich),
) 

-- Bảng KetQuaKham
CREATE TABLE KetQuaKham (
  MaKQ VARCHAR(30) NOT NULL PRIMARY KEY,
  MaLich VARCHAR(30) NOT NULL,
  ChanDoan TEXT,
  GhiChu TEXT,
  NgayKham DATETIME NOT NULL,
  FOREIGN KEY (MaLich) REFERENCES LichKham(MaLich), 
) 

-- Bảng ThanhToan
CREATE TABLE ThanhToan (
  MaTT VARCHAR(30) NOT NULL PRIMARY KEY,
  MaLich VARCHAR(30) NOT NULL,
  SoTien DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  PhuongThuc VARCHAR(50),
  TrangThai VARCHAR(30) DEFAULT 'ChoThanhToan',
  NgayTT DATETIME,
  FOREIGN KEY (MaLich) REFERENCES LichKham(MaLich),
) 

﻿CREATE DATABASE Medicalendar
GO
USE Medicalendar;
GO
-- Xóa km con trước -> cha
DROP TABLE IF EXISTS DonThuoc;
DROP TABLE IF EXISTS KetQuaKham;
DROP TABLE IF EXISTS ThanhToan;
DROP TABLE IF EXISTS LichKham;
DROP TABLE IF EXISTS BacSi;
DROP TABLE IF EXISTS BenhNhan;

-- Bảng bệnh nhân
CREATE TABLE BenhNhan (
  MaBN VARCHAR(50) PRIMARY KEY,
  HoTen VARCHAR(200),
  NgaySinh DATE,
  SDT VARCHAR(20),
  Email VARCHAR(255),
  CCCD VARCHAR(50),
  MatKhau VARCHAR(255)
);

-- Bảng bác sĩ
CREATE TABLE BacSi (
  MaBS VARCHAR(50) PRIMARY KEY,
  HoTen VARCHAR(200),
  ChuyenKhoa VARCHAR(200),
  MatKhau VARCHAR(255)
);

-- Bảng lịch khám (liên kết tới bệnh nhân và bác sĩ)
CREATE TABLE LichKham (
  MaLich VARCHAR(50) PRIMARY KEY,
  MaBN VARCHAR(50) NOT NULL,
  MaBS VARCHAR(50) NOT NULL,
  NgayGio DATETIME,
  STT INT,
  TrangThai VARCHAR(100),
  FOREIGN KEY (MaBN) REFERENCES BenhNhan(MaBN),
  FOREIGN KEY (MaBS) REFERENCES BacSi(MaBS)
);

-- Đơn thuốc (một lịch có thể nhiều đơn)
CREATE TABLE DonThuoc (
  MaDon VARCHAR(50) PRIMARY KEY,
  MaLich VARCHAR(50) NOT NULL,
  NgayLap DATETIME,
  TenThuoc TEXT,
  SoLuong INT,
  HuongDan TEXT,
  FOREIGN KEY (MaLich) REFERENCES LichKham(MaLich)
);

-- Kết quả khám (mỗi lịch tối đa 1 kết quả)
CREATE TABLE KetQuaKham (
  MaKQ VARCHAR(50) PRIMARY KEY,
  MaLich VARCHAR(50) NOT NULL UNIQUE,
  ChanDoan TEXT,
  GhiChu TEXT,
  NgayKham DATE,
  FOREIGN KEY (MaLich) REFERENCES LichKham(MaLich)
);

-- Thanh toán (mỗi lịch tối đa 1 thanh toán)
CREATE TABLE ThanhToan (
  MaTT VARCHAR(50) PRIMARY KEY,
  MaLich VARCHAR(50) NOT NULL UNIQUE,
  SoTien DECIMAL(12,2),
  PhuongThuc VARCHAR(100),
  TrangThai VARCHAR(100),
  NgayTT DATETIME,
  FOREIGN KEY (MaLich) REFERENCES LichKham(MaLich)
);

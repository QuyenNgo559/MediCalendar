﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace QLBV1.Models
{
    public partial class Thuoc
    {
        public Thuoc()
        {
            ChiTietDonThuoc = new HashSet<ChiTietDonThuoc>();
        }

        public string MaThuoc { get; set; }
        public string TenThuoc { get; set; }
        public string DonVi { get; set; }
        public decimal? Gia { get; set; }
        public string MoTa { get; set; }

        public virtual ICollection<ChiTietDonThuoc> ChiTietDonThuoc { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace QLBV1.Models
{
    public partial class ThongBao
    {
        public string MaTb { get; set; }
        public string MaNguoiGui { get; set; }
        public string MaNguoiNhan { get; set; }
        public string MaLich { get; set; }
        public string TieuDe { get; set; }
        public string NoiDung { get; set; }
        public string LoaiThongBao { get; set; }
        public DateTime? NgayGui { get; set; }
        public string TrangThai { get; set; }

        public virtual LichKham MaLichNavigation { get; set; }
        public virtual Users MaNguoiGuiNavigation { get; set; }
        public virtual Users MaNguoiNhanNavigation { get; set; }
    }
}

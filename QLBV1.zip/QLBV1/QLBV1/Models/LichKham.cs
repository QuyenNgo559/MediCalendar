﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace QLBV1.Models
{
    public partial class LichKham
    {
        public LichKham()
        {
            DonThuoc = new HashSet<DonThuoc>();
            HoaDon = new HashSet<HoaDon>();
            KetQuaKham = new HashSet<KetQuaKham>();
            ThongBao = new HashSet<ThongBao>();
        }

        public string MaLich { get; set; }
        public string MaBn { get; set; }
        public string MaBs { get; set; }
        public DateTime? NgayGio { get; set; }
        public int? Stt { get; set; }
        public string TrangThai { get; set; }
        public string GhiChu { get; set; }

        public virtual Users MaBnNavigation { get; set; }
        public virtual Users MaBsNavigation { get; set; }
        public virtual ICollection<DonThuoc> DonThuoc { get; set; }
        public virtual ICollection<HoaDon> HoaDon { get; set; }
        public virtual ICollection<KetQuaKham> KetQuaKham { get; set; }
        public virtual ICollection<ThongBao> ThongBao { get; set; }
    }
}

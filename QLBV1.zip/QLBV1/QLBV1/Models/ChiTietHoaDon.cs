﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace QLBV1.Models
{
    public partial class ChiTietHoaDon
    {
        public string MaCthd { get; set; }
        public string MaTt { get; set; }
        public string NoiDung { get; set; }
        public decimal? SoTien { get; set; }

        public virtual HoaDon MaTtNavigation { get; set; }
    }
}

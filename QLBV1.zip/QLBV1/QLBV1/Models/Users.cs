﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace QLBV1.Models
{
    public partial class Users
    {
        public Users()
        {
            LichKhamMaBnNavigation = new HashSet<LichKham>();
            LichKhamMaBsNavigation = new HashSet<LichKham>();
            ThongBaoMaNguoiGuiNavigation = new HashSet<ThongBao>();
            ThongBaoMaNguoiNhanNavigation = new HashSet<ThongBao>();
        }

        public string UserId { get; set; }
        public string HoTen { get; set; }
        public DateTime? NgaySinh { get; set; }
        public string Sdt { get; set; }
        public string Email { get; set; }
        public string Cccd { get; set; }
        public string MatKhau { get; set; }
        public string DiaChi { get; set; }
        public string RoleId { get; set; }
        public string MaCk { get; set; }

        public virtual ChuyenKhoa MaCkNavigation { get; set; }
        public virtual Roles Role { get; set; }
        public virtual ICollection<LichKham> LichKhamMaBnNavigation { get; set; }
        public virtual ICollection<LichKham> LichKhamMaBsNavigation { get; set; }
        public virtual ICollection<ThongBao> ThongBaoMaNguoiGuiNavigation { get; set; }
        public virtual ICollection<ThongBao> ThongBaoMaNguoiNhanNavigation { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace QLBV1.Models
{
    public partial class KetQuaKham
    {
        public string MaKq { get; set; }
        public string MaLich { get; set; }
        public string ChanDoan { get; set; }
        public string GhiChu { get; set; }
        public DateTime? NgayKham { get; set; }

        public virtual LichKham MaLichNavigation { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace QLBV1.Models
{
    public partial class HoaDon
    {
        public HoaDon()
        {
            ChiTietHoaDon = new HashSet<ChiTietHoaDon>();
        }

        public string MaTt { get; set; }
        public string MaLich { get; set; }
        public decimal? SoTien { get; set; }
        public string PhuongThuc { get; set; }
        public string TrangThai { get; set; }
        public DateTime? NgayTt { get; set; }

        public virtual LichKham MaLichNavigation { get; set; }
        public virtual ICollection<ChiTietHoaDon> ChiTietHoaDon { get; set; }
    }
}

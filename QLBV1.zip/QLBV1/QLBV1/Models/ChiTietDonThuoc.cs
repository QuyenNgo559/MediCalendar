﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace QLBV1.Models
{
    public partial class ChiTietDonThuoc
    {
        public string MaCt { get; set; }
        public string MaDon { get; set; }
        public string MaThuoc { get; set; }
        public int? SoLuong { get; set; }
        public string HuongDan { get; set; }

        public virtual DonThuoc MaDonNavigation { get; set; }
        public virtual Thuoc MaThuocNavigation { get; set; }
    }
}

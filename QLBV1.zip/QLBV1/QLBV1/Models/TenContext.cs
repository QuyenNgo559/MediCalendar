﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace QLBV1.Models
{
    public partial class TenContext : DbContext
    {
        public TenContext()
        {
        }

        public TenContext(DbContextOptions<TenContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ChiTietDonThuoc> ChiTietDonThuoc { get; set; }
        public virtual DbSet<ChiTietHoaDon> ChiTietHoaDon { get; set; }
        public virtual DbSet<ChuyenKhoa> ChuyenKhoa { get; set; }
        public virtual DbSet<DonThuoc> DonThuoc { get; set; }
        public virtual DbSet<HoaDon> HoaDon { get; set; }
        public virtual DbSet<KetQuaKham> KetQuaKham { get; set; }
        public virtual DbSet<LichKham> LichKham { get; set; }
        public virtual DbSet<Roles> Roles { get; set; }
        public virtual DbSet<ThongBao> ThongBao { get; set; }
        public virtual DbSet<Thuoc> Thuoc { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=LAPTOP-DVMMQ4G6\\SQLEXPRESS;Database=MediCalendar;Trusted_Connection=True;TrustServerCertificate=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ChiTietDonThuoc>(entity =>
            {
                entity.HasKey(e => e.MaCt)
                    .HasName("PK__ChiTietD__27258E74D4A3B6F8");

                entity.Property(e => e.MaCt)
                    .HasColumnName("MaCT")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MaDon)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MaThuoc)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.HasOne(d => d.MaDonNavigation)
                    .WithMany(p => p.ChiTietDonThuoc)
                    .HasForeignKey(d => d.MaDon)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CTDonThuoc_DonThuoc");

                entity.HasOne(d => d.MaThuocNavigation)
                    .WithMany(p => p.ChiTietDonThuoc)
                    .HasForeignKey(d => d.MaThuoc)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CTDonThuoc_Thuoc");
            });

            modelBuilder.Entity<ChiTietHoaDon>(entity =>
            {
                entity.HasKey(e => e.MaCthd)
                    .HasName("PK__ChiTietH__1E4FA7719394ADA8");

                entity.Property(e => e.MaCthd)
                    .HasColumnName("MaCTHD")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MaTt)
                    .IsRequired()
                    .HasColumnName("MaTT")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.NoiDung).HasMaxLength(255);

                entity.Property(e => e.SoTien).HasColumnType("decimal(12, 2)");

                entity.HasOne(d => d.MaTtNavigation)
                    .WithMany(p => p.ChiTietHoaDon)
                    .HasForeignKey(d => d.MaTt)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ChiTietHoaDon_ThanhToan");
            });

            modelBuilder.Entity<ChuyenKhoa>(entity =>
            {
                entity.HasKey(e => e.MaCk)
                    .HasName("PK__ChuyenKh__27258E0DC94077B6");

                entity.Property(e => e.MaCk)
                    .HasColumnName("MaCK")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.TenCk)
                    .IsRequired()
                    .HasColumnName("TenCK")
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<DonThuoc>(entity =>
            {
                entity.HasKey(e => e.MaDon)
                    .HasName("PK__DonThuoc__3D89F5682098B64B");

                entity.Property(e => e.MaDon)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MaLich)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.NgayLap).HasColumnType("datetime");

                entity.HasOne(d => d.MaLichNavigation)
                    .WithMany(p => p.DonThuoc)
                    .HasForeignKey(d => d.MaLich)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DonThuoc_LichKham");
            });

            modelBuilder.Entity<HoaDon>(entity =>
            {
                entity.HasKey(e => e.MaTt)
                    .HasName("PK__HoaDon__27250079B571FE50");

                entity.Property(e => e.MaTt)
                    .HasColumnName("MaTT")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MaLich)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.NgayTt)
                    .HasColumnName("NgayTT")
                    .HasColumnType("date")
                    .HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PhuongThuc).HasMaxLength(50);

                entity.Property(e => e.SoTien).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.TrangThai).HasMaxLength(50);

                entity.HasOne(d => d.MaLichNavigation)
                    .WithMany(p => p.HoaDon)
                    .HasForeignKey(d => d.MaLich)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ThanhToan_LichKham");
            });

            modelBuilder.Entity<KetQuaKham>(entity =>
            {
                entity.HasKey(e => e.MaKq)
                    .HasName("PK__KetQuaKh__2725CF114E932B80");

                entity.Property(e => e.MaKq)
                    .HasColumnName("MaKQ")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MaLich)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.NgayKham).HasColumnType("datetime");

                entity.HasOne(d => d.MaLichNavigation)
                    .WithMany(p => p.KetQuaKham)
                    .HasForeignKey(d => d.MaLich)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_KetQuaKham_LichKham");
            });

            modelBuilder.Entity<LichKham>(entity =>
            {
                entity.HasKey(e => e.MaLich)
                    .HasName("PK__LichKham__728A9AE960775532");

                entity.Property(e => e.MaLich)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MaBn)
                    .IsRequired()
                    .HasColumnName("MaBN")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MaBs)
                    .HasColumnName("MaBS")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.NgayGio).HasColumnType("datetime");

                entity.Property(e => e.Stt).HasColumnName("STT");

                entity.Property(e => e.TrangThai).HasMaxLength(50);

                entity.HasOne(d => d.MaBnNavigation)
                    .WithMany(p => p.LichKhamMaBnNavigation)
                    .HasForeignKey(d => d.MaBn)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LichKham_BenhNhan");

                entity.HasOne(d => d.MaBsNavigation)
                    .WithMany(p => p.LichKhamMaBsNavigation)
                    .HasForeignKey(d => d.MaBs)
                    .HasConstraintName("FK_LichKham_BacSi");
            });

            modelBuilder.Entity<Roles>(entity =>
            {
                entity.HasKey(e => e.RoleId)
                    .HasName("PK__Roles__8AFACE3AB4F4F7CE");

                entity.Property(e => e.RoleId)
                    .HasColumnName("RoleID")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.RoleName)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<ThongBao>(entity =>
            {
                entity.HasKey(e => e.MaTb)
                    .HasName("PK__ThongBao__2725006F9A429DA4");

                entity.Property(e => e.MaTb)
                    .HasColumnName("MaTB")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.LoaiThongBao).HasMaxLength(50);

                entity.Property(e => e.MaLich)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MaNguoiGui)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MaNguoiNhan)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.NgayGui).HasColumnType("datetime");

                entity.Property(e => e.TieuDe).HasMaxLength(200);

                entity.Property(e => e.TrangThai).HasMaxLength(50);

                entity.HasOne(d => d.MaLichNavigation)
                    .WithMany(p => p.ThongBao)
                    .HasForeignKey(d => d.MaLich)
                    .HasConstraintName("FK_ThongBao_LichKham");

                entity.HasOne(d => d.MaNguoiGuiNavigation)
                    .WithMany(p => p.ThongBaoMaNguoiGuiNavigation)
                    .HasForeignKey(d => d.MaNguoiGui)
                    .HasConstraintName("FK_ThongBao_NguoiGui");

                entity.HasOne(d => d.MaNguoiNhanNavigation)
                    .WithMany(p => p.ThongBaoMaNguoiNhanNavigation)
                    .HasForeignKey(d => d.MaNguoiNhan)
                    .HasConstraintName("FK_ThongBao_NguoiNhan");
            });

            modelBuilder.Entity<Thuoc>(entity =>
            {
                entity.HasKey(e => e.MaThuoc)
                    .HasName("PK__Thuoc__4BB1F620EB5CC0DB");

                entity.Property(e => e.MaThuoc)
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.DonVi).HasMaxLength(50);

                entity.Property(e => e.Gia).HasColumnType("decimal(12, 2)");

                entity.Property(e => e.TenThuoc)
                    .IsRequired()
                    .HasMaxLength(255);
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("PK__Users__1788CCAC006705AA");

                entity.Property(e => e.UserId)
                    .HasColumnName("UserID")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Cccd)
                    .HasColumnName("CCCD")
                    .HasMaxLength(20);

                entity.Property(e => e.DiaChi).HasMaxLength(255);

                entity.Property(e => e.Email).HasMaxLength(150);

                entity.Property(e => e.HoTen)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(e => e.MaCk)
                    .HasColumnName("MaCK")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.MatKhau).HasMaxLength(255);

                entity.Property(e => e.NgaySinh).HasColumnType("date");

                entity.Property(e => e.RoleId)
                    .IsRequired()
                    .HasColumnName("RoleID")
                    .HasMaxLength(1)
                    .IsUnicode(false);

                entity.Property(e => e.Sdt)
                    .HasColumnName("SDT")
                    .HasMaxLength(20);

                entity.HasOne(d => d.MaCkNavigation)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.MaCk)
                    .HasConstraintName("FK_Users_ChuyenKhoa");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Users_Roles");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}

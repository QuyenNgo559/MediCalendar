﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace QLBV1.Models
{
    public partial class DonThuoc
    {
        public DonThuoc()
        {
            ChiTietDonThuoc = new HashSet<ChiTietDonThuoc>();
        }

        public string MaDon { get; set; }
        public string MaLich { get; set; }
        public DateTime? NgayLap { get; set; }

        public virtual LichKham MaLichNavigation { get; set; }
        public virtual ICollection<ChiTietDonThuoc> ChiTietDonThuoc { get; set; }
    }
}
